@echo off
title UFC Requirements Tool v2
echo.
echo  ╔══════════════════════════════════════╗
echo  ║   UFC Requirements Tool v2           ║
echo  ║   DoD Unified Facilities Criteria    ║
echo  ╚══════════════════════════════════════╝
echo.

:: Check Python 3.10+
python --version >nul 2>&1
if errorlevel 1 (
    echo  ERROR: Python not found. Install Python 3.10+ from python.org
    pause & exit /b 1
)

:: Install / verify dependencies
echo  Checking dependencies...
pip install -r requirements.txt --quiet --no-warn-script-location
if errorlevel 1 (
    echo  WARNING: Some packages may not have installed correctly.
    echo  Try: pip install -r requirements.txt
)

echo.
echo  Starting application...
echo.
python main.py

if errorlevel 1 (
    echo.
    echo  Application exited with an error.
    pause
)
