# UFC Requirements Tool v2

Professional requirements management platform for DoD Unified Facilities Criteria (UFC)
documents. Implements INCOSE / ISO 29148 quality scoring, LLM classification,
ChromaDB semantic search, SQLite project workspace, and ReqIF export.

---

## Architecture

```
ufc_tool_v2/
├── main.py                  # Application entry point + all UI tabs
├── run.bat                  # Windows launcher
├── requirements.txt
├── ufc_tool_config.json     # Auto-created on first run
│
├── core/
│   ├── config.py            # AppConfig, LLMConfig, EmbeddingConfig dataclasses
│   ├── database.py          # ProjectDB — SQLite schema, CRUD, RTM, audit log
│   ├── llm_client.py        # OpenAI-compatible LLM client (classify/score/ask)
│   ├── embeddings.py        # ChromaDB VectorStore + EmbeddingClient (Ollama/LM Studio)
│   ├── incose.py            # Heuristic INCOSE/ISO 29148 quality scorer
│   ├── change_detection.py  # UFC edition diff (added/removed/modified requirements)
│   └── reqif_export.py      # ReqIF 1.2 XML generator
│
├── ui/
│   ├── theme.py             # Dark military palette + QSS stylesheet
│   ├── settings_dialog.py   # LLM endpoint + embedding + extraction settings
│   └── workers.py           # QThread workers for all background operations
│
├── data/
│   └── ufc_catalog.json     # 97 UFC/UFS document catalog
│
├── downloads/               # Downloaded PDFs (auto-created)
├── exports/                 # CSV/Excel/ReqIF exports (auto-created)
├── projects/                # Project .ufcdb databases (auto-created)
└── chroma_db/               # ChromaDB persistent vector store (auto-created)
```

---

## Setup

```bat
run.bat
```

Or manually:
```bash
pip install -r requirements.txt
python main.py
```

### Local LLM setup (choose one)

**LM Studio:**
1. Download and open LM Studio
2. Load any GGUF model (Mistral 7B or Llama 3 recommended)
3. Start the local server (default: http://localhost:1234)
4. In Settings → LLM Endpoints → use the LM Studio preset

**Ollama:**
```bash
ollama pull mistral                    # classification model
ollama pull nomic-embed-text           # embedding model (required for vector search)
```
Then in Settings → LLM Endpoints → use the Ollama preset.

---

## Feature Walkthrough

### Tab 1 — Download
- 97 UFC/UFS documents with category, title, and filename
- Concurrent downloads (1–8), streamed with SHA256 version hashing
- Version change detection: re-downloading a changed UFC flags it with ↑
- File hashes stored in project DB for change tracking across sessions

### Tab 2 — Extract & Score
- **pdfplumber** text extraction with font-size heading detection
- Heuristic INCOSE scoring runs at extraction time (instant, no LLM needed)
- **LLM Classifier**: sends each sentence to your local/cloud LLM to confirm it's a real requirement. Removes 40–70% of false positives.
- **LLM INCOSE Scorer**: more accurate attribute scoring using structured prompts
- **Embed**: sends all requirements to ChromaDB via nomic-embed-text
- **Dedup**: runs cosine similarity over all embeddings, removes near-duplicates (≥95% similar)
- "Send to Review →" pushes all surviving requirements to the Review tab

### Tab 3 — Review & Allocation
- Multi-column filters (status, priority, discipline, source, LLM result, INCOSE score)
- Editable cells with dropdown delegates (Priority / Discipline / Status)
- Detail pane with 4 sub-tabs:
  - **Requirement** — full text + metadata
  - **INCOSE Scores** — colour-coded bar chart of all 6 attributes
  - **Notes** — allocation rationale and "Assigned to" field, saved to DB
  - **Audit Log** — immutable per-requirement change history from DB
- **Quick Set**: bulk Accept / Reject / Defer / Priority for selected rows
- **View RTM**: traceability matrix showing all parent→child links + orphan list
- **Save to DB / Load from DB**: persist and resume review across sessions
- **Export CSV**: UTF-8 BOM, all 21 fields including INCOSE scores
- **Export Excel**: formatted .xlsx with status colour bands, freeze pane, auto-filter, Summary sheet
- **Export ReqIF**: ISO ReqIF 1.2 XML, importable into DOORS NG, Jama, Polarion, Reqtify

### Tab 4 — Semantic Search
- Natural language queries over embedded requirements
- Top-K configurable (5–100 results)
- Filter by source UFC
- Similarity score with colour coding (green ≥0.8, teal ≥0.6, yellow <0.6)
- **AI Answer (RAG)**: synthesises top-10 results through LLM to answer your question directly

### Tab 5 — Analytics
- Live project statistics from SQLite
- Review progress (reviewed / accepted / rejected / deferred)
- LLM classification breakdown
- Traceability link count
- Per-source UFC breakdown

---

## Database Schema (SQLite / .ufcdb)

| Table | Purpose |
|---|---|
| `requirements` | All extracted requirements with all scores and allocation fields |
| `allocations` | Parent→child traceability links with link type and rationale |
| `audit_log` | Immutable field-level change history with timestamps |
| `ufc_versions` | File hash + metadata per downloaded UFC for change detection |
| `change_detection` | Diff results when UFC editions are re-downloaded |
| `project_meta` | Key-value project metadata (name, created_at, etc.) |

---

## Req ID Format

Content-addressed, survives re-extraction:
```
UFC-3-301-01-a3f7c2d1
│              │
│              └── 8-char SHA256(source|page|text)
└── UFC number (normalized)
```

---

## INCOSE Quality Attributes

| Attribute | What is checked |
|---|---|
| Singular | One requirement per statement (no compound shall clauses) |
| Verifiable | Measurable units present; no vague terms (adequate, sufficient) |
| Unambiguous | No "and/or", no multiple interpretations |
| Complete | No TBDs, has a clear actor/subject |
| Traceable | Section heading or standard reference (UFC, NFPA, ASHRAE, etc.) |
| Feasible | No physically impossible language (100% reliable, zero downtime) |

Scores are 0.0–1.0. Overall = arithmetic mean. Displayed as colour-coded bars in the Review detail pane.

---

## ReqIF Export

The generated `.reqif` file conforms to ReqIF 1.2 (OMG specification). It includes:
- All requirement text, metadata, and INCOSE scores as typed attributes
- Status, Priority, and Discipline as enumeration datatypes
- Traceability links as `SPEC-RELATION` elements
- One `SPECIFICATION` per source UFC document

Import into DOORS NG: File → Import → ReqIF
Import into Jama: Administration → Import → ReqIF

---

## Notes

- UFC 3-340-01 (FOUO/classified hardened structures) returns 403 — expected
- Pre-2000 UFCs may be scanned images: uncomment `pytesseract` in requirements.txt for OCR
- ChromaDB creates a local `chroma_db/` folder. Back this up with your `.ufcdb` project file
- The `.ufcdb` extension is a standard SQLite database — can be opened with any SQLite browser
