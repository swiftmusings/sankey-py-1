"""
core/llm_client.py
==================
OpenAI-compatible LLM client supporting LM Studio, Ollama, and OpenAI.

Responsibilities
----------------
1.  Requirement classification  – is this sentence a true requirement?
2.  Requirement decomposition   – split compound requirements into atomics
3.  INCOSE quality scoring      – rate each requirement on 6 attributes
4.  General chat/completion     – used by future features (RAG Q&A)

All calls are synchronous and designed to run inside QThread workers.
"""

from __future__ import annotations
import json
import re
import time
import logging
from typing import Optional
from dataclasses import dataclass

try:
    from openai import OpenAI, APIConnectionError, APITimeoutError
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False

from core.config import LLMConfig

log = logging.getLogger(__name__)


# ── Prompts ────────────────────────────────────────────────────────────────────

CLASSIFY_SYSTEM = """You are a systems engineering expert specializing in DoD \
Unified Facilities Criteria (UFC) requirement analysis per INCOSE and ISO 29148.

Your task: determine whether a given sentence from a UFC document is a true \
engineering/design requirement (not a note, definition, reference, or process step).

A requirement:
- Uses modal verbs: shall, must, will, is required
- Specifies a capability, condition, constraint, or performance threshold
- Is testable/verifiable in principle

Respond with ONLY valid JSON, no markdown:
{"is_requirement": true|false, "confidence": 0.0-1.0, "rationale": "one sentence"}"""

CLASSIFY_USER = "Classify this UFC sentence:\n\n{text}"

INCOSE_SYSTEM = """You are a requirements quality analyst applying ISO 29148 and \
INCOSE Systems Engineering Handbook criteria.

Score the following requirement on six attributes. Each score is 0.0 (fails) to \
1.0 (fully satisfies). Be strict — most requirements have at least one weakness.

Attributes:
- singular: addresses exactly one requirement (no 'and/or' compound requirements)
- verifiable: can be tested or demonstrated objectively
- unambiguous: only one possible interpretation; no vague terms like "adequate", "sufficient"
- complete: fully states what is required without unstated assumptions
- traceable: can be linked to a need or higher-level requirement
- feasible: technically achievable with known methods

Respond with ONLY valid JSON, no markdown:
{"singular":0.0,"verifiable":0.0,"unambiguous":0.0,"complete":0.0,"traceable":0.0,"feasible":0.0,"issues":"comma-separated list of main weaknesses"}"""

INCOSE_USER = "Score this requirement:\n\n{text}"

DECOMPOSE_SYSTEM = """You are a requirements engineer. Split the following compound \
UFC requirement into atomic requirements (one 'shall' statement each). \
Preserve the original technical meaning. \
Respond with ONLY a JSON array of strings, no markdown:
["atomic requirement 1", "atomic requirement 2", ...]"""

DECOMPOSE_USER = "Decompose this compound requirement:\n\n{text}"


# ── Client ─────────────────────────────────────────────────────────────────────

@dataclass
class ClassificationResult:
    req_id: str
    is_requirement: bool
    confidence: float
    rationale: str
    error: str = ""


@dataclass
class IncoseResult:
    req_id: str
    score_singular: float
    score_verifiable: float
    score_unambiguous: float
    score_complete: float
    score_traceable: float
    score_feasible: float
    incose_overall: float
    issues: str
    error: str = ""


class LLMClient:
    """
    Thin wrapper around OpenAI client targeting any compatible endpoint.
    Handles retries, JSON parsing, and graceful degradation when the
    local server is unavailable.
    """

    def __init__(self, config: LLMConfig):
        self._cfg = config
        self._client: Optional[object] = None
        self._available: Optional[bool] = None

    def _get_client(self):
        if not HAS_OPENAI:
            raise ImportError("openai package not installed. Run: pip install openai")
        if self._client is None:
            self._client = OpenAI(
                base_url=self._cfg.base_url,
                api_key=self._cfg.api_key,
                timeout=self._cfg.timeout,
            )
        return self._client

    def check_available(self) -> tuple[bool, str]:
        """Ping the endpoint to verify it's reachable."""
        try:
            client = self._get_client()
            models = client.models.list()
            model_names = [m.id for m in models.data]
            self._available = True
            return True, f"Connected — {len(model_names)} model(s) available"
        except Exception as e:
            self._available = False
            return False, str(e)

    def _complete(self, system: str, user: str,
                  max_tokens: int = None) -> str:
        """Raw completion returning the assistant message string."""
        client = self._get_client()
        model  = self._cfg.model or None  # None = server picks loaded model

        kwargs = dict(
            messages=[
                {"role": "system", "content": system},
                {"role": "user",   "content": user},
            ],
            temperature=self._cfg.temperature,
            max_tokens=max_tokens or self._cfg.max_tokens,
        )
        if model:
            kwargs["model"] = model
        else:
            # For LM Studio the model field is required but can be a dummy value
            kwargs["model"] = "local-model"

        for attempt in range(3):
            try:
                resp = client.chat.completions.create(**kwargs)
                return resp.choices[0].message.content or ""
            except (APITimeoutError, APIConnectionError) as e:
                if attempt < 2:
                    time.sleep(1.5 * (attempt + 1))
                else:
                    raise
        return ""

    def _parse_json(self, text: str) -> dict:
        """Strip markdown fences and parse JSON, raising on failure."""
        text = text.strip()
        # Strip ```json ... ``` fences
        text = re.sub(r'^```(?:json)?\s*', '', text, flags=re.MULTILINE)
        text = re.sub(r'\s*```$', '', text, flags=re.MULTILINE)
        return json.loads(text.strip())

    # ── Classification ─────────────────────────────────────────────────────────

    def classify(self, req_id: str, text: str) -> ClassificationResult:
        try:
            raw  = self._complete(CLASSIFY_SYSTEM, CLASSIFY_USER.format(text=text))
            data = self._parse_json(raw)
            return ClassificationResult(
                req_id         = req_id,
                is_requirement = bool(data.get("is_requirement", True)),
                confidence     = float(data.get("confidence", 0.5)),
                rationale      = str(data.get("rationale", "")),
            )
        except Exception as e:
            return ClassificationResult(
                req_id=req_id, is_requirement=True,
                confidence=0.0, rationale="", error=str(e)
            )

    def classify_batch(self, items: list[dict],
                       progress_cb=None) -> list[dict]:
        """
        items: list of {"req_id": ..., "text": ...}
        Returns list of dicts ready for DB bulk_update_llm_scores.
        """
        results = []
        for i, item in enumerate(items):
            r = self.classify(item["req_id"], item["text"])
            results.append({
                "req_id":            r.req_id,
                "llm_is_requirement": 1 if r.is_requirement else 0,
                "llm_confidence":    r.confidence,
                "llm_rationale":     r.rationale,
            })
            if progress_cb:
                progress_cb(i + 1, len(items), r)
        return results

    # ── INCOSE Scoring ─────────────────────────────────────────────────────────

    def score_incose(self, req_id: str, text: str) -> IncoseResult:
        try:
            raw  = self._complete(INCOSE_SYSTEM, INCOSE_USER.format(text=text),
                                  max_tokens=256)
            data = self._parse_json(raw)
            scores = {
                "score_singular":    float(data.get("singular",    0.5)),
                "score_verifiable":  float(data.get("verifiable",  0.5)),
                "score_unambiguous": float(data.get("unambiguous", 0.5)),
                "score_complete":    float(data.get("complete",    0.5)),
                "score_traceable":   float(data.get("traceable",   0.5)),
                "score_feasible":    float(data.get("feasible",    0.5)),
            }
            overall = round(sum(scores.values()) / len(scores), 3)
            return IncoseResult(
                req_id=req_id, **scores,
                incose_overall=overall,
                issues=str(data.get("issues","")),
            )
        except Exception as e:
            return IncoseResult(
                req_id=req_id,
                score_singular=0, score_verifiable=0, score_unambiguous=0,
                score_complete=0, score_traceable=0, score_feasible=0,
                incose_overall=0, issues="", error=str(e)
            )

    def score_incose_batch(self, items: list[dict],
                           progress_cb=None) -> list[dict]:
        results = []
        for i, item in enumerate(items):
            r = self.score_incose(item["req_id"], item["text"])
            results.append({
                "req_id":            r.req_id,
                "score_singular":    r.score_singular,
                "score_verifiable":  r.score_verifiable,
                "score_unambiguous": r.score_unambiguous,
                "score_complete":    r.score_complete,
                "score_traceable":   r.score_traceable,
                "score_feasible":    r.score_feasible,
                "incose_overall":    r.incose_overall,
            })
            if progress_cb:
                progress_cb(i + 1, len(items), r)
        return results

    # ── Decomposition ──────────────────────────────────────────────────────────

    def decompose(self, text: str) -> list[str]:
        """Return list of atomic requirement strings."""
        try:
            raw  = self._complete(DECOMPOSE_SYSTEM, DECOMPOSE_USER.format(text=text),
                                  max_tokens=512)
            data = self._parse_json(raw)
            if isinstance(data, list):
                return [str(s) for s in data if s]
            return [text]
        except Exception:
            return [text]

    # ── General completion (for RAG Q&A) ──────────────────────────────────────

    def ask(self, system: str, user: str, max_tokens: int = 1024) -> str:
        try:
            return self._complete(system, user, max_tokens=max_tokens)
        except Exception as e:
            return f"[LLM error: {e}]"
