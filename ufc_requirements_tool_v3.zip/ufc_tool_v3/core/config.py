"""
core/config.py
==============
Persistent application configuration stored in a JSON file alongside the
project database.  Covers LLM endpoints, embedding settings, UI prefs, and
extraction defaults.
"""

from __future__ import annotations
import json
import os
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Optional

# ── Default paths ─────────────────────────────────────────────────────────────
APP_DIR      = Path(__file__).parent.parent
CONFIG_PATH  = APP_DIR / "ufc_tool_config.json"
CATALOG_PATH = APP_DIR / "data" / "ufc_catalog.json"
DOWNLOADS_DIR = APP_DIR / "downloads"
EXPORTS_DIR   = APP_DIR / "exports"

for _d in (DOWNLOADS_DIR, EXPORTS_DIR):
    _d.mkdir(exist_ok=True)


@dataclass
class LLMConfig:
    """Settings for a single OpenAI-compatible LLM endpoint."""
    name: str           = "LM Studio"
    base_url: str       = "http://localhost:1234/v1"
    api_key: str        = "lm-studio"          # arbitrary for local servers
    model: str          = ""                   # empty = use whatever is loaded
    temperature: float  = 0.0
    max_tokens: int     = 512
    timeout: int        = 60                   # seconds
    enabled: bool       = True

    # Preset helpers
    @classmethod
    def lm_studio(cls) -> "LLMConfig":
        return cls(name="LM Studio",
                   base_url="http://localhost:1234/v1",
                   api_key="lm-studio",
                   model="")

    @classmethod
    def ollama(cls) -> "LLMConfig":
        return cls(name="Ollama",
                   base_url="http://localhost:11434/v1",
                   api_key="ollama",
                   model="mistral")

    @classmethod
    def openai(cls) -> "LLMConfig":
        return cls(name="OpenAI",
                   base_url="https://api.openai.com/v1",
                   api_key=os.environ.get("OPENAI_API_KEY", ""),
                   model="gpt-4o-mini")


@dataclass
class EmbeddingConfig:
    """Settings for the embedding model used by ChromaDB."""
    provider: str   = "ollama"                 # "ollama" | "lm_studio" | "openai"
    base_url: str   = "http://localhost:11434"
    model: str      = "nomic-embed-text"
    api_key: str    = "ollama"
    batch_size: int = 32


@dataclass
class ExtractionConfig:
    """Defaults for the extraction engine."""
    min_words: int          = 8
    use_shall: bool         = True
    use_must: bool          = True
    use_required: bool      = True
    use_will: bool          = True
    use_should: bool        = False
    concurrent_downloads: int = 3
    use_font_heuristics: bool = True           # pdfplumber font-size heading detect


@dataclass
class AppConfig:
    """Root configuration object — serialised to JSON."""
    llm_endpoints: list[dict]     = field(default_factory=lambda: [
        asdict(LLMConfig.lm_studio()),
        asdict(LLMConfig.ollama()),
    ])
    active_llm_index: int         = 0
    embedding: dict               = field(default_factory=lambda: asdict(EmbeddingConfig()))
    extraction: dict              = field(default_factory=lambda: asdict(ExtractionConfig()))
    last_project_path: str        = ""
    theme: str                    = "dark"
    window_geometry: str          = ""

    # ── Serialization ──────────────────────────────────────────────────────────

    def save(self, path: Path = CONFIG_PATH):
        with open(path, "w") as f:
            json.dump(asdict(self), f, indent=2)

    @classmethod
    def load(cls, path: Path = CONFIG_PATH) -> "AppConfig":
        if not path.exists():
            cfg = cls()
            cfg.save(path)
            return cfg
        try:
            with open(path) as f:
                data = json.load(f)
            cfg = cls()
            for k, v in data.items():
                if hasattr(cfg, k):
                    setattr(cfg, k, v)
            return cfg
        except Exception:
            return cls()

    def get_active_llm(self) -> LLMConfig:
        idx = min(self.active_llm_index, len(self.llm_endpoints) - 1)
        d   = self.llm_endpoints[idx]
        return LLMConfig(**{k: v for k, v in d.items()
                            if k in LLMConfig.__dataclass_fields__})

    def get_embedding(self) -> EmbeddingConfig:
        return EmbeddingConfig(**{k: v for k, v in self.embedding.items()
                                  if k in EmbeddingConfig.__dataclass_fields__})

    def get_extraction(self) -> ExtractionConfig:
        return ExtractionConfig(**{k: v for k, v in self.extraction.items()
                                   if k in ExtractionConfig.__dataclass_fields__})
