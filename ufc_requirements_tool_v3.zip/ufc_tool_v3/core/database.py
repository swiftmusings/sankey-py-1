"""
core/database.py
================
SQLite persistence layer for UFC Requirements Tool v2.

Schema
------
  projects        – named workspaces with metadata
  requirements    – extracted requirements with all fields
  allocations     – traceability links (parent/child)
  audit_log       – immutable change history
  ufc_versions    – tracked download versions for change detection
  embeddings_meta – ChromaDB sync state per requirement
"""

from __future__ import annotations
import sqlite3
import json
import hashlib
import datetime
from pathlib import Path
from contextlib import contextmanager
from typing import Optional, Generator

# ── Schema ─────────────────────────────────────────────────────────────────────
SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS project_meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS requirements (
    req_id          TEXT PRIMARY KEY,
    source_ufc      TEXT NOT NULL,
    ufc_version     TEXT NOT NULL DEFAULT '',
    page            INTEGER,
    section         TEXT,
    text            TEXT NOT NULL,
    keyword         TEXT,
    -- INCOSE quality scores (0.0–1.0 each)
    score_singular      REAL DEFAULT NULL,
    score_verifiable    REAL DEFAULT NULL,
    score_unambiguous   REAL DEFAULT NULL,
    score_complete      REAL DEFAULT NULL,
    score_traceable     REAL DEFAULT NULL,
    score_feasible      REAL DEFAULT NULL,
    incose_overall      REAL DEFAULT NULL,
    llm_is_requirement  INTEGER DEFAULT NULL,  -- 1=yes, 0=no, NULL=unscored
    llm_confidence      REAL DEFAULT NULL,
    llm_rationale       TEXT DEFAULT '',
    -- Allocation
    priority        TEXT DEFAULT 'Unset',
    discipline      TEXT DEFAULT 'Unassigned',
    status          TEXT DEFAULT 'Unreviewed',
    notes           TEXT DEFAULT '',
    assigned_to     TEXT DEFAULT '',
    -- Dedup
    content_hash    TEXT,
    is_duplicate    INTEGER DEFAULT 0,
    canonical_id    TEXT DEFAULT NULL,
    -- Embedding
    embedded        INTEGER DEFAULT 0,
    -- Timestamps
    extracted_at    TEXT,
    reviewed_at     TEXT,
    updated_at      TEXT
);

CREATE TABLE IF NOT EXISTS allocations (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    parent_req_id   TEXT NOT NULL,
    child_req_id    TEXT NOT NULL,
    link_type       TEXT DEFAULT 'derives',   -- derives | refines | conflicts | satisfies
    rationale       TEXT DEFAULT '',
    created_at      TEXT,
    created_by      TEXT DEFAULT '',
    FOREIGN KEY(parent_req_id) REFERENCES requirements(req_id),
    FOREIGN KEY(child_req_id)  REFERENCES requirements(req_id),
    UNIQUE(parent_req_id, child_req_id, link_type)
);

CREATE TABLE IF NOT EXISTS audit_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    req_id      TEXT,
    field       TEXT,
    old_value   TEXT,
    new_value   TEXT,
    changed_by  TEXT DEFAULT 'user',
    changed_at  TEXT
);

CREATE TABLE IF NOT EXISTS ufc_versions (
    filename        TEXT PRIMARY KEY,
    ufc_id          TEXT,
    downloaded_at   TEXT,
    file_hash       TEXT,
    file_size_bytes INTEGER,
    page_count      INTEGER DEFAULT 0,
    req_count       INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS change_detection (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    filename        TEXT,
    detected_at     TEXT,
    old_file_hash   TEXT,
    new_file_hash   TEXT,
    reqs_added      INTEGER DEFAULT 0,
    reqs_removed    INTEGER DEFAULT 0,
    reqs_modified   INTEGER DEFAULT 0,
    diff_json       TEXT DEFAULT '{}'
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_req_source  ON requirements(source_ufc);
CREATE INDEX IF NOT EXISTS idx_req_status  ON requirements(status);
CREATE INDEX IF NOT EXISTS idx_req_priority ON requirements(priority);
CREATE INDEX IF NOT EXISTS idx_req_discipline ON requirements(discipline);
CREATE INDEX IF NOT EXISTS idx_req_hash    ON requirements(content_hash);
CREATE INDEX IF NOT EXISTS idx_req_llm     ON requirements(llm_is_requirement);
CREATE INDEX IF NOT EXISTS idx_alloc_parent ON allocations(parent_req_id);
CREATE INDEX IF NOT EXISTS idx_alloc_child  ON allocations(child_req_id);
CREATE INDEX IF NOT EXISTS idx_audit_req    ON audit_log(req_id);
"""


def _now() -> str:
    return datetime.datetime.utcnow().isoformat()


def make_req_id(source_ufc: str, text: str, page: int) -> str:
    """
    Content-addressed Req ID — survives re-extraction.
    Format: UFC-3-301-01-a3f7c2d1  (UFC ID + 8-char SHA256 of content)
    """
    raw = f"{source_ufc}|{page}|{text.strip()}"
    h   = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:8]
    uid = source_ufc.replace(" ", "-").upper()
    return f"{uid}-{h}"


def make_content_hash(text: str) -> str:
    """Full SHA256 of normalised text for dedup."""
    normalised = " ".join(text.lower().split())
    return hashlib.sha256(normalised.encode("utf-8")).hexdigest()


class ProjectDB:
    """
    Wraps a SQLite database for a single UFC project workspace.
    Thread-safe: each call gets a fresh connection from the pool.
    WAL mode allows concurrent readers.
    """

    def __init__(self, path: Path):
        self.path = Path(path)
        self._init_schema()

    # ── Connection management ─────────────────────────────────────────────────

    @contextmanager
    def _conn(self) -> Generator[sqlite3.Connection, None, None]:
        conn = sqlite3.connect(str(self.path), timeout=10,
                               detect_types=sqlite3.PARSE_DECLTYPES)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA journal_mode=WAL")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_schema(self):
        with self._conn() as conn:
            conn.executescript(SCHEMA)

    # ── Project metadata ──────────────────────────────────────────────────────

    def set_meta(self, key: str, value: str):
        with self._conn() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO project_meta(key,value) VALUES(?,?)",
                (key, value)
            )

    def get_meta(self, key: str, default: str = "") -> str:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT value FROM project_meta WHERE key=?", (key,)
            ).fetchone()
        return row["value"] if row else default

    def get_all_meta(self) -> dict:
        with self._conn() as conn:
            rows = conn.execute("SELECT key,value FROM project_meta").fetchall()
        return {r["key"]: r["value"] for r in rows}

    # ── Requirements CRUD ─────────────────────────────────────────────────────

    def upsert_requirements(self, reqs: list[dict]) -> tuple[int, int]:
        """Insert or update requirements. Returns (inserted, updated)."""
        inserted = updated = 0
        now = _now()
        with self._conn() as conn:
            for r in reqs:
                req_id = r.get("req_id") or make_req_id(
                    r["source_ufc"], r["text"], int(r.get("page") or 0)
                )
                content_hash = make_content_hash(r["text"])
                existing = conn.execute(
                    "SELECT req_id FROM requirements WHERE req_id=?",
                    (req_id,)
                ).fetchone()

                if existing:
                    conn.execute("""
                        UPDATE requirements SET
                            text=?, page=?, section=?, keyword=?,
                            content_hash=?, updated_at=?
                        WHERE req_id=?
                    """, (
                        r.get("text",""), r.get("page"), r.get("section",""),
                        r.get("keyword",""), content_hash, now, req_id
                    ))
                    updated += 1
                else:
                    conn.execute("""
                        INSERT INTO requirements
                        (req_id, source_ufc, ufc_version, page, section, text,
                         keyword, priority, discipline, status, notes,
                         content_hash, extracted_at, updated_at)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """, (
                        req_id,
                        r.get("source","") or r.get("source_ufc",""),
                        r.get("ufc_version",""),
                        r.get("page"),
                        r.get("section",""),
                        r.get("text",""),
                        r.get("keyword",""),
                        r.get("priority","Unset"),
                        r.get("discipline","Unassigned"),
                        r.get("status","Unreviewed"),
                        r.get("notes",""),
                        content_hash,
                        now, now,
                    ))
                    inserted += 1
        return inserted, updated

    def get_requirements(self,
                         source_ufc: str = None,
                         status: str = None,
                         priority: str = None,
                         discipline: str = None,
                         llm_only: bool = False,
                         include_duplicates: bool = False,
                         limit: int = None,
                         offset: int = 0) -> list[dict]:
        clauses = []
        params  = []

        if source_ufc:
            clauses.append("source_ufc=?"); params.append(source_ufc)
        if status and status != "All Statuses":
            clauses.append("status=?"); params.append(status)
        if priority and priority != "All Priorities":
            clauses.append("priority=?"); params.append(priority)
        if discipline and discipline != "All Disciplines":
            clauses.append("discipline=?"); params.append(discipline)
        if llm_only:
            clauses.append("llm_is_requirement=1")
        if not include_duplicates:
            clauses.append("is_duplicate=0")

        where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
        lim   = f"LIMIT {limit} OFFSET {offset}" if limit else ""
        sql   = f"SELECT * FROM requirements {where} ORDER BY source_ufc, page {lim}"

        with self._conn() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def update_requirement_field(self, req_id: str, field: str,
                                  value, changed_by: str = "user"):
        """Update a single field and append to audit log."""
        allowed = {
            "priority","discipline","status","notes","assigned_to",
            "score_singular","score_verifiable","score_unambiguous",
            "score_complete","score_traceable","score_feasible",
            "incose_overall","llm_is_requirement","llm_confidence",
            "llm_rationale","is_duplicate","canonical_id","embedded",
        }
        if field not in allowed:
            raise ValueError(f"Field '{field}' not updatable via this method")
        now = _now()
        with self._conn() as conn:
            old = conn.execute(
                f"SELECT {field} FROM requirements WHERE req_id=?", (req_id,)
            ).fetchone()
            old_val = str(old[field]) if old else ""
            conn.execute(
                f"UPDATE requirements SET {field}=?, updated_at=? WHERE req_id=?",
                (value, now, req_id)
            )
            conn.execute(
                "INSERT INTO audit_log(req_id,field,old_value,new_value,"
                "changed_by,changed_at) VALUES(?,?,?,?,?,?)",
                (req_id, field, old_val, str(value), changed_by, now)
            )

    def bulk_update_llm_scores(self, scored: list[dict]):
        """
        Batch-update LLM classification results.
        Each dict must have req_id + the score/flag fields.
        """
        now = _now()
        with self._conn() as conn:
            for s in scored:
                conn.execute("""
                    UPDATE requirements SET
                        llm_is_requirement=?,
                        llm_confidence=?,
                        llm_rationale=?,
                        updated_at=?
                    WHERE req_id=?
                """, (
                    s.get("llm_is_requirement"),
                    s.get("llm_confidence"),
                    s.get("llm_rationale",""),
                    now,
                    s["req_id"],
                ))

    def bulk_update_incose_scores(self, scored: list[dict]):
        now = _now()
        with self._conn() as conn:
            for s in scored:
                conn.execute("""
                    UPDATE requirements SET
                        score_singular=?, score_verifiable=?,
                        score_unambiguous=?, score_complete=?,
                        score_traceable=?, score_feasible=?,
                        incose_overall=?, updated_at=?
                    WHERE req_id=?
                """, (
                    s.get("score_singular"), s.get("score_verifiable"),
                    s.get("score_unambiguous"), s.get("score_complete"),
                    s.get("score_traceable"), s.get("score_feasible"),
                    s.get("incose_overall"), now, s["req_id"],
                ))

    def mark_duplicates(self, dup_pairs: list[tuple[str, str]]):
        """
        Mark requirements as duplicates.
        dup_pairs: list of (duplicate_req_id, canonical_req_id)
        """
        now = _now()
        with self._conn() as conn:
            for dup_id, canon_id in dup_pairs:
                conn.execute("""
                    UPDATE requirements SET
                        is_duplicate=1, canonical_id=?, updated_at=?
                    WHERE req_id=?
                """, (canon_id, now, dup_id))

    def get_duplicates_summary(self) -> dict:
        with self._conn() as conn:
            total = conn.execute(
                "SELECT COUNT(*) FROM requirements").fetchone()[0]
            dups  = conn.execute(
                "SELECT COUNT(*) FROM requirements WHERE is_duplicate=1").fetchone()[0]
            unscored = conn.execute(
                "SELECT COUNT(*) FROM requirements WHERE llm_is_requirement IS NULL"
                " AND is_duplicate=0").fetchone()[0]
        return {"total": total, "duplicates": dups, "unscored_llm": unscored}

    def count(self, where: str = "", params=()) -> int:
        with self._conn() as conn:
            sql = f"SELECT COUNT(*) FROM requirements {where}"
            return conn.execute(sql, params).fetchone()[0]

    # ── Traceability / Allocations ────────────────────────────────────────────

    def add_allocation(self, parent_id: str, child_id: str,
                       link_type: str = "derives", rationale: str = "",
                       created_by: str = "user") -> int:
        now = _now()
        with self._conn() as conn:
            cur = conn.execute("""
                INSERT OR IGNORE INTO allocations
                (parent_req_id, child_req_id, link_type, rationale,
                 created_at, created_by)
                VALUES (?,?,?,?,?,?)
            """, (parent_id, child_id, link_type, rationale, now, created_by))
            return cur.lastrowid

    def remove_allocation(self, parent_id: str, child_id: str,
                          link_type: str = "derives"):
        with self._conn() as conn:
            conn.execute("""
                DELETE FROM allocations
                WHERE parent_req_id=? AND child_req_id=? AND link_type=?
            """, (parent_id, child_id, link_type))

    def get_children(self, req_id: str) -> list[dict]:
        with self._conn() as conn:
            rows = conn.execute("""
                SELECT a.*, r.text, r.source_ufc, r.status
                FROM allocations a
                JOIN requirements r ON r.req_id = a.child_req_id
                WHERE a.parent_req_id=?
            """, (req_id,)).fetchall()
        return [dict(r) for r in rows]

    def get_parents(self, req_id: str) -> list[dict]:
        with self._conn() as conn:
            rows = conn.execute("""
                SELECT a.*, r.text, r.source_ufc, r.status
                FROM allocations a
                JOIN requirements r ON r.req_id = a.parent_req_id
                WHERE a.child_req_id=?
            """, (req_id,)).fetchall()
        return [dict(r) for r in rows]

    def get_rtm(self) -> list[dict]:
        """Full RTM as list of (parent, child, link) rows."""
        with self._conn() as conn:
            rows = conn.execute("""
                SELECT
                    a.parent_req_id, p.text AS parent_text,
                    p.source_ufc AS parent_source,
                    a.child_req_id,  c.text AS child_text,
                    c.source_ufc AS child_source,
                    a.link_type, a.rationale,
                    c.status AS child_status
                FROM allocations a
                JOIN requirements p ON p.req_id = a.parent_req_id
                JOIN requirements c ON c.req_id = a.child_req_id
                ORDER BY a.parent_req_id
            """).fetchall()
        return [dict(r) for r in rows]

    def get_orphans(self) -> list[dict]:
        """Requirements with no parent and no children."""
        with self._conn() as conn:
            rows = conn.execute("""
                SELECT r.* FROM requirements r
                WHERE r.is_duplicate=0
                  AND r.req_id NOT IN (
                      SELECT child_req_id FROM allocations
                      UNION
                      SELECT parent_req_id FROM allocations
                  )
            """).fetchall()
        return [dict(r) for r in rows]

    # ── UFC Version tracking ──────────────────────────────────────────────────

    def record_ufc_version(self, filename: str, ufc_id: str,
                            file_hash: str, file_size: int,
                            page_count: int = 0, req_count: int = 0):
        now = _now()
        with self._conn() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO ufc_versions
                (filename, ufc_id, downloaded_at, file_hash,
                 file_size_bytes, page_count, req_count)
                VALUES (?,?,?,?,?,?,?)
            """, (filename, ufc_id, now, file_hash, file_size, page_count, req_count))

    def get_ufc_version(self, filename: str) -> Optional[dict]:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT * FROM ufc_versions WHERE filename=?", (filename,)
            ).fetchone()
        return dict(row) if row else None

    def record_change_detection(self, filename: str, old_hash: str,
                                  new_hash: str, diff: dict):
        now = _now()
        with self._conn() as conn:
            conn.execute("""
                INSERT INTO change_detection
                (filename, detected_at, old_file_hash, new_file_hash,
                 reqs_added, reqs_removed, reqs_modified, diff_json)
                VALUES (?,?,?,?,?,?,?,?)
            """, (
                filename, now, old_hash, new_hash,
                diff.get("added",0), diff.get("removed",0),
                diff.get("modified",0), json.dumps(diff)
            ))

    # ── Audit ─────────────────────────────────────────────────────────────────

    def get_audit_log(self, req_id: str = None,
                      limit: int = 200) -> list[dict]:
        with self._conn() as conn:
            if req_id:
                rows = conn.execute(
                    "SELECT * FROM audit_log WHERE req_id=? "
                    "ORDER BY changed_at DESC LIMIT ?",
                    (req_id, limit)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM audit_log ORDER BY changed_at DESC LIMIT ?",
                    (limit,)
                ).fetchall()
        return [dict(r) for r in rows]

    # ── Stats ─────────────────────────────────────────────────────────────────

    def get_stats(self) -> dict:
        with self._conn() as conn:
            total    = conn.execute("SELECT COUNT(*) FROM requirements").fetchone()[0]
            dups     = conn.execute("SELECT COUNT(*) FROM requirements WHERE is_duplicate=1").fetchone()[0]
            reviewed = conn.execute("SELECT COUNT(*) FROM requirements WHERE status!='Unreviewed'").fetchone()[0]
            accepted = conn.execute("SELECT COUNT(*) FROM requirements WHERE status='Accepted'").fetchone()[0]
            rejected = conn.execute("SELECT COUNT(*) FROM requirements WHERE status='Rejected'").fetchone()[0]
            deferred = conn.execute("SELECT COUNT(*) FROM requirements WHERE status='Deferred'").fetchone()[0]
            llm_yes  = conn.execute("SELECT COUNT(*) FROM requirements WHERE llm_is_requirement=1").fetchone()[0]
            llm_no   = conn.execute("SELECT COUNT(*) FROM requirements WHERE llm_is_requirement=0").fetchone()[0]
            allocs   = conn.execute("SELECT COUNT(*) FROM allocations").fetchone()[0]
            sources  = conn.execute(
                "SELECT source_ufc, COUNT(*) as n FROM requirements "
                "WHERE is_duplicate=0 GROUP BY source_ufc"
            ).fetchall()
        return {
            "total": total, "duplicates": dups,
            "unique": total - dups, "reviewed": reviewed,
            "accepted": accepted, "rejected": rejected, "deferred": deferred,
            "llm_confirmed": llm_yes, "llm_rejected": llm_no,
            "allocations": allocs,
            "by_source": {r["source_ufc"]: r["n"] for r in sources},
        }
