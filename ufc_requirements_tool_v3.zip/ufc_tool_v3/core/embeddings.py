"""
core/embeddings.py
==================
ChromaDB vector store for semantic search and near-duplicate detection.
Uses Ollama's nomic-embed-text (or any configured embedding endpoint).
"""

from __future__ import annotations
import hashlib
import logging
from typing import Optional
from dataclasses import dataclass

log = logging.getLogger(__name__)

# ── Optional imports ───────────────────────────────────────────────────────────
try:
    import chromadb
    from chromadb.config import Settings
    HAS_CHROMA = True
except ImportError:
    HAS_CHROMA = False

try:
    import requests as _requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


@dataclass
class SearchResult:
    req_id: str
    text: str
    source_ufc: str
    score: float          # cosine similarity 0–1 (higher = more similar)
    is_duplicate: bool = False


class EmbeddingClient:
    """
    Wraps Ollama (or any OpenAI-compatible) embedding endpoint.
    Returns float vectors for use with ChromaDB.
    """

    def __init__(self, base_url: str, model: str, api_key: str = "ollama"):
        self._base    = base_url.rstrip("/")
        self._model   = model
        self._api_key = api_key
        # Try Ollama-native endpoint first, fall back to OpenAI-compat
        self._use_native = "11434" in base_url or "ollama" in base_url.lower()

    def embed(self, texts: list[str]) -> list[list[float]]:
        """Return embeddings for a list of texts."""
        if not HAS_REQUESTS:
            raise ImportError("requests package not installed")

        if self._use_native:
            return self._embed_ollama_native(texts)
        else:
            return self._embed_openai_compat(texts)

    def _embed_ollama_native(self, texts: list[str]) -> list[list[float]]:
        """Use Ollama /api/embed (batch) or /api/embeddings (single)."""
        import requests
        results = []
        # Ollama batch endpoint (>= 0.3.0)
        try:
            resp = requests.post(
                f"{self._base}/api/embed",
                json={"model": self._model, "input": texts},
                timeout=120
            )
            if resp.status_code == 200:
                data = resp.json()
                if "embeddings" in data:
                    return data["embeddings"]
        except Exception:
            pass

        # Fall back to single-text endpoint
        for text in texts:
            resp = requests.post(
                f"{self._base}/api/embeddings",
                json={"model": self._model, "prompt": text},
                timeout=60
            )
            resp.raise_for_status()
            results.append(resp.json()["embedding"])
        return results

    def _embed_openai_compat(self, texts: list[str]) -> list[list[float]]:
        """Use OpenAI-compatible /v1/embeddings endpoint."""
        import requests
        resp = requests.post(
            f"{self._base}/v1/embeddings",
            headers={"Authorization": f"Bearer {self._api_key}"},
            json={"model": self._model, "input": texts},
            timeout=120
        )
        resp.raise_for_status()
        data = resp.json()
        return [item["embedding"] for item in sorted(
            data["data"], key=lambda x: x["index"]
        )]

    def check_available(self) -> tuple[bool, str]:
        if not HAS_REQUESTS:
            return False, "requests not installed"
        try:
            test = self.embed(["test"])
            dim  = len(test[0]) if test else 0
            return True, f"OK — embedding dim {dim}"
        except Exception as e:
            return False, str(e)


class VectorStore:
    """
    ChromaDB collection wrapper for UFC requirements.
    Provides:
      - upsert(requirements)     — add/update embeddings
      - search(query, k)         — semantic similarity search
      - find_duplicates(thresh)  — cluster near-duplicates
      - get_stats()              — collection info
    """

    COLLECTION_NAME = "ufc_requirements"

    def __init__(self, persist_dir: str, embedding_client: EmbeddingClient):
        if not HAS_CHROMA:
            raise ImportError("chromadb not installed. Run: pip install chromadb")
        self._embed_client = embedding_client
        self._chroma = chromadb.PersistentClient(
            path=persist_dir,
            settings=Settings(anonymized_telemetry=False)
        )
        self._col = self._chroma.get_or_create_collection(
            name=self.COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"}
        )

    # ── Upsert ────────────────────────────────────────────────────────────────

    def upsert(self, reqs: list[dict],
               batch_size: int = 32,
               progress_cb=None) -> int:
        """
        Embed and store requirements.
        reqs must have: req_id, text, source_ufc, (optional) section, page
        Returns count of upserted items.
        """
        total = 0
        for i in range(0, len(reqs), batch_size):
            batch = reqs[i:i + batch_size]
            texts = [r["text"] for r in batch]
            try:
                vectors = self._embed_client.embed(texts)
            except Exception as e:
                log.error(f"Embedding batch {i//batch_size} failed: {e}")
                continue

            ids      = [r["req_id"] for r in batch]
            metadata = [
                {
                    "source_ufc": r.get("source_ufc", r.get("source", "")),
                    "page":       str(r.get("page", "")),
                    "section":    str(r.get("section", ""))[:500],
                    "status":     r.get("status", "Unreviewed"),
                }
                for r in batch
            ]

            self._col.upsert(
                ids=ids,
                embeddings=vectors,
                documents=texts,
                metadatas=metadata,
            )
            total += len(batch)
            if progress_cb:
                progress_cb(min(i + batch_size, len(reqs)), len(reqs))

        return total

    # ── Search ────────────────────────────────────────────────────────────────

    def search(self, query: str, k: int = 20,
               source_filter: str = None) -> list[SearchResult]:
        """Semantic similarity search. Returns top-k results."""
        where = {"source_ufc": source_filter} if source_filter else None
        try:
            vectors = self._embed_client.embed([query])
        except Exception as e:
            log.error(f"Query embedding failed: {e}")
            return []

        kw = dict(
            query_embeddings=vectors,
            n_results=min(k, self._col.count() or 1),
            include=["documents", "metadatas", "distances"],
        )
        if where:
            kw["where"] = where

        results = self._col.query(**kw)

        out = []
        for idx in range(len(results["ids"][0])):
            out.append(SearchResult(
                req_id     = results["ids"][0][idx],
                text       = results["documents"][0][idx],
                source_ufc = results["metadatas"][0][idx].get("source_ufc",""),
                score      = 1.0 - float(results["distances"][0][idx]),
            ))
        return sorted(out, key=lambda r: r.score, reverse=True)

    # ── Near-duplicate detection ──────────────────────────────────────────────

    def find_duplicates(self, threshold: float = 0.95,
                        batch_size: int = 100,
                        progress_cb=None) -> list[tuple[str, str, float]]:
        """
        Compare each requirement against its nearest neighbours.
        Returns list of (dup_id, canonical_id, similarity) pairs.
        threshold: cosine similarity above which two requirements are dups.
        The canonical is the one that appears first (lower batch index).
        """
        total_count = self._col.count()
        if total_count == 0:
            return []

        # Get all items in batches (ChromaDB limit = 5461 per get call)
        all_ids   = []
        all_texts = []
        all_vecs  = []

        offset = 0
        chunk  = min(batch_size, 500)
        while offset < total_count:
            got = self._col.get(
                limit=chunk, offset=offset,
                include=["embeddings", "documents"]
            )
            if not got["ids"]:
                break
            all_ids.extend(got["ids"])
            all_texts.extend(got["documents"])
            all_vecs.extend(got["embeddings"])
            offset += len(got["ids"])
            if progress_cb:
                progress_cb(offset, total_count, "Loading embeddings…")

        import numpy as np
        vecs    = np.array(all_vecs, dtype=np.float32)
        # Normalize for cosine similarity
        norms   = np.linalg.norm(vecs, axis=1, keepdims=True)
        norms   = np.where(norms == 0, 1, norms)
        vecs_n  = vecs / norms

        seen_canonical: dict[str, str] = {}   # dup_id -> canonical_id
        dup_pairs: list[tuple[str, str, float]] = []

        for i in range(len(all_ids)):
            if progress_cb and i % 50 == 0:
                progress_cb(i, len(all_ids), "Finding duplicates…")

            sim = vecs_n @ vecs_n[i]           # dot product = cosine sim
            for j in range(i + 1, len(all_ids)):
                if sim[j] >= threshold:
                    canonical = all_ids[i]
                    duplicate = all_ids[j]
                    if duplicate not in seen_canonical:
                        seen_canonical[duplicate] = canonical
                        dup_pairs.append((duplicate, canonical, float(sim[j])))

        return dup_pairs

    # ── Stats ─────────────────────────────────────────────────────────────────

    def get_stats(self) -> dict:
        count = self._col.count()
        return {
            "embedded_count": count,
            "collection":     self.COLLECTION_NAME,
        }

    def delete(self, req_ids: list[str]):
        self._col.delete(ids=req_ids)

    @property
    def count(self) -> int:
        return self._col.count()
