"""
core/library.py
===============
Generic PDF document library manager.

Handles:
  - Recursive folder scanning and single-file addition
  - Document-type auto-detection (UFC, NFPA, IBC, ASHRAE, MIL-SPEC, OSHA, etc.)
  - Per-document metadata (source label, category, discipline, keyword profile)
  - Keyword extraction profiles (different standards use different modal verbs)
  - Persistence of library state in the project SQLite database
"""

from __future__ import annotations
import os
import re
import hashlib
import datetime
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional


# ── Keyword profiles ──────────────────────────────────────────────────────────
# Each profile defines which patterns to search for when extracting requirements.
# Profiles are stored by name and can be assigned per-document.

@dataclass
class KeywordProfile:
    name: str
    description: str
    patterns: list[str]          # regex patterns
    min_words: int = 6

    def to_regex(self) -> str:
        return '|'.join(self.patterns)


BUILTIN_PROFILES: dict[str, KeywordProfile] = {
    "ufc_standard": KeywordProfile(
        name="ufc_standard",
        description="DoD UFC / military standard (shall/must/will/required)",
        patterns=[
            r'\bshall not\b', r'\bshall\b',
            r'\bmust not\b',  r'\bmust\b',
            r'\brequired to\b', r'\bis required\b', r'\bare required\b',
            r'\bwill\b',
        ],
        min_words=8,
    ),
    "building_code": KeywordProfile(
        name="building_code",
        description="IBC/IFC/IRC/IEBC building codes (shall/must/is required/is prohibited)",
        patterns=[
            r'\bshall not\b', r'\bshall\b',
            r'\bmust not\b',  r'\bmust\b',
            r'\bis required\b', r'\bare required\b',
            r'\bis prohibited\b', r'\bare prohibited\b',
            r'\bshall be prohibited\b',
            r'\bit is unlawful\b',
        ],
        min_words=6,
    ),
    "nfpa": KeywordProfile(
        name="nfpa",
        description="NFPA codes and standards (shall/shall not/required/prohibited)",
        patterns=[
            r'\bshall not\b', r'\bshall\b',
            r'\brequired\b',
            r'\bprohibited\b',
            r'\bpermitted\b',
            r'\bshall be installed\b',
        ],
        min_words=6,
    ),
    "ashrae": KeywordProfile(
        name="ashrae",
        description="ASHRAE standards (shall/should/must/is required)",
        patterns=[
            r'\bshall not\b', r'\bshall\b',
            r'\bmust\b',
            r'\bshould\b',
            r'\bis required\b',
        ],
        min_words=6,
    ),
    "osha": KeywordProfile(
        name="osha",
        description="OSHA / CFR regulatory text (shall/must/is required/employer shall)",
        patterns=[
            r'\bshall\b', r'\bmust\b',
            r'\bis required\b', r'\bare required\b',
            r'\bemployer shall\b', r'\bemployees shall\b',
            r'\bshall be provided\b', r'\bshall be equipped\b',
            r'\bno person shall\b',
        ],
        min_words=6,
    ),
    "mil_spec": KeywordProfile(
        name="mil_spec",
        description="MIL-SPEC / MIL-STD documents (shall/should/will/may)",
        patterns=[
            r'\bshall\b', r'\bshould\b',
            r'\bwill\b',  r'\bmay\b',
            r'\bmust\b',
        ],
        min_words=8,
    ),
    "iso_iec": KeywordProfile(
        name="iso_iec",
        description="ISO/IEC standards (shall/shall not/should/may/need not)",
        patterns=[
            r'\bshall not\b', r'\bshall\b',
            r'\bshould not\b', r'\bshould\b',
            r'\bmay\b',
            r'\bneed not\b',
        ],
        min_words=6,
    ),
    "permissive": KeywordProfile(
        name="permissive",
        description="Catch-all — any modal requirement language (broadest extraction)",
        patterns=[
            r'\bshall\b', r'\bmust\b', r'\bwill\b',
            r'\bshould\b', r'\bmay\b',
            r'\brequired\b', r'\bprohibited\b',
            r'\bpermitted\b', r'\bauthorized\b',
            r'\bshall not\b', r'\bmust not\b',
        ],
        min_words=5,
    ),
}


# ── Document type detection ────────────────────────────────────────────────────

@dataclass
class DocTypeRule:
    doc_type: str
    display_name: str
    profile: str              # default keyword profile name
    category: str             # default category / discipline bucket
    patterns: list[str]       # regex patterns matched against filename + early text


DOC_TYPE_RULES: list[DocTypeRule] = [
    DocTypeRule("ufc",    "UFC / DoD Criteria",     "ufc_standard",  "General",
                [r'\bufc[_\s-]\d', r'unified facilities criteria', r'\bufs[_\s-]\d']),
    DocTypeRule("nfpa",   "NFPA Code/Standard",     "nfpa",          "Fire Protection",
                [r'\bnfpa\s*\d', r'national fire protection', r'nfpa\s+\d+']),
    DocTypeRule("ibc",    "IBC / Building Code",    "building_code", "Architecture",
                [r'\bibc\b', r'international building code', r'international fire code',
                 r'international residential code', r'\bifc\b', r'\birc\b', r'\biebc\b']),
    DocTypeRule("ashrae", "ASHRAE Standard",         "ashrae",        "Mechanical",
                [r'\bashrae\b', r'american society of heating']),
    DocTypeRule("osha",   "OSHA / CFR Regulation",  "osha",          "Safety",
                [r'\bosha\b', r'29\s*cfr', r'occupational safety', r'code of federal regulations']),
    DocTypeRule("mil",    "MIL-SPEC / MIL-STD",     "mil_spec",      "General",
                [r'\bmil[_\-](?:spec|std|prf|dtl|hdbk)\b', r'military standard',
                 r'military specification']),
    DocTypeRule("iso",    "ISO / IEC Standard",      "iso_iec",       "General",
                [r'\biso\s*\d{4}', r'\biec\s*\d{4}', r'international organization for standardization']),
    DocTypeRule("asce",   "ASCE Standard",           "ufc_standard",  "Structural",
                [r'\basce\s*\d', r'american society of civil engineers']),
    DocTypeRule("astm",   "ASTM Standard",           "ufc_standard",  "General",
                [r'\bastm\s+[a-z]\d', r'american society for testing']),
    DocTypeRule("aws",    "AWS Welding Standard",    "ufc_standard",  "Structural",
                [r'\baws\s+[dbd]\d', r'american welding society']),
    DocTypeRule("aci",    "ACI Concrete Standard",   "ufc_standard",  "Structural",
                [r'\baci\s+\d{3}', r'american concrete institute']),
    DocTypeRule("aisc",   "AISC Steel Standard",     "ufc_standard",  "Structural",
                [r'\baisc\b', r'american institute of steel construction']),
    DocTypeRule("ansi",   "ANSI Standard",           "iso_iec",       "General",
                [r'\bansi\b', r'american national standards']),
    DocTypeRule("ieee",   "IEEE Standard",           "iso_iec",       "Electrical",
                [r'\bieee\s+std\b', r'\bieee\s+\d{3}', r'institute of electrical']),
    DocTypeRule("generic","Generic PDF",             "permissive",    "Unassigned", []),
]


def detect_doc_type(filename: str, first_page_text: str = "") -> DocTypeRule:
    """
    Detect document type by matching filename and early text against known patterns.
    Falls back to 'generic' if nothing matches.
    """
    haystack = (filename + " " + first_page_text[:2000]).lower()
    for rule in DOC_TYPE_RULES[:-1]:   # skip generic sentinel
        for pattern in rule.patterns:
            if re.search(pattern, haystack, re.IGNORECASE):
                return rule
    return DOC_TYPE_RULES[-1]          # generic


# ── Document record ────────────────────────────────────────────────────────────

@dataclass
class LibraryDocument:
    """Represents one PDF in the user's library."""
    doc_id: str                         # SHA256[:16] of absolute path
    path: str                           # absolute path to PDF file
    filename: str
    display_name: str                   # user-editable friendly name
    doc_type: str                       # detected type key
    doc_type_display: str               # human-readable type
    source_label: str                   # e.g. "NFPA 13", "IBC 2021", "OSHA 29 CFR 1926"
    category: str                       # Architecture / Structural / etc.
    keyword_profile: str                # profile name
    discipline: str                     # default discipline for extracted reqs
    enabled: bool = True                # included in extraction?
    file_hash: str = ""
    file_size_bytes: int = 0
    page_count: int = 0
    req_count: int = 0                  # last known extracted count
    added_at: str = ""
    notes: str = ""
    folder_root: str = ""               # original scan root (if added via folder)

    @classmethod
    def from_path(cls, path: Path, first_page_text: str = "") -> "LibraryDocument":
        rule = detect_doc_type(path.name, first_page_text)
        doc_id = hashlib.sha256(str(path.resolve()).encode()).hexdigest()[:16]
        return cls(
            doc_id       = doc_id,
            path         = str(path.resolve()),
            filename     = path.name,
            display_name = path.stem.replace("_"," ").replace("-"," "),
            doc_type     = rule.doc_type,
            doc_type_display = rule.display_name,
            source_label = path.stem.upper()[:40],
            category     = rule.category,
            keyword_profile = rule.profile,
            discipline   = rule.category,
            file_size_bytes = path.stat().st_size if path.exists() else 0,
            added_at     = datetime.datetime.utcnow().isoformat(),
        )

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "LibraryDocument":
        return cls(**{k: v for k, v in d.items()
                      if k in cls.__dataclass_fields__})

    def exists(self) -> bool:
        return Path(self.path).exists()

    def get_profile(self) -> KeywordProfile:
        return BUILTIN_PROFILES.get(
            self.keyword_profile,
            BUILTIN_PROFILES["permissive"]
        )

    def as_extraction_doc(self) -> dict:
        """Format compatible with ExtractionWorker's doc dict."""
        return {
            "id":              self.source_label or self.filename,
            "source_label":    self.source_label,
            "filename":        self.filename,
            "filepath":        self.path,          # absolute path — skip downloads dir
            "category":        self.category,
            "discipline":      self.discipline,
            "doc_type":        self.doc_type,
            "keyword_profile": self.keyword_profile,
            "display_name":    self.display_name,
        }


# ── Library manager ────────────────────────────────────────────────────────────

class LibraryManager:
    """
    Manages a collection of LibraryDocument objects.
    Persists to the project SQLite database (documents_library table).
    Also holds in-memory list for UI binding.
    """

    def __init__(self, db=None):
        self._db   = db
        self._docs: dict[str, LibraryDocument] = {}
        if db:
            self._init_db_table()
            self._load_from_db()

    # ── DB schema ─────────────────────────────────────────────────────────────

    def _init_db_table(self):
        with self._db._conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS library_documents (
                    doc_id          TEXT PRIMARY KEY,
                    path            TEXT NOT NULL,
                    filename        TEXT,
                    display_name    TEXT,
                    doc_type        TEXT,
                    doc_type_display TEXT,
                    source_label    TEXT,
                    category        TEXT,
                    keyword_profile TEXT,
                    discipline      TEXT,
                    enabled         INTEGER DEFAULT 1,
                    file_hash       TEXT,
                    file_size_bytes INTEGER,
                    page_count      INTEGER DEFAULT 0,
                    req_count       INTEGER DEFAULT 0,
                    added_at        TEXT,
                    notes           TEXT DEFAULT '',
                    folder_root     TEXT DEFAULT ''
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS keyword_profiles (
                    name        TEXT PRIMARY KEY,
                    description TEXT,
                    patterns    TEXT,   -- JSON array
                    min_words   INTEGER DEFAULT 6
                )
            """)
            # Seed builtin profiles
            import json
            for p in BUILTIN_PROFILES.values():
                conn.execute("""
                    INSERT OR IGNORE INTO keyword_profiles
                    (name, description, patterns, min_words)
                    VALUES (?,?,?,?)
                """, (p.name, p.description, json.dumps(p.patterns), p.min_words))

    def _load_from_db(self):
        with self._db._conn() as conn:
            rows = conn.execute("SELECT * FROM library_documents").fetchall()
        for row in rows:
            d = dict(row)
            d["enabled"] = bool(d.get("enabled", 1))
            try:
                self._docs[d["doc_id"]] = LibraryDocument.from_dict(d)
            except Exception:
                pass

    def _save_doc(self, doc: LibraryDocument):
        with self._db._conn() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO library_documents
                (doc_id, path, filename, display_name, doc_type, doc_type_display,
                 source_label, category, keyword_profile, discipline, enabled,
                 file_hash, file_size_bytes, page_count, req_count,
                 added_at, notes, folder_root)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                doc.doc_id, doc.path, doc.filename, doc.display_name,
                doc.doc_type, doc.doc_type_display, doc.source_label,
                doc.category, doc.keyword_profile, doc.discipline,
                1 if doc.enabled else 0,
                doc.file_hash, doc.file_size_bytes, doc.page_count,
                doc.req_count, doc.added_at, doc.notes, doc.folder_root,
            ))

    def _delete_doc(self, doc_id: str):
        with self._db._conn() as conn:
            conn.execute("DELETE FROM library_documents WHERE doc_id=?", (doc_id,))

    # ── Public API ────────────────────────────────────────────────────────────

    def add_file(self, path: Path, folder_root: str = "") -> LibraryDocument:
        """Add a single PDF. Returns the LibraryDocument (possibly existing)."""
        doc_id = hashlib.sha256(str(path.resolve()).encode()).hexdigest()[:16]
        if doc_id in self._docs:
            return self._docs[doc_id]
        # Peek at first page text for type detection
        first_text = self._peek_text(path)
        doc = LibraryDocument.from_path(path, first_text)
        doc.folder_root = folder_root
        if path.exists():
            doc.file_hash = hashlib.sha256(
                path.read_bytes()
            ).hexdigest()[:16]
        self._docs[doc_id] = doc
        if self._db:
            self._save_doc(doc)
        return doc

    def add_folder(self, folder: Path, recursive: bool = True,
                   progress_cb=None) -> list[LibraryDocument]:
        """Scan folder for PDFs and add all found files."""
        pattern = "**/*.pdf" if recursive else "*.pdf"
        paths   = sorted(folder.glob(pattern))
        added   = []
        for i, p in enumerate(paths):
            doc = self.add_file(p, folder_root=str(folder))
            added.append(doc)
            if progress_cb:
                progress_cb(i+1, len(paths), p.name)
        return added

    def update_doc(self, doc: LibraryDocument):
        self._docs[doc.doc_id] = doc
        if self._db:
            self._save_doc(doc)

    def remove_doc(self, doc_id: str):
        self._docs.pop(doc_id, None)
        if self._db:
            self._delete_doc(doc_id)

    def get_all(self) -> list[LibraryDocument]:
        return list(self._docs.values())

    def get_enabled(self) -> list[LibraryDocument]:
        return [d for d in self._docs.values() if d.enabled and d.exists()]

    def get_by_id(self, doc_id: str) -> Optional[LibraryDocument]:
        return self._docs.get(doc_id)

    def count(self) -> int:
        return len(self._docs)

    def enabled_count(self) -> int:
        return sum(1 for d in self._docs.values() if d.enabled)

    # ── Custom keyword profiles ───────────────────────────────────────────────

    def save_custom_profile(self, profile: KeywordProfile):
        BUILTIN_PROFILES[profile.name] = profile
        if self._db:
            import json
            with self._db._conn() as conn:
                conn.execute("""
                    INSERT OR REPLACE INTO keyword_profiles
                    (name, description, patterns, min_words)
                    VALUES (?,?,?,?)
                """, (profile.name, profile.description,
                      json.dumps(profile.patterns), profile.min_words))

    def load_custom_profiles(self) -> list[KeywordProfile]:
        if not self._db:
            return list(BUILTIN_PROFILES.values())
        import json
        with self._db._conn() as conn:
            rows = conn.execute("SELECT * FROM keyword_profiles").fetchall()
        profiles = []
        for row in rows:
            d = dict(row)
            p = KeywordProfile(
                name=d["name"], description=d["description"],
                patterns=json.loads(d["patterns"]),
                min_words=d.get("min_words", 6),
            )
            BUILTIN_PROFILES[p.name] = p
            profiles.append(p)
        return profiles

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _peek_text(path: Path, max_chars: int = 3000) -> str:
        """Extract first page text for type detection without full parse."""
        try:
            import pdfplumber
            with pdfplumber.open(str(path)) as pdf:
                if pdf.pages:
                    return (pdf.pages[0].extract_text() or "")[:max_chars]
        except Exception:
            pass
        return ""
