"""
core/incose.py
==============
Heuristic INCOSE / ISO 29148 requirement quality scoring.

Runs entirely locally (no LLM) as a fast pre-pass before optional
LLM-based scoring.  The LLM scorer in llm_client.py is more accurate
but slower — these heuristics run at extraction time.

Attributes scored (0.0 – 1.0):
  singular      – one requirement per statement
  verifiable    – objectively testable
  unambiguous   – no vague language
  complete      – no TBDs, placeholders, or missing actors
  traceable     – can be referenced (has section/context)
  feasible      – no physically impossible language
"""

from __future__ import annotations
import re
from dataclasses import dataclass, field


# ── Vocabulary lists ──────────────────────────────────────────────────────────

VAGUE_TERMS = {
    "adequate","sufficient","appropriate","reasonable","proper","suitable",
    "necessary","timely","efficient","effective","robust","flexible","user-friendly",
    "easy","simple","fast","minimal","acceptable","as needed","as required",
    "best","optimal","maximum feasible","normal","standard","typical",
    "whenever possible","where practicable","to the extent possible",
}

COMPOUND_CONNECTORS = re.compile(
    r'\b(and|or)\b(?=.{0,120}\b(shall|must|will|required)\b)',
    re.IGNORECASE
)

AND_OR_IN_SHALL = re.compile(
    r'\bshall\b.{0,200}\b(and|;)\b.{0,200}\bshall\b',
    re.IGNORECASE | re.DOTALL
)

MEASURABLE_PATTERN = re.compile(
    r'(\d+[\.,]?\d*\s*(%|percent|°[CFK]|psi|kPa|MPa|lbs?|kg|'
    r'ft|m|mm|in|inches|feet|meters|dB|lux|fc|cfm|gpm|kW|kVA|'
    r'Hz|V|A|ohm|BTU|J|N|min|max|≤|≥|<|>|±))',
    re.IGNORECASE
)

TBD_PATTERN = re.compile(
    r'\b(TBD|TBS|TBR|placeholder|to be determined|to be specified|'
    r'to be revised|N/A|not applicable)\b',
    re.IGNORECASE
)

PHYSICALLY_IMPOSSIBLE = re.compile(
    r'\b(100\s*%\s*reliable|zero\s*downtime|instantaneous(?:ly)?|'
    r'infinit(?:e|ely)|unlimited|no\s+downtime|always\s+available)\b',
    re.IGNORECASE
)

ACTOR_PATTERN = re.compile(
    r'\b(the\s+)?(system|facility|structure|building|contractor|'
    r'designer|engineer|roof|wall|floor|duct|pipe|circuit|panel|'
    r'equipment|installation|component|network|server|sensor|'
    r'generator|pump|valve)\b',
    re.IGNORECASE
)

SHALL_PATTERN = re.compile(r'\bshall\b', re.IGNORECASE)


@dataclass
class HeuristicScore:
    req_id:           str
    score_singular:   float = 0.0
    score_verifiable: float = 0.0
    score_unambiguous:float = 0.0
    score_complete:   float = 0.0
    score_traceable:  float = 0.0
    score_feasible:   float = 0.0
    incose_overall:   float = 0.0
    issues:           list  = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "req_id":            self.req_id,
            "score_singular":    round(self.score_singular, 3),
            "score_verifiable":  round(self.score_verifiable, 3),
            "score_unambiguous": round(self.score_unambiguous, 3),
            "score_complete":    round(self.score_complete, 3),
            "score_traceable":   round(self.score_traceable, 3),
            "score_feasible":    round(self.score_feasible, 3),
            "incose_overall":    round(self.incose_overall, 3),
        }


def score_requirement(req_id: str, text: str,
                      section: str = "") -> HeuristicScore:
    """
    Score a single requirement text using heuristics.
    section: current document section heading (improves traceability score).
    """
    s    = HeuristicScore(req_id=req_id)
    issues = []
    words  = text.split()
    n_words = len(words)
    lower  = text.lower()

    # ── Singular ──────────────────────────────────────────────────────────────
    # Penalise: multiple 'shall' instances, semicolons before shall,
    # compound connectors linking two requirements
    shall_count  = len(SHALL_PATTERN.findall(text))
    compound_hit = AND_OR_IN_SHALL.search(text) is not None
    semi_clauses = text.count(";")

    if shall_count > 2 or compound_hit:
        s.score_singular = 0.2
        issues.append("compound requirement (multiple shall clauses)")
    elif shall_count == 2 or semi_clauses >= 2:
        s.score_singular = 0.6
        issues.append("possibly compound")
    else:
        s.score_singular = 1.0

    # ── Verifiable ────────────────────────────────────────────────────────────
    # Positive: numeric thresholds, measurable units
    # Negative: vague terms, no metric at all
    vague_hits   = sum(1 for v in VAGUE_TERMS if v in lower)
    metric_hits  = len(MEASURABLE_PATTERN.findall(text))

    if vague_hits == 0 and metric_hits >= 1:
        s.score_verifiable = 1.0
    elif vague_hits == 0 and metric_hits == 0:
        s.score_verifiable = 0.7   # no metric but also no vague terms
    elif vague_hits == 1:
        s.score_verifiable = 0.5
        issues.append(f"vague term present")
    else:
        s.score_verifiable = max(0.1, 0.4 - (vague_hits - 1) * 0.15)
        issues.append(f"{vague_hits} vague terms")

    # ── Unambiguous ───────────────────────────────────────────────────────────
    # Vague terms are the primary driver; also "and/or" at decision points
    and_or_count = len(re.findall(r'\band/or\b', text, re.IGNORECASE))
    if vague_hits == 0 and and_or_count == 0:
        s.score_unambiguous = 1.0
    elif vague_hits + and_or_count <= 1:
        s.score_unambiguous = 0.7
    elif vague_hits + and_or_count <= 3:
        s.score_unambiguous = 0.4
        issues.append("multiple ambiguous terms")
    else:
        s.score_unambiguous = 0.2

    # ── Complete ──────────────────────────────────────────────────────────────
    # Penalise: TBD markers, missing actor, very short sentences
    tbd_hit   = TBD_PATTERN.search(text) is not None
    actor_hit = ACTOR_PATTERN.search(text) is not None
    if tbd_hit:
        s.score_complete = 0.1
        issues.append("TBD/placeholder present")
    elif not actor_hit:
        s.score_complete = 0.6
        issues.append("no clear actor/subject")
    elif n_words < 10:
        s.score_complete = 0.7
        issues.append("very short — possibly incomplete")
    else:
        s.score_complete = 1.0

    # ── Traceable ─────────────────────────────────────────────────────────────
    # Section headings, UFC references, and paragraph labels help traceability
    has_section  = bool(section and len(section) > 3)
    has_ref      = bool(re.search(
        r'(UFC|NFPA|ASHRAE|ASCE|IBC|NEC|ASTM|MIL-|DoD|para\.?|section)\s*[\d\-\.]+',
        text, re.IGNORECASE
    ))
    if has_section and has_ref:
        s.score_traceable = 1.0
    elif has_section or has_ref:
        s.score_traceable = 0.8
    else:
        s.score_traceable = 0.5
        issues.append("no section context or standard reference")

    # ── Feasible ──────────────────────────────────────────────────────────────
    impossible_hit = PHYSICALLY_IMPOSSIBLE.search(text) is not None
    if impossible_hit:
        s.score_feasible = 0.1
        issues.append("possibly infeasible (100% availability / zero downtime)")
    else:
        s.score_feasible = 1.0

    # ── Overall ───────────────────────────────────────────────────────────────
    scores = [s.score_singular, s.score_verifiable, s.score_unambiguous,
              s.score_complete, s.score_traceable, s.score_feasible]
    s.incose_overall = round(sum(scores) / len(scores), 3)
    s.issues         = issues
    return s


def score_batch(reqs: list[dict],
                progress_cb=None) -> list[HeuristicScore]:
    """
    reqs: list of dicts with at least req_id, text, (optional) section
    """
    results = []
    total   = len(reqs)
    for i, r in enumerate(reqs):
        hs = score_requirement(
            r["req_id"], r["text"], r.get("section","")
        )
        results.append(hs)
        if progress_cb and i % 100 == 0:
            progress_cb(i + 1, total)
    return results


def quality_summary(scores: list[HeuristicScore]) -> dict:
    """Aggregate statistics across a scored corpus."""
    if not scores:
        return {}
    attrs = ["score_singular","score_verifiable","score_unambiguous",
             "score_complete","score_traceable","score_feasible","incose_overall"]
    summary = {}
    for attr in attrs:
        vals = [getattr(s, attr) for s in scores]
        summary[attr] = {
            "mean": round(sum(vals)/len(vals), 3),
            "min":  round(min(vals), 3),
            "pct_above_0_8": round(
                sum(1 for v in vals if v >= 0.8) / len(vals), 3
            ),
        }
    return summary
