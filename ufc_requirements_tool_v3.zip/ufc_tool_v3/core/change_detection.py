"""
core/change_detection.py
========================
UFC edition change detection — compares requirements extracted from two
versions of the same document and classifies changes as:
  added / removed / modified / unchanged
"""

from __future__ import annotations
import hashlib
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Optional


@dataclass
class RequirementDiff:
    change_type: str          # "added" | "removed" | "modified" | "unchanged"
    req_id_old: Optional[str]
    req_id_new: Optional[str]
    text_old: Optional[str]
    text_new: Optional[str]
    similarity: float = 1.0   # 0–1 for "modified" entries


@dataclass
class DocumentDiff:
    filename: str
    old_hash: str
    new_hash: str
    added:    list[RequirementDiff] = field(default_factory=list)
    removed:  list[RequirementDiff] = field(default_factory=list)
    modified: list[RequirementDiff] = field(default_factory=list)
    unchanged: int = 0

    @property
    def summary(self) -> dict:
        return {
            "added":    len(self.added),
            "removed":  len(self.removed),
            "modified": len(self.modified),
            "unchanged": self.unchanged,
            "total_changes": len(self.added) + len(self.removed) + len(self.modified),
        }


def _content_hash(text: str) -> str:
    normalised = " ".join(text.lower().split())
    return hashlib.sha256(normalised.encode()).hexdigest()


def diff_requirement_sets(
    old_reqs: list[dict],
    new_reqs: list[dict],
    filename: str,
    old_file_hash: str,
    new_file_hash: str,
    similarity_threshold: float = 0.80,
) -> DocumentDiff:
    """
    Compare two lists of extracted requirements (old vs. new UFC edition).

    Strategy
    --------
    1. Exact match by content hash → unchanged
    2. Remaining old → try to find near-match in remaining new via
       SequenceMatcher ratio → modified if ratio >= threshold
    3. Leftovers: old = removed, new = added
    """
    result = DocumentDiff(
        filename=filename,
        old_hash=old_file_hash,
        new_hash=new_file_hash,
    )

    # Index by content hash
    old_by_hash = {_content_hash(r["text"]): r for r in old_reqs}
    new_by_hash = {_content_hash(r["text"]): r for r in new_reqs}

    # Step 1 — exact matches
    common_hashes   = set(old_by_hash) & set(new_by_hash)
    result.unchanged = len(common_hashes)

    remaining_old = {h: r for h, r in old_by_hash.items() if h not in common_hashes}
    remaining_new = {h: r for h, r in new_by_hash.items() if h not in common_hashes}

    # Step 2 — near-matches
    used_new_hashes: set[str] = set()

    for old_hash, old_r in remaining_old.items():
        best_ratio  = 0.0
        best_new_h  = None
        best_new_r  = None

        for new_hash, new_r in remaining_new.items():
            if new_hash in used_new_hashes:
                continue
            ratio = SequenceMatcher(
                None, old_r["text"], new_r["text"]
            ).ratio()
            if ratio > best_ratio:
                best_ratio = ratio
                best_new_h = new_hash
                best_new_r = new_r

        if best_ratio >= similarity_threshold and best_new_r is not None:
            used_new_hashes.add(best_new_h)
            result.modified.append(RequirementDiff(
                change_type="modified",
                req_id_old  = old_r.get("req_id"),
                req_id_new  = best_new_r.get("req_id"),
                text_old    = old_r["text"],
                text_new    = best_new_r["text"],
                similarity  = round(best_ratio, 3),
            ))
        else:
            result.removed.append(RequirementDiff(
                change_type="removed",
                req_id_old  = old_r.get("req_id"),
                req_id_new  = None,
                text_old    = old_r["text"],
                text_new    = None,
            ))

    # Step 3 — additions
    for new_hash, new_r in remaining_new.items():
        if new_hash not in used_new_hashes and new_hash not in common_hashes:
            result.added.append(RequirementDiff(
                change_type="added",
                req_id_old  = None,
                req_id_new  = new_r.get("req_id"),
                text_old    = None,
                text_new    = new_r["text"],
            ))

    return result


def format_diff_report(diff: DocumentDiff) -> str:
    """Plain-text summary report for a DocumentDiff."""
    lines = [
        f"Change Detection Report — {diff.filename}",
        f"{'='*60}",
        f"  Added:    {len(diff.added)}",
        f"  Removed:  {len(diff.removed)}",
        f"  Modified: {len(diff.modified)}",
        f"  Unchanged:{diff.unchanged}",
        "",
    ]
    if diff.added:
        lines.append("── ADDED ──")
        for d in diff.added[:20]:
            lines.append(f"  + {d.req_id_new}: {d.text_new[:120]}…")
        if len(diff.added) > 20:
            lines.append(f"  … and {len(diff.added)-20} more")
        lines.append("")

    if diff.removed:
        lines.append("── REMOVED ──")
        for d in diff.removed[:20]:
            lines.append(f"  - {d.req_id_old}: {d.text_old[:120]}…")
        if len(diff.removed) > 20:
            lines.append(f"  … and {len(diff.removed)-20} more")
        lines.append("")

    if diff.modified:
        lines.append("── MODIFIED ──")
        for d in diff.modified[:20]:
            lines.append(f"  ~ {d.req_id_old} → {d.req_id_new} "
                         f"(similarity {d.similarity:.0%})")
            lines.append(f"    OLD: {d.text_old[:100]}…")
            lines.append(f"    NEW: {d.text_new[:100]}…")
        if len(diff.modified) > 20:
            lines.append(f"  … and {len(diff.modified)-20} more")

    return "\n".join(lines)
