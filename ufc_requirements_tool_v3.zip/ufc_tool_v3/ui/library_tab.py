"""
ui/library_tab.py
==================
Library Manager tab for UFC Requirements Tool v3.

Provides:
  - Folder picker (recursive scan) and individual file picker
  - QTreeWidget showing folder hierarchy with per-document checkboxes
  - Document metadata editor (source label, category, keyword profile,
    discipline, notes, enabled toggle)
  - "Detect Type" button — re-runs detect_doc_type against filename + first page
  - Keyword profile manager — view built-ins, add custom profiles
  - "Extract from Library" button — sends enabled docs to ExtractionWorker
  - Stats bar: count by document type
"""

from __future__ import annotations
import json
import re
from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, Signal, QThread, QTimer
from PySide6.QtGui import QColor, QFont, QIcon
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTreeWidget, QTreeWidgetItem, QSplitter, QGroupBox,
    QFormLayout, QLineEdit, QComboBox, QCheckBox, QTextEdit,
    QFileDialog, QMessageBox, QDialog, QDialogButtonBox,
    QProgressBar, QFrame, QTabWidget, QListWidget, QListWidgetItem,
    QSpinBox, QSizePolicy, QAbstractItemView, QApplication,
    QPlainTextEdit, QScrollArea
)

from core.library import (
    LibraryManager, LibraryDocument, KeywordProfile,
    BUILTIN_PROFILES, DOC_TYPE_RULES, detect_doc_type
)
from ui.theme import (
    DARK_BG, DARK_SURF, DARK_SURF2, DARK_BORD,
    TEXT_MAIN, TEXT_MUTED, ACCENT, ACCENT_HVR,
    SUCCESS, WARNING, ERROR
)

# ── Discipline options shared with ReviewTab ──────────────────────────────────
DISCIPLINE_LABELS = [
    "Unassigned", "Architecture", "Civil", "Structural", "Mechanical",
    "Electrical", "Fire Protection", "Environmental", "Security",
    "Communications", "Operations", "Naval", "Safety", "Other"
]

# ── Category options ──────────────────────────────────────────────────────────
CATEGORY_LABELS = [
    "General", "Architecture", "Structural", "Mechanical", "Electrical",
    "Fire Protection", "Environmental", "Safety", "Security",
    "Communications", "Naval", "Operations", "Other"
]

# ── Document type badge colours ───────────────────────────────────────────────
TYPE_COLOURS = {
    "ufc":      "#1a73e8",
    "nfpa":     "#e53935",
    "ibc":      "#8e24aa",
    "ashrae":   "#00897b",
    "osha":     "#f4511e",
    "mil":      "#546e7a",
    "iso":      "#039be5",
    "asce":     "#43a047",
    "astm":     "#6d4c41",
    "aws":      "#fb8c00",
    "aci":      "#c0ca33",
    "aisc":     "#00acc1",
    "ansi":     "#5e35b1",
    "ieee":     "#3949ab",
    "generic":  "#616161",
}

# Column indices for the tree widget
COL_NAME     = 0
COL_TYPE     = 1
COL_PROFILE  = 2
COL_PAGES    = 3
COL_REQS     = 4
COL_SIZE     = 5


# ─────────────────────────────────────────────────────────────────────────────
# Folder scan worker (runs in background to avoid freezing UI)
# ─────────────────────────────────────────────────────────────────────────────
class FolderScanWorker(QThread):
    progress  = Signal(int, int, str)   # current, total, filename
    finished  = Signal(list)            # list[LibraryDocument]
    error     = Signal(str)

    def __init__(self, lib: LibraryManager, folder: Path, parent=None):
        super().__init__(parent)
        self._lib    = lib
        self._folder = folder

    def run(self):
        try:
            docs = self._lib.add_folder(
                self._folder,
                recursive=True,
                progress_cb=lambda c, t, n: self.progress.emit(c, t, n)
            )
            self.finished.emit(docs)
        except Exception as exc:
            self.error.emit(str(exc))


# ─────────────────────────────────────────────────────────────────────────────
# Custom Profile Dialog
# ─────────────────────────────────────────────────────────────────────────────
class ProfileDialog(QDialog):
    """Create or edit a custom keyword profile."""

    def __init__(self, lib: LibraryManager, existing: Optional[KeywordProfile] = None,
                 parent=None):
        super().__init__(parent)
        self._lib      = lib
        self._existing = existing
        self.setWindowTitle("Custom Keyword Profile" if not existing else f"Edit: {existing.name}")
        self.setMinimumWidth(520)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        form = QFormLayout()
        self._name_edit = QLineEdit()
        self._name_edit.setPlaceholderText("my_custom_profile")
        self._desc_edit = QLineEdit()
        self._desc_edit.setPlaceholderText("Short description of this profile")
        self._min_words = QSpinBox(); self._min_words.setRange(3, 30); self._min_words.setValue(6)

        form.addRow("Name:", self._name_edit)
        form.addRow("Description:", self._desc_edit)
        form.addRow("Min words:", self._min_words)
        layout.addLayout(form)

        lbl = QLabel("Patterns (one regex per line):")
        lbl.setStyleSheet(f"color:{TEXT_MUTED};font-size:11px;")
        layout.addWidget(lbl)

        self._patterns = QPlainTextEdit()
        self._patterns.setPlaceholderText(
            r"\bshall\b" + "\n" +
            r"\bmust\b" + "\n" +
            r"\bis required\b"
        )
        self._patterns.setMinimumHeight(140)
        layout.addWidget(self._patterns)

        if self._existing:
            self._name_edit.setText(self._existing.name)
            self._desc_edit.setText(self._existing.description)
            self._min_words.setValue(self._existing.min_words)
            self._patterns.setPlainText("\n".join(self._existing.patterns))
            if self._existing.name in BUILTIN_PROFILES and \
               self._existing.name in [p.name for p in BUILTIN_PROFILES.values()
                                        if p.name == self._existing.name]:
                self._name_edit.setReadOnly(True)

        bb = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        bb.accepted.connect(self._save)
        bb.rejected.connect(self.reject)
        layout.addWidget(bb)

    def _save(self):
        name = self._name_edit.text().strip()
        if not name or not re.match(r'^[\w_]+$', name):
            QMessageBox.warning(self, "Invalid Name",
                "Profile name must be non-empty and use only letters, digits, underscores.")
            return
        raw_patterns = [
            ln.strip() for ln in self._patterns.toPlainText().splitlines()
            if ln.strip()
        ]
        if not raw_patterns:
            QMessageBox.warning(self, "No Patterns", "Add at least one regex pattern.")
            return
        # Validate patterns compile
        for p in raw_patterns:
            try:
                re.compile(p)
            except re.error as exc:
                QMessageBox.warning(self, "Bad Regex",
                    f"Pattern '{p}' is not valid regex:\n{exc}")
                return
        profile = KeywordProfile(
            name=name,
            description=self._desc_edit.text().strip(),
            patterns=raw_patterns,
            min_words=self._min_words.value(),
        )
        self._lib.save_custom_profile(profile)
        self.accept()


# ─────────────────────────────────────────────────────────────────────────────
# Profile Manager Dialog (view all, add/edit)
# ─────────────────────────────────────────────────────────────────────────────
class ProfileManagerDialog(QDialog):
    def __init__(self, lib: LibraryManager, parent=None):
        super().__init__(parent)
        self._lib = lib
        self.setWindowTitle("Keyword Profile Manager")
        self.setMinimumSize(700, 450)
        self._build_ui()
        self._refresh()

    def _build_ui(self):
        v = QVBoxLayout(self)
        v.setContentsMargins(12, 12, 12, 12)
        v.setSpacing(8)

        splitter = QSplitter(Qt.Horizontal)

        # Left: list of profiles
        left = QWidget()
        lv = QVBoxLayout(left); lv.setContentsMargins(0,0,0,0); lv.setSpacing(4)
        lv.addWidget(QLabel("Profiles:"))
        self._list = QListWidget()
        self._list.currentRowChanged.connect(self._on_select)
        lv.addWidget(self._list, 1)
        row = QHBoxLayout(); row.setSpacing(4)
        self._btn_new  = QPushButton("+ New")
        self._btn_edit = QPushButton("Edit")
        row.addWidget(self._btn_new); row.addWidget(self._btn_edit)
        lv.addLayout(row)
        splitter.addWidget(left)

        # Right: profile detail
        right = QWidget()
        rv = QVBoxLayout(right); rv.setContentsMargins(0,0,0,0); rv.setSpacing(4)
        rv.addWidget(QLabel("Detail:"))
        self._detail = QTextEdit()
        self._detail.setReadOnly(True)
        rv.addWidget(self._detail, 1)
        splitter.addWidget(right)
        splitter.setSizes([200, 400])

        v.addWidget(splitter, 1)
        bb = QDialogButtonBox(QDialogButtonBox.Close)
        bb.rejected.connect(self.reject)
        v.addWidget(bb)

        self._btn_new.clicked.connect(self._new_profile)
        self._btn_edit.clicked.connect(self._edit_profile)

    def _refresh(self):
        self._lib.load_custom_profiles()
        self._list.clear()
        for name, prof in BUILTIN_PROFILES.items():
            item = QListWidgetItem(name)
            item.setData(Qt.UserRole, name)
            self._list.addItem(item)
        if self._list.count():
            self._list.setCurrentRow(0)

    def _on_select(self, row):
        if row < 0:
            return
        name = self._list.item(row).data(Qt.UserRole)
        prof = BUILTIN_PROFILES.get(name)
        if not prof:
            return
        html = (
            f"<b>Name:</b> {prof.name}<br>"
            f"<b>Description:</b> {prof.description}<br>"
            f"<b>Min words:</b> {prof.min_words}<br>"
            f"<b>Patterns ({len(prof.patterns)}):</b><ul>"
            + "".join(f"<li><code>{p}</code></li>" for p in prof.patterns)
            + "</ul>"
        )
        self._detail.setHtml(html)

    def _new_profile(self):
        dlg = ProfileDialog(self._lib, parent=self)
        if dlg.exec() == QDialog.Accepted:
            self._refresh()

    def _edit_profile(self):
        row = self._list.currentRow()
        if row < 0:
            return
        name = self._list.item(row).data(Qt.UserRole)
        prof = BUILTIN_PROFILES.get(name)
        if not prof:
            return
        dlg = ProfileDialog(self._lib, existing=prof, parent=self)
        if dlg.exec() == QDialog.Accepted:
            self._refresh()


# ─────────────────────────────────────────────────────────────────────────────
# LibraryTab — main widget
# ─────────────────────────────────────────────────────────────────────────────
class LibraryTab(QWidget):
    """
    Tab for managing an arbitrary PDF document library.
    Emits `extraction_ready` with a list of requirement dicts when extraction
    finishes — wire this to MainWindow._on_reqs_ready.
    """
    extraction_ready = Signal(list)   # list[dict] — same format as ExtractTab

    def __init__(self, lib: LibraryManager, config, db, parent=None):
        super().__init__(parent)
        self._lib    = lib
        self._config = config
        self._db     = db
        self._scan_worker: Optional[FolderScanWorker] = None
        self._ext_worker  = None
        self._build_ui()
        self._refresh_tree()

    # ── UI construction ───────────────────────────────────────────────────────

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(6)

        # ── Toolbar row ───────────────────────────────────────────────────────
        toolbar = QHBoxLayout()
        toolbar.setSpacing(6)

        self._btn_add_folder = QPushButton("  Add Folder…")
        self._btn_add_folder.setObjectName("primary")
        self._btn_add_folder.setToolTip("Recursively scan a folder and add all PDFs")
        self._btn_add_folder.clicked.connect(self._pick_folder)

        self._btn_add_files = QPushButton("  Add Files…")
        self._btn_add_files.setToolTip("Pick individual PDF files to add")
        self._btn_add_files.clicked.connect(self._pick_files)

        self._btn_remove = QPushButton("Remove")
        self._btn_remove.setToolTip("Remove selected document(s) from library (does not delete files)")
        self._btn_remove.clicked.connect(self._remove_selected)

        self._btn_detect = QPushButton("Detect Type")
        self._btn_detect.setToolTip("Re-run document type detection for selected item")
        self._btn_detect.clicked.connect(self._detect_selected)

        self._btn_profiles = QPushButton("Profiles…")
        self._btn_profiles.setToolTip("Manage keyword extraction profiles")
        self._btn_profiles.clicked.connect(self._open_profiles)

        self._btn_check_all   = QPushButton("Check All")
        self._btn_uncheck_all = QPushButton("Uncheck All")
        self._btn_check_all.clicked.connect(lambda: self._set_all_checked(True))
        self._btn_uncheck_all.clicked.connect(lambda: self._set_all_checked(False))

        self._btn_extract = QPushButton("  Extract from Library")
        self._btn_extract.setObjectName("primary")
        self._btn_extract.setToolTip("Run requirement extraction on all checked documents")
        self._btn_extract.clicked.connect(self._run_extraction)

        for btn in [self._btn_add_folder, self._btn_add_files, self._btn_remove,
                    self._btn_detect, self._btn_profiles,
                    self._btn_check_all, self._btn_uncheck_all]:
            toolbar.addWidget(btn)
        toolbar.addStretch()
        toolbar.addWidget(self._btn_extract)
        root.addLayout(toolbar)

        # ── Progress bar (hidden when idle) ───────────────────────────────────
        self._progress = QProgressBar()
        self._progress.setVisible(False)
        self._progress.setFixedHeight(6)
        self._progress.setTextVisible(False)
        root.addWidget(self._progress)

        # ── Main splitter: tree | detail ──────────────────────────────────────
        splitter = QSplitter(Qt.Horizontal)
        splitter.setHandleWidth(4)

        # Left pane: tree + stats
        left_pane = QWidget()
        left_v = QVBoxLayout(left_pane)
        left_v.setContentsMargins(0, 0, 0, 0)
        left_v.setSpacing(4)

        self._tree = QTreeWidget()
        self._tree.setColumnCount(6)
        self._tree.setHeaderLabels(["Document", "Type", "Profile", "Pages", "Reqs", "Size"])
        self._tree.header().setStretchLastSection(False)
        self._tree.setColumnWidth(COL_NAME,    300)
        self._tree.setColumnWidth(COL_TYPE,    120)
        self._tree.setColumnWidth(COL_PROFILE, 110)
        self._tree.setColumnWidth(COL_PAGES,    50)
        self._tree.setColumnWidth(COL_REQS,     50)
        self._tree.setColumnWidth(COL_SIZE,     70)
        self._tree.setAlternatingRowColors(True)
        self._tree.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self._tree.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._tree.itemChanged.connect(self._on_item_check_changed)
        self._tree.itemSelectionChanged.connect(self._on_selection_changed)
        self._tree.setSortingEnabled(True)
        left_v.addWidget(self._tree, 1)

        # Stats bar
        self._stats_label = QLabel("No documents in library.")
        self._stats_label.setStyleSheet(
            f"color:{TEXT_MUTED};font-size:11px;padding:2px 4px;"
        )
        left_v.addWidget(self._stats_label)

        splitter.addWidget(left_pane)

        # Right pane: document metadata editor
        right_pane = QWidget()
        right_pane.setMinimumWidth(280)
        right_v = QVBoxLayout(right_pane)
        right_v.setContentsMargins(4, 0, 0, 0)
        right_v.setSpacing(6)

        detail_hdr = QLabel("Document Properties")
        detail_hdr.setStyleSheet(
            f"color:{ACCENT};font-weight:700;font-size:13px;padding:4px 0;"
        )
        right_v.addWidget(detail_hdr)

        grp = QGroupBox()
        grp.setStyleSheet(f"QGroupBox{{border:1px solid {DARK_BORD};border-radius:4px;padding:8px;}}")
        form = QFormLayout(grp)
        form.setSpacing(8)
        form.setLabelAlignment(Qt.AlignRight)

        self._ed_path        = QLineEdit(); self._ed_path.setReadOnly(True)
        self._ed_name        = QLineEdit()
        self._ed_source      = QLineEdit()
        self._ed_source.setPlaceholderText("e.g. NFPA 13 2022")
        self._ed_type        = QLineEdit(); self._ed_type.setReadOnly(True)
        self._ed_category    = QComboBox(); self._ed_category.addItems(CATEGORY_LABELS)
        self._ed_discipline  = QComboBox(); self._ed_discipline.addItems(DISCIPLINE_LABELS)
        self._ed_profile     = QComboBox()
        self._ed_enabled     = QCheckBox("Include in extraction")
        self._ed_notes       = QTextEdit()
        self._ed_notes.setPlaceholderText("Notes, version info, applicable sections…")
        self._ed_notes.setMaximumHeight(80)

        self._btn_apply_meta = QPushButton("Apply")
        self._btn_apply_meta.setObjectName("primary")
        self._btn_apply_meta.clicked.connect(self._apply_metadata)

        form.addRow("File:",        self._ed_path)
        form.addRow("Display Name:", self._ed_name)
        form.addRow("Source Label:", self._ed_source)
        form.addRow("Detected Type:", self._ed_type)
        form.addRow("Category:",    self._ed_category)
        form.addRow("Discipline:",  self._ed_discipline)
        form.addRow("Profile:",     self._ed_profile)
        form.addRow("",             self._ed_enabled)
        form.addRow("Notes:",       self._ed_notes)
        form.addRow("",             self._btn_apply_meta)

        right_v.addWidget(grp)
        right_v.addStretch()

        splitter.addWidget(right_pane)
        splitter.setSizes([620, 300])
        root.addWidget(splitter, 1)

        # ── Extraction status label ───────────────────────────────────────────
        self._ext_status = QLabel("")
        self._ext_status.setStyleSheet(f"color:{TEXT_MUTED};font-size:11px;")
        root.addWidget(self._ext_status)

        # Populate profile combo
        self._refresh_profile_combo()

        # Disable detail panel until selection
        self._set_detail_enabled(False)

    # ── Profile combo helpers ─────────────────────────────────────────────────

    def _refresh_profile_combo(self):
        current = self._ed_profile.currentText()
        self._ed_profile.clear()
        self._lib.load_custom_profiles()
        for name in BUILTIN_PROFILES:
            self._ed_profile.addItem(name)
        idx = self._ed_profile.findText(current)
        if idx >= 0:
            self._ed_profile.setCurrentIndex(idx)

    # ── Tree building ─────────────────────────────────────────────────────────

    def _refresh_tree(self):
        """Rebuild the entire tree from LibraryManager state."""
        self._tree.blockSignals(True)
        self._tree.clear()

        docs = self._lib.get_all()
        if not docs:
            self._update_stats([])
            self._tree.blockSignals(False)
            return

        # Group by folder_root — if blank, use parent folder of file
        groups: dict[str, list[LibraryDocument]] = {}
        for doc in docs:
            root = doc.folder_root or str(Path(doc.path).parent)
            groups.setdefault(root, []).append(doc)

        for root_path, group_docs in sorted(groups.items()):
            root_item = QTreeWidgetItem(self._tree)
            root_item.setText(COL_NAME, Path(root_path).name or root_path)
            root_item.setData(COL_NAME, Qt.UserRole, None)   # marks as folder node
            root_item.setExpanded(True)
            root_item.setFlags(root_item.flags() & ~Qt.ItemIsUserCheckable)
            root_item.setForeground(COL_NAME, QColor(ACCENT))
            font = root_item.font(COL_NAME)
            font.setBold(True)
            root_item.setFont(COL_NAME, font)
            root_item.setText(COL_TYPE, f"{len(group_docs)} docs")

            for doc in sorted(group_docs, key=lambda d: d.filename.lower()):
                self._add_doc_item(root_item, doc)

        self._tree.expandAll()
        self._update_stats(docs)
        self._tree.blockSignals(False)

    def _add_doc_item(self, parent: QTreeWidgetItem, doc: LibraryDocument) -> QTreeWidgetItem:
        item = QTreeWidgetItem(parent)
        item.setData(COL_NAME, Qt.UserRole, doc.doc_id)
        item.setText(COL_NAME, doc.display_name or doc.filename)
        item.setToolTip(COL_NAME, doc.path)
        item.setText(COL_TYPE, doc.doc_type_display)
        item.setForeground(COL_TYPE, QColor(TYPE_COLOURS.get(doc.doc_type, "#616161")))
        item.setText(COL_PROFILE, doc.keyword_profile)
        item.setText(COL_PAGES,   str(doc.page_count) if doc.page_count else "—")
        item.setText(COL_REQS,    str(doc.req_count)  if doc.req_count  else "—")

        size_kb = doc.file_size_bytes / 1024
        if size_kb > 1024:
            item.setText(COL_SIZE, f"{size_kb/1024:.1f} MB")
        else:
            item.setText(COL_SIZE, f"{size_kb:.0f} KB")

        check_state = Qt.Checked if doc.enabled else Qt.Unchecked
        item.setCheckState(COL_NAME, check_state)

        if not doc.exists():
            item.setForeground(COL_NAME, QColor(ERROR))
            item.setToolTip(COL_NAME, f"File not found: {doc.path}")

        return item

    # ── Stats bar ─────────────────────────────────────────────────────────────

    def _update_stats(self, docs: list[LibraryDocument]):
        if not docs:
            self._stats_label.setText("No documents in library.")
            return
        total   = len(docs)
        enabled = sum(1 for d in docs if d.enabled)
        # Count by type
        type_counts: dict[str, int] = {}
        for d in docs:
            type_counts[d.doc_type] = type_counts.get(d.doc_type, 0) + 1
        type_str = "  |  ".join(
            f"{k.upper()}: {v}" for k, v in sorted(type_counts.items())
        )
        self._stats_label.setText(
            f"{total} documents ({enabled} checked for extraction)   |   {type_str}"
        )

    # ── Item check state sync ─────────────────────────────────────────────────

    def _on_item_check_changed(self, item: QTreeWidgetItem, column: int):
        if column != COL_NAME:
            return
        doc_id = item.data(COL_NAME, Qt.UserRole)
        if doc_id is None:
            return   # folder node
        doc = self._lib.get_by_id(doc_id)
        if not doc:
            return
        new_enabled = item.checkState(COL_NAME) == Qt.Checked
        if doc.enabled != new_enabled:
            doc.enabled = new_enabled
            self._lib.update_doc(doc)
            self._update_stats(self._lib.get_all())

    # ── Selection → populate detail panel ────────────────────────────────────

    def _on_selection_changed(self):
        selected = self._tree.selectedItems()
        # Find first doc-level item
        doc = None
        for item in selected:
            doc_id = item.data(COL_NAME, Qt.UserRole)
            if doc_id is not None:
                doc = self._lib.get_by_id(doc_id)
                break
        if doc:
            self._populate_detail(doc)
            self._set_detail_enabled(True)
        else:
            self._set_detail_enabled(False)

    def _populate_detail(self, doc: LibraryDocument):
        self._ed_path.setText(doc.path)
        self._ed_name.setText(doc.display_name)
        self._ed_source.setText(doc.source_label)
        self._ed_type.setText(f"{doc.doc_type_display}  [{doc.doc_type}]")
        idx = self._ed_category.findText(doc.category)
        self._ed_category.setCurrentIndex(idx if idx >= 0 else 0)
        idx = self._ed_discipline.findText(doc.discipline)
        self._ed_discipline.setCurrentIndex(idx if idx >= 0 else 0)
        idx = self._ed_profile.findText(doc.keyword_profile)
        if idx < 0:
            # Might be a custom profile not yet loaded
            self._refresh_profile_combo()
            idx = self._ed_profile.findText(doc.keyword_profile)
        self._ed_profile.setCurrentIndex(idx if idx >= 0 else 0)
        self._ed_enabled.setChecked(doc.enabled)
        self._ed_notes.setPlainText(doc.notes)

    def _set_detail_enabled(self, enabled: bool):
        for w in [self._ed_name, self._ed_source, self._ed_category,
                  self._ed_discipline, self._ed_profile, self._ed_enabled,
                  self._ed_notes, self._btn_apply_meta]:
            w.setEnabled(enabled)

    # ── Apply metadata edits ──────────────────────────────────────────────────

    def _apply_metadata(self):
        """Write edited metadata back to the selected doc and refresh tree."""
        selected = self._tree.selectedItems()
        doc_id   = None
        for item in selected:
            did = item.data(COL_NAME, Qt.UserRole)
            if did is not None:
                doc_id = did
                break
        if not doc_id:
            return
        doc = self._lib.get_by_id(doc_id)
        if not doc:
            return
        doc.display_name    = self._ed_name.text().strip() or doc.filename
        doc.source_label    = self._ed_source.text().strip() or doc.filename
        doc.category        = self._ed_category.currentText()
        doc.discipline      = self._ed_discipline.currentText()
        doc.keyword_profile = self._ed_profile.currentText()
        doc.enabled         = self._ed_enabled.isChecked()
        doc.notes           = self._ed_notes.toPlainText()
        self._lib.update_doc(doc)
        # Refresh the tree item in-place
        self._refresh_tree()

    # ── Folder / file pickers ─────────────────────────────────────────────────

    def _pick_folder(self):
        folder = QFileDialog.getExistingDirectory(
            self, "Select Folder Containing PDFs",
            str(Path.home())
        )
        if not folder:
            return
        folder_path = Path(folder)
        # Quick estimate
        pdf_count = len(list(folder_path.rglob("*.pdf")))
        if pdf_count == 0:
            QMessageBox.information(self, "No PDFs Found",
                f"No PDF files found in:\n{folder}")
            return
        if pdf_count > 200:
            reply = QMessageBox.question(
                self, "Large Folder",
                f"Found {pdf_count} PDF files. This may take a while.\nContinue?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return
        self._start_scan(folder_path)

    def _pick_files(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Select PDF Files",
            str(Path.home()),
            "PDF Files (*.pdf);;All Files (*)"
        )
        if not paths:
            return
        added = 0
        for p in paths:
            self._lib.add_file(Path(p))
            added += 1
        self._refresh_tree()
        self._ext_status.setText(f"Added {added} file(s) to library.")

    def _start_scan(self, folder: Path):
        self._btn_add_folder.setEnabled(False)
        self._btn_add_files.setEnabled(False)
        self._progress.setVisible(True)
        self._progress.setRange(0, 0)   # indeterminate spinner
        self._ext_status.setText(f"Scanning {folder.name}…")

        self._scan_worker = FolderScanWorker(self._lib, folder, parent=self)
        self._scan_worker.progress.connect(self._on_scan_progress)
        self._scan_worker.finished.connect(self._on_scan_done)
        self._scan_worker.error.connect(self._on_scan_error)
        self._scan_worker.start()

    def _on_scan_progress(self, current: int, total: int, name: str):
        self._progress.setRange(0, total)
        self._progress.setValue(current)
        self._ext_status.setText(f"Scanning {current}/{total}: {name}")

    def _on_scan_done(self, docs: list):
        self._progress.setVisible(False)
        self._btn_add_folder.setEnabled(True)
        self._btn_add_files.setEnabled(True)
        self._refresh_tree()
        self._ext_status.setText(
            f"Scan complete — {len(docs)} document(s) added to library."
        )

    def _on_scan_error(self, msg: str):
        self._progress.setVisible(False)
        self._btn_add_folder.setEnabled(True)
        self._btn_add_files.setEnabled(True)
        QMessageBox.critical(self, "Scan Error", f"Error scanning folder:\n{msg}")
        self._ext_status.setText("Scan failed.")

    # ── Remove ────────────────────────────────────────────────────────────────

    def _remove_selected(self):
        selected = [
            item for item in self._tree.selectedItems()
            if item.data(COL_NAME, Qt.UserRole) is not None
        ]
        if not selected:
            return
        reply = QMessageBox.question(
            self, "Remove Documents",
            f"Remove {len(selected)} document(s) from library?\n"
            "(Files will not be deleted from disk.)",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if reply != QMessageBox.Yes:
            return
        for item in selected:
            doc_id = item.data(COL_NAME, Qt.UserRole)
            if doc_id:
                self._lib.remove_doc(doc_id)
        self._refresh_tree()

    # ── Detect type ───────────────────────────────────────────────────────────

    def _detect_selected(self):
        selected = [
            item for item in self._tree.selectedItems()
            if item.data(COL_NAME, Qt.UserRole) is not None
        ]
        if not selected:
            QMessageBox.information(self, "Nothing Selected",
                "Select one or more documents first.")
            return
        changed = 0
        for item in selected:
            doc_id = item.data(COL_NAME, Qt.UserRole)
            doc = self._lib.get_by_id(doc_id)
            if not doc or not doc.exists():
                continue
            first_text = LibraryManager._peek_text(Path(doc.path))
            rule = detect_doc_type(doc.filename, first_text)
            doc.doc_type         = rule.doc_type
            doc.doc_type_display = rule.display_name
            doc.category         = rule.category
            doc.keyword_profile  = rule.profile
            self._lib.update_doc(doc)
            changed += 1
        self._refresh_tree()
        self._ext_status.setText(f"Re-detected type for {changed} document(s).")

    # ── Check/uncheck all ────────────────────────────────────────────────────

    def _set_all_checked(self, checked: bool):
        self._tree.blockSignals(True)
        for i in range(self._tree.topLevelItemCount()):
            folder_item = self._tree.topLevelItem(i)
            for j in range(folder_item.childCount()):
                child = folder_item.child(j)
                doc_id = child.data(COL_NAME, Qt.UserRole)
                if doc_id is None:
                    continue
                child.setCheckState(COL_NAME, Qt.Checked if checked else Qt.Unchecked)
                doc = self._lib.get_by_id(doc_id)
                if doc:
                    doc.enabled = checked
                    self._lib.update_doc(doc)
        self._tree.blockSignals(False)
        self._update_stats(self._lib.get_all())

    # ── Profile manager ───────────────────────────────────────────────────────

    def _open_profiles(self):
        dlg = ProfileManagerDialog(self._lib, parent=self)
        dlg.exec()
        self._refresh_profile_combo()

    # ── Extraction ────────────────────────────────────────────────────────────

    def _run_extraction(self):
        from ui.workers import ExtractionWorker

        docs = self._lib.get_enabled()
        if not docs:
            QMessageBox.information(self, "Nothing to Extract",
                "No documents are checked for extraction.\n"
                "Check at least one document and try again.")
            return

        # Confirm for large batches
        if len(docs) > 20:
            reply = QMessageBox.question(
                self, "Extract from Library",
                f"Extract requirements from {len(docs)} documents?\n"
                "This may take several minutes.",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return

        self._btn_extract.setEnabled(False)
        self._progress.setRange(0, len(docs))
        self._progress.setValue(0)
        self._progress.setVisible(True)
        self._ext_status.setText(f"Extracting from {len(docs)} document(s)…")

        # Convert to extraction dicts
        ext_docs = [d.as_extraction_doc() for d in docs]

        self._ext_worker = ExtractionWorker(
            docs     = ext_docs,
            config   = self._config.extraction,
            llm_cfg  = self._config.llm,
            emb_cfg  = self._config.embedding,
            db       = self._db,
        )
        self._ext_worker.progress.connect(self._on_ext_progress)
        self._ext_worker.finished.connect(self._on_ext_done)
        self._ext_worker.error.connect(self._on_ext_error)
        self._ext_worker.start()

    def _on_ext_progress(self, current: int, total: int, msg: str):
        self._progress.setRange(0, total)
        self._progress.setValue(current)
        self._ext_status.setText(msg)

    def _on_ext_done(self, reqs: list):
        self._progress.setVisible(False)
        self._btn_extract.setEnabled(True)

        # Update req_count in library for each doc that was processed
        doc_counts: dict[str, int] = {}
        for r in reqs:
            src = r.get("source", "")
            doc_counts[src] = doc_counts.get(src, 0) + 1

        for doc in self._lib.get_all():
            count = doc_counts.get(doc.source_label, 0)
            if count:
                doc.req_count = count
                self._lib.update_doc(doc)

        self._refresh_tree()
        self._ext_status.setText(
            f"Extraction complete — {len(reqs):,} requirement(s) found. "
            "Sending to Review tab…"
        )
        self.extraction_ready.emit(reqs)

    def _on_ext_error(self, msg: str):
        self._progress.setVisible(False)
        self._btn_extract.setEnabled(True)
        QMessageBox.critical(self, "Extraction Error", f"Error during extraction:\n{msg}")
        self._ext_status.setText("Extraction failed.")

    # ── Public helpers called from MainWindow ─────────────────────────────────

    def reload_library(self):
        """Re-read library state from DB and refresh tree (e.g., after project change)."""
        self._refresh_tree()
