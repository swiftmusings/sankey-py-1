"""
ui/settings_dialog.py
=====================
LLM endpoint, embedding, and extraction settings dialog.
"""

from __future__ import annotations
import json
from dataclasses import asdict
from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QTabWidget, QWidget,
    QGroupBox, QLabel, QLineEdit, QPushButton, QComboBox,
    QSpinBox, QDoubleSpinBox, QCheckBox, QDialogButtonBox,
    QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox,
    QFormLayout, QSlider
)
from PySide6.QtGui import QColor, QFont

from core.config import AppConfig, LLMConfig, EmbeddingConfig, ExtractionConfig
from ui.theme import ACCENT, TEXT_MUTED, SUCCESS, ERROR, DARK_SURF2


class LLMEndpointWidget(QWidget):
    """Editor for a single LLM endpoint config."""

    def __init__(self, cfg: LLMConfig, parent=None):
        super().__init__(parent)
        self._cfg = cfg
        layout = QFormLayout(self)
        layout.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)
        layout.setSpacing(10)

        self._name    = QLineEdit(cfg.name)
        self._url     = QLineEdit(cfg.base_url)
        self._key     = QLineEdit(cfg.api_key)
        self._model   = QLineEdit(cfg.model)
        self._model.setPlaceholderText("Leave blank = use loaded model (LM Studio/Ollama)")
        self._temp    = QDoubleSpinBox()
        self._temp.setRange(0.0, 2.0); self._temp.setSingleStep(0.05)
        self._temp.setValue(cfg.temperature); self._temp.setDecimals(2)
        self._tokens  = QSpinBox()
        self._tokens.setRange(64, 8192); self._tokens.setSingleStep(64)
        self._tokens.setValue(cfg.max_tokens)
        self._timeout = QSpinBox()
        self._timeout.setRange(10, 300); self._timeout.setSuffix(" s")
        self._timeout.setValue(cfg.timeout)
        self._enabled = QCheckBox("Enabled")
        self._enabled.setChecked(cfg.enabled)

        self._btn_test = QPushButton("Test Connection")
        self._btn_test.setObjectName("primary")
        self._lbl_status = QLabel("")
        self._lbl_status.setObjectName("subheader")

        layout.addRow("Name:",          self._name)
        layout.addRow("Base URL:",      self._url)
        layout.addRow("API Key:",       self._key)
        layout.addRow("Model:",         self._model)
        layout.addRow("Temperature:",   self._temp)
        layout.addRow("Max Tokens:",    self._tokens)
        layout.addRow("Timeout:",       self._timeout)
        layout.addRow("",               self._enabled)

        test_row = QHBoxLayout()
        test_row.addWidget(self._btn_test)
        test_row.addWidget(self._lbl_status)
        test_row.addStretch()
        layout.addRow("", test_row)

        self._btn_test.clicked.connect(self._test)

    def _test(self):
        cfg = self.get_config()
        self._lbl_status.setText("Testing…")
        try:
            from core.llm_client import LLMClient
            client = LLMClient(cfg)
            ok, msg = client.check_available()
            if ok:
                self._lbl_status.setText(f"✓ {msg}")
                self._lbl_status.setStyleSheet(f"color: {SUCCESS};")
            else:
                self._lbl_status.setText(f"✗ {msg}")
                self._lbl_status.setStyleSheet(f"color: {ERROR};")
        except Exception as e:
            self._lbl_status.setText(f"✗ {e}")
            self._lbl_status.setStyleSheet(f"color: {ERROR};")

    def get_config(self) -> LLMConfig:
        return LLMConfig(
            name        = self._name.text().strip(),
            base_url    = self._url.text().strip(),
            api_key     = self._key.text().strip(),
            model       = self._model.text().strip(),
            temperature = self._temp.value(),
            max_tokens  = self._tokens.value(),
            timeout     = self._timeout.value(),
            enabled     = self._enabled.isChecked(),
        )


class SettingsDialog(QDialog):
    """Full settings dialog with tabs for LLM, Embedding, and Extraction."""

    config_saved = Signal(AppConfig)

    def __init__(self, config: AppConfig, parent=None):
        super().__init__(parent)
        self._config = config
        self.setWindowTitle("Settings — UFC Requirements Tool")
        self.resize(700, 560)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        tabs = QTabWidget()

        # ── LLM Endpoints tab ──────────────────────────────────────────────
        llm_widget = QWidget()
        llm_layout = QVBoxLayout(llm_widget)

        # Endpoint selector
        sel_row = QHBoxLayout()
        sel_row.addWidget(QLabel("Active Endpoint:"))
        self._endpoint_combo = QComboBox()
        self._endpoint_combo.setMinimumWidth(200)
        sel_row.addWidget(self._endpoint_combo)
        self._btn_add_ep = QPushButton("Add Preset")
        self._btn_del_ep = QPushButton("Remove")
        sel_row.addWidget(self._btn_add_ep)
        sel_row.addWidget(self._btn_del_ep)
        sel_row.addStretch()
        llm_layout.addLayout(sel_row)

        # Endpoint editor (stacked via combo)
        self._ep_editors: list[LLMEndpointWidget] = []
        self._ep_stack   = QWidget()
        self._ep_stack_layout = QVBoxLayout(self._ep_stack)
        self._ep_stack_layout.setContentsMargins(0,0,0,0)
        llm_layout.addWidget(self._ep_stack, 1)

        # Presets bar
        preset_row = QHBoxLayout()
        preset_row.addWidget(QLabel("Quick add:"))
        for lbl, preset in [
            ("LM Studio", LLMConfig.lm_studio()),
            ("Ollama",    LLMConfig.ollama()),
            ("OpenAI",    LLMConfig.openai()),
        ]:
            b = QPushButton(lbl)
            b.setFixedWidth(90)
            b.clicked.connect(lambda _, p=preset: self._add_endpoint(p))
            preset_row.addWidget(b)
        preset_row.addStretch()
        llm_layout.addLayout(preset_row)

        tabs.addTab(llm_widget, "LLM Endpoints")

        # ── Embedding tab ──────────────────────────────────────────────────
        emb_widget = QWidget()
        emb_form   = QFormLayout(emb_widget)
        emb_form.setSpacing(10)

        emb_cfg = self._config.get_embedding()
        self._emb_provider = QComboBox()
        self._emb_provider.addItems(["ollama","lm_studio","openai"])
        self._emb_provider.setCurrentText(emb_cfg.provider)
        self._emb_url   = QLineEdit(emb_cfg.base_url)
        self._emb_model = QLineEdit(emb_cfg.model)
        self._emb_key   = QLineEdit(emb_cfg.api_key)
        self._emb_batch = QSpinBox()
        self._emb_batch.setRange(1, 256); self._emb_batch.setValue(emb_cfg.batch_size)

        self._btn_test_emb  = QPushButton("Test Embedding")
        self._btn_test_emb.setObjectName("primary")
        self._lbl_emb_status = QLabel("")
        self._lbl_emb_status.setObjectName("subheader")

        emb_form.addRow("Provider:",    self._emb_provider)
        emb_form.addRow("Base URL:",    self._emb_url)
        emb_form.addRow("Model:",       self._emb_model)
        emb_form.addRow("API Key:",     self._emb_key)
        emb_form.addRow("Batch Size:",  self._emb_batch)

        emb_test_row = QHBoxLayout()
        emb_test_row.addWidget(self._btn_test_emb)
        emb_test_row.addWidget(self._lbl_emb_status)
        emb_test_row.addStretch()
        emb_form.addRow("", emb_test_row)

        note = QLabel(
            "Ollama: pull nomic-embed-text first →  ollama pull nomic-embed-text\n"
            "LM Studio: load an embedding model and use its base URL."
        )
        note.setObjectName("subheader")
        note.setWordWrap(True)
        emb_form.addRow("", note)

        self._btn_test_emb.clicked.connect(self._test_embedding)
        tabs.addTab(emb_widget, "Embedding")

        # ── Extraction tab ─────────────────────────────────────────────────
        ext_widget = QWidget()
        ext_form   = QFormLayout(ext_widget)
        ext_form.setSpacing(10)

        ext_cfg = self._config.get_extraction()
        self._ext_min_words  = QSpinBox()
        self._ext_min_words.setRange(3,30); self._ext_min_words.setValue(ext_cfg.min_words)
        self._ext_shall      = QCheckBox("shall / shall not"); self._ext_shall.setChecked(ext_cfg.use_shall)
        self._ext_must       = QCheckBox("must / must not");   self._ext_must.setChecked(ext_cfg.use_must)
        self._ext_required   = QCheckBox("required");          self._ext_required.setChecked(ext_cfg.use_required)
        self._ext_will       = QCheckBox("will");              self._ext_will.setChecked(ext_cfg.use_will)
        self._ext_should     = QCheckBox("should (informative)"); self._ext_should.setChecked(ext_cfg.use_should)
        self._ext_concurrent = QSpinBox()
        self._ext_concurrent.setRange(1,8); self._ext_concurrent.setValue(ext_cfg.concurrent_downloads)
        self._ext_font_h     = QCheckBox("Use font-size heuristics for heading detection")
        self._ext_font_h.setChecked(ext_cfg.use_font_heuristics)

        ext_form.addRow("Min sentence words:", self._ext_min_words)
        ext_form.addRow("Keywords:", self._ext_shall)
        ext_form.addRow("",          self._ext_must)
        ext_form.addRow("",          self._ext_required)
        ext_form.addRow("",          self._ext_will)
        ext_form.addRow("",          self._ext_should)
        ext_form.addRow("Concurrent DLs:", self._ext_concurrent)
        ext_form.addRow("",          self._ext_font_h)

        tabs.addTab(ext_widget, "Extraction")

        layout.addWidget(tabs, 1)

        # ── Buttons ────────────────────────────────────────────────────────
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self._save)
        bb.rejected.connect(self.reject)
        layout.addWidget(bb)

        # ── Populate endpoints ─────────────────────────────────────────────
        self._current_ep_widget: LLMEndpointWidget | None = None
        for d in self._config.llm_endpoints:
            cfg = LLMConfig(**{k: v for k, v in d.items()
                               if k in LLMConfig.__dataclass_fields__})
            self._add_endpoint(cfg, select=False)

        if self._ep_editors:
            idx = min(self._config.active_llm_index, len(self._ep_editors)-1)
            self._endpoint_combo.setCurrentIndex(idx)
            self._switch_endpoint(idx)

        self._endpoint_combo.currentIndexChanged.connect(self._switch_endpoint)
        self._btn_add_ep.clicked.connect(lambda: self._add_endpoint(LLMConfig()))
        self._btn_del_ep.clicked.connect(self._remove_endpoint)

    def _add_endpoint(self, cfg: LLMConfig, select: bool = True):
        editor = LLMEndpointWidget(cfg)
        self._ep_editors.append(editor)
        self._ep_stack_layout.addWidget(editor)
        editor.hide()
        self._endpoint_combo.addItem(cfg.name)
        if select:
            idx = len(self._ep_editors) - 1
            self._endpoint_combo.setCurrentIndex(idx)
            self._switch_endpoint(idx)

    def _switch_endpoint(self, idx: int):
        if self._current_ep_widget:
            self._current_ep_widget.hide()
        if 0 <= idx < len(self._ep_editors):
            self._ep_editors[idx].show()
            self._current_ep_widget = self._ep_editors[idx]

    def _remove_endpoint(self):
        idx = self._endpoint_combo.currentIndex()
        if len(self._ep_editors) <= 1:
            return
        self._ep_editors[idx].hide()
        self._ep_stack_layout.removeWidget(self._ep_editors[idx])
        self._ep_editors[idx].deleteLater()
        del self._ep_editors[idx]
        self._endpoint_combo.removeItem(idx)

    def _test_embedding(self):
        from core.embeddings import EmbeddingClient
        cfg = self._get_embedding_config()
        client = EmbeddingClient(cfg.base_url, cfg.model, cfg.api_key)
        self._lbl_emb_status.setText("Testing…")
        try:
            ok, msg = client.check_available()
            if ok:
                self._lbl_emb_status.setText(f"✓ {msg}")
                self._lbl_emb_status.setStyleSheet(f"color:{SUCCESS};")
            else:
                self._lbl_emb_status.setText(f"✗ {msg}")
                self._lbl_emb_status.setStyleSheet(f"color:{ERROR};")
        except Exception as e:
            self._lbl_emb_status.setText(f"✗ {e}")
            self._lbl_emb_status.setStyleSheet(f"color:{ERROR};")

    def _get_embedding_config(self) -> EmbeddingConfig:
        return EmbeddingConfig(
            provider   = self._emb_provider.currentText(),
            base_url   = self._emb_url.text().strip(),
            model      = self._emb_model.text().strip(),
            api_key    = self._emb_key.text().strip(),
            batch_size = self._emb_batch.value(),
        )

    def _save(self):
        # Collect endpoint configs
        endpoints = [asdict(ed.get_config()) for ed in self._ep_editors]
        active    = self._endpoint_combo.currentIndex()

        self._config.llm_endpoints    = endpoints
        self._config.active_llm_index = active
        self._config.embedding        = asdict(self._get_embedding_config())
        self._config.extraction = asdict(ExtractionConfig(
            min_words           = self._ext_min_words.value(),
            use_shall           = self._ext_shall.isChecked(),
            use_must            = self._ext_must.isChecked(),
            use_required        = self._ext_required.isChecked(),
            use_will            = self._ext_will.isChecked(),
            use_should          = self._ext_should.isChecked(),
            concurrent_downloads= self._ext_concurrent.value(),
            use_font_heuristics = self._ext_font_h.isChecked(),
        ))
        self._config.save()
        self.config_saved.emit(self._config)
        self.accept()
