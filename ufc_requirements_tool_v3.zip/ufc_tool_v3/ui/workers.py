"""
ui/workers.py
=============
QThread workers for all background operations:
  DownloadWorker     – concurrent PDF downloads
  ExtractionWorker   – pdfplumber text extraction + heuristic INCOSE scoring
  LLMWorker          – batch LLM classification or INCOSE scoring
  EmbeddingWorker    – ChromaDB upsert + near-duplicate detection
  ChangeDetectWorker – file-hash comparison + requirement diffing
"""

from __future__ import annotations
import re
import time
import hashlib
import threading
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QThread, Signal

from core.config import DOWNLOADS_DIR, LLMConfig, EmbeddingConfig
from core.database import make_req_id, make_content_hash

# ── Requirement extraction patterns ───────────────────────────────────────────
BASE_URL = "https://www.wbdg.org/FFC/DOD/UFC/"

try:
    import pdfplumber
    HAS_PDFPLUMBER = True
except ImportError:
    HAS_PDFPLUMBER = False

try:
    import requests as _requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


def _build_keyword_pattern(cfg) -> re.Pattern:
    parts = []
    if cfg.use_shall:    parts.extend([r'\bshall not\b', r'\bshall\b'])
    if cfg.use_must:     parts.extend([r'\bmust not\b',  r'\bmust\b'])
    if cfg.use_required: parts.extend([r'\brequired to\b',r'\bis required\b',r'\bare required\b'])
    if cfg.use_will:     parts.append(r'\bwill\b')
    if cfg.use_should:   parts.append(r'\bshould\b')
    if not parts:
        parts = [r'\bshall\b']
    return re.compile('|'.join(parts), re.IGNORECASE)


def _split_sentences(text: str) -> list[str]:
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    clean = [l for l in lines if len(l) >= 5 and
             not re.match(r'^(\d+|[ivxlc]+|[A-Z]-\d+)\.?\s*$', l.strip())]
    full  = " ".join(clean)
    sents = re.split(r'(?<=[.!?])\s+(?=[A-Z0-9("])', full)
    out   = []
    for s in sents:
        parts = re.split(r';\s*(?=[A-Z("])', s)
        out.extend(parts)
    return [s.strip() for s in out if s.strip()]


def _detect_heading_text(line: str) -> bool:
    """Simple text-based heading heuristic (fallback if no font data)."""
    return bool(re.match(
        r'^(\d{1,2}[\.\-]\d{1,2}[\.\-]?\d{0,2}[\.\-]?\d{0,2})\s+[A-Z]',
        line.strip()
    ) and len(line.split()) <= 12)


def _detect_heading_font(words) -> bool:
    """pdfplumber font-size heading detection using word metadata."""
    if not words:
        return False
    sizes = [w.get("size", 0) for w in words if w.get("size")]
    if not sizes:
        return False
    avg = sum(sizes) / len(sizes)
    return avg >= 11.0 and len(words) <= 15   # large font + short line


# ═══════════════════════════════════════════════════════════════════════════════
# Download Worker
# ═══════════════════════════════════════════════════════════════════════════════

class DownloadWorker(QThread):
    file_done  = Signal(int, str, str, str)  # row, status, size_str, file_hash
    all_done   = Signal(int, int)

    def __init__(self, jobs: list, max_concurrent: int = 3, parent=None):
        super().__init__(parent)
        self._jobs   = jobs
        self._max    = max_concurrent
        self._cancel = False
        self._lock   = threading.Lock()
        self._success = 0
        self._fail    = 0

    def cancel(self): self._cancel = True

    def run(self):
        from concurrent.futures import ThreadPoolExecutor, as_completed
        with ThreadPoolExecutor(max_workers=self._max) as pool:
            futures = {pool.submit(self._download_one, row, doc): (row, doc)
                       for row, doc in self._jobs}
            for fut in as_completed(futures):
                if self._cancel: break
                row, doc = futures[fut]
                try:
                    status, size_str, fhash = fut.result()
                    with self._lock:
                        if status == "Downloaded": self._success += 1
                        else:                      self._fail    += 1
                    self.file_done.emit(row, status, size_str, fhash)
                except Exception:
                    with self._lock: self._fail += 1
                    self.file_done.emit(row, "Failed", "", "")
        self.all_done.emit(self._success, self._fail)

    def _download_one(self, row: int, doc: dict):
        import requests
        url  = BASE_URL + doc["filename"]
        dest = DOWNLOADS_DIR / doc["filename"]
        headers = {"User-Agent": "Mozilla/5.0 (compatible; UFC-Tool/2.0)"}
        try:
            with requests.get(url, stream=True, timeout=90, headers=headers) as r:
                r.raise_for_status()
                sha = hashlib.sha256()
                with open(dest, "wb") as f:
                    for chunk in r.iter_content(65536):
                        if self._cancel: break
                        f.write(chunk); sha.update(chunk)
            if self._cancel and not dest.exists():
                return "Failed", "", ""
            fhash = sha.hexdigest()
            kb    = dest.stat().st_size / 1024
            size_str = f"{kb/1024:.1f} MB" if kb >= 1024 else f"{kb:.0f} KB"
            return "Downloaded", size_str, fhash
        except Exception:
            if dest.exists(): dest.unlink(missing_ok=True)
            return "Failed", "", ""


# ═══════════════════════════════════════════════════════════════════════════════
# Extraction Worker
# ═══════════════════════════════════════════════════════════════════════════════

class ExtractionWorker(QThread):
    progress   = Signal(int, int, str)
    found_reqs = Signal(list)
    done       = Signal(int)

    def __init__(self, docs: list, ext_cfg, parent=None):
        super().__init__(parent)
        self._docs     = docs
        self._cfg      = ext_cfg
        self._cancel   = False
        self._pattern  = _build_keyword_pattern(ext_cfg)
        self._total    = 0

    def cancel(self): self._cancel = True

    def run(self):
        total   = len(self._docs)
        counter = [0]
        for i, doc in enumerate(self._docs):
            if self._cancel: break
            self.progress.emit(i+1, total, doc["filename"])
            # Support both UFC catalog docs (downloads dir) and
            # arbitrary library docs (absolute filepath key)
            if "filepath" in doc and doc["filepath"]:
                path = Path(doc["filepath"])
            else:
                path = DOWNLOADS_DIR / doc["filename"]
            if not path.exists(): continue
            batch = self._extract(path, doc, counter)
            self._total += len(batch)
            if batch: self.found_reqs.emit(batch)
        self.done.emit(self._total)

    def _get_doc_pattern(self, doc: dict) -> re.Pattern:
        """Return per-document keyword pattern if profile set, else use global."""
        profile_name = doc.get("keyword_profile", "")
        if profile_name:
            try:
                from core.library import BUILTIN_PROFILES
                profile = BUILTIN_PROFILES.get(profile_name)
                if profile:
                    return re.compile(profile.to_regex(), re.IGNORECASE)
            except Exception:
                pass
        return self._pattern

    def _extract(self, path: Path, doc: dict, counter: list) -> list:
        results = []
        ufc_id  = doc.get("source_label") or doc.get("id") or doc["filename"]
        category = doc.get("category","Unassigned")
        use_font = self._cfg.use_font_heuristics and HAS_PDFPLUMBER
        # Use per-document keyword profile if available
        pattern  = self._get_doc_pattern(doc)
        min_words = doc.get("min_words", self._cfg.min_words)

        if HAS_PDFPLUMBER:
            try:
                with pdfplumber.open(str(path)) as pdf:
                    section = "General"
                    for page_num, page in enumerate(pdf.pages, 1):
                        if self._cancel: break
                        # Get words with font metadata
                        words = page.extract_words(
                            extra_attrs=["fontname","size"]
                        ) if use_font else []
                        text  = page.extract_text() or ""
                        sentences = _split_sentences(text)

                        for sent in sentences:
                            # Heading detection
                            if use_font:
                                ws = [w for w in words
                                      if sent[:30].strip() in w.get("text","")]
                                if _detect_heading_font(ws) and len(sent.split()) <= 14:
                                    section = sent.strip()[:100]
                                    continue
                            else:
                                if _detect_heading_text(sent):
                                    section = sent.strip()[:100]
                                    continue

                            match = pattern.search(sent)
                            if match and len(sent.split()) >= min_words:
                                keyword = match.group(0).upper()
                                req_id  = make_req_id(ufc_id, sent, page_num)
                                counter[0] += 1
                                # Heuristic INCOSE score
                                from core.incose import score_requirement
                                hs = score_requirement(req_id, sent, section)
                                results.append({
                                    "req_id":       req_id,
                                    "source":       ufc_id,
                                    "source_ufc":   ufc_id,
                                    "ufc_version":  doc.get("filename",""),
                                    "page":         page_num,
                                    "section":      section,
                                    "text":         sent.strip(),
                                    "keyword":      keyword,
                                    "priority":     "Unset",
                                    "discipline":   category,
                                    "status":       "Unreviewed",
                                    "notes":        "",
                                    **hs.to_dict(),
                                })
            except Exception as e:
                pass
        else:
            results = self._extract_cli(path, doc, counter)
        return results

    def _extract_cli(self, path: Path, doc: dict, counter: list) -> list:
        import subprocess
        try:
            r = subprocess.run(["pdftotext","-layout",str(path),"-"],
                               capture_output=True, text=True, timeout=120)
            text = r.stdout
        except Exception:
            return []
        ufc_id = doc.get("source_label") or doc.get("id") or doc["filename"]
        for sent in _split_sentences(text):
            match = pattern.search(sent)
            if match and len(sent.split()) >= min_words:
                kwd    = match.group(0).upper()
                req_id = make_req_id(ufc_id, sent, 0)
                counter[0] += 1
                from core.incose import score_requirement
                hs = score_requirement(req_id, sent, "")
                yield {
                    "req_id":      req_id,
                    "source":      ufc_id,
                    "source_ufc":  ufc_id,
                    "ufc_version": doc.get("filename",""),
                    "page":        0,
                    "section":     "General",
                    "text":        sent.strip(),
                    "keyword":     kwd,
                    "priority":    "Unset",
                    "discipline":  doc.get("category",""),
                    "status":      "Unreviewed",
                    "notes":       "",
                    **hs.to_dict(),
                }
        return []


# ═══════════════════════════════════════════════════════════════════════════════
# LLM Worker
# ═══════════════════════════════════════════════════════════════════════════════

class LLMWorker(QThread):
    progress    = Signal(int, int, str)   # current, total, req_id
    batch_done  = Signal(list)            # list of scored dicts
    done        = Signal(int, int)        # processed, errors
    error       = Signal(str)

    MODE_CLASSIFY = "classify"
    MODE_INCOSE   = "incose"

    def __init__(self, items: list[dict], llm_cfg: LLMConfig,
                 mode: str = MODE_CLASSIFY, parent=None):
        super().__init__(parent)
        self._items  = items
        self._cfg    = llm_cfg
        self._mode   = mode
        self._cancel = False
        self._processed = 0
        self._errors    = 0

    def cancel(self): self._cancel = True

    def run(self):
        from core.llm_client import LLMClient
        client = LLMClient(self._cfg)

        # Verify connection
        ok, msg = client.check_available()
        if not ok:
            self.error.emit(f"LLM endpoint unavailable: {msg}")
            return

        BATCH = 10
        total = len(self._items)
        for i in range(0, total, BATCH):
            if self._cancel: break
            batch = self._items[i:i+BATCH]

            def progress_cb(cur, tot, result):
                abs_cur = i + cur
                self.progress.emit(abs_cur, total, getattr(result, 'req_id',''))

            if self._mode == self.MODE_CLASSIFY:
                scored = client.classify_batch(batch, progress_cb)
            else:
                scored = client.score_incose_batch(batch, progress_cb)

            errors = sum(1 for s in scored if s.get("error"))
            self._processed += len(scored)
            self._errors    += errors
            self.batch_done.emit(scored)

        self.done.emit(self._processed, self._errors)


# ═══════════════════════════════════════════════════════════════════════════════
# Embedding Worker
# ═══════════════════════════════════════════════════════════════════════════════

class EmbeddingWorker(QThread):
    progress      = Signal(int, int, str)
    done          = Signal(int)
    duplicates_found = Signal(list)    # list of (dup_id, canon_id, score)
    error         = Signal(str)

    MODE_UPSERT = "upsert"
    MODE_DEDUP  = "dedup"

    def __init__(self, reqs: list[dict], emb_cfg: EmbeddingConfig,
                 chroma_dir: str, mode: str = MODE_UPSERT,
                 dup_threshold: float = 0.95, parent=None):
        super().__init__(parent)
        self._reqs      = reqs
        self._cfg       = emb_cfg
        self._chroma_dir = chroma_dir
        self._mode      = mode
        self._threshold = dup_threshold
        self._cancel    = False

    def cancel(self): self._cancel = True

    def run(self):
        from core.embeddings import EmbeddingClient, VectorStore
        try:
            ec = EmbeddingClient(self._cfg.base_url, self._cfg.model,
                                  self._cfg.api_key)
            vs = VectorStore(self._chroma_dir, ec)
        except ImportError as e:
            self.error.emit(str(e))
            return
        except Exception as e:
            self.error.emit(f"Vector store init failed: {e}")
            return

        if self._mode == self.MODE_UPSERT:
            def prog(cur, tot):
                self.progress.emit(cur, tot, "Embedding…")
            total = vs.upsert(self._reqs, self._cfg.batch_size, prog)
            self.done.emit(total)

        elif self._mode == self.MODE_DEDUP:
            def prog(cur, tot, msg=""):
                self.progress.emit(cur, tot, msg)
            pairs = vs.find_duplicates(self._threshold, progress_cb=prog)
            self.duplicates_found.emit(pairs)
            self.done.emit(len(pairs))


# ═══════════════════════════════════════════════════════════════════════════════
# Change Detection Worker
# ═══════════════════════════════════════════════════════════════════════════════

class ChangeDetectWorker(QThread):
    progress = Signal(int, int, str)
    done     = Signal(object)   # DocumentDiff object
    error    = Signal(str)

    def __init__(self, filename: str, old_reqs: list[dict],
                 new_reqs: list[dict],
                 old_hash: str, new_hash: str, parent=None):
        super().__init__(parent)
        self._filename = filename
        self._old_reqs = old_reqs
        self._new_reqs = new_reqs
        self._old_hash = old_hash
        self._new_hash = new_hash

    def run(self):
        from core.change_detection import diff_requirement_sets
        self.progress.emit(0, 1, "Running diff…")
        try:
            result = diff_requirement_sets(
                self._old_reqs, self._new_reqs,
                self._filename, self._old_hash, self._new_hash
            )
            self.done.emit(result)
        except Exception as e:
            self.error.emit(str(e))
