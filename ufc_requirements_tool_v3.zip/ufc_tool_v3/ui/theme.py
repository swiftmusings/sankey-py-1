"""ui/theme.py — Centralised dark military colour palette and stylesheet."""

DARK_BG    = "#1A1D21"
DARK_SURF  = "#22262C"
DARK_SURF2 = "#2A2F37"
DARK_BORD  = "#3A4050"
TEXT_MAIN  = "#D0D4DC"
TEXT_MUTED = "#737880"
ACCENT     = "#20808D"
ACCENT_HVR = "#1A6A76"
SUCCESS    = "#3D8B4E"
WARNING    = "#B87833"
ERROR      = "#8B3D3D"
HIGHLIGHT  = "#2B3A4A"
ACCENT_LT  = "#BCE2E7"

STYLESHEET = f"""
QMainWindow, QDialog {{
    background-color: {DARK_BG}; color: {TEXT_MAIN};
}}
QWidget {{
    background-color: {DARK_BG}; color: {TEXT_MAIN};
    font-family: "Segoe UI", "Calibri", sans-serif;
    font-size: 13px;
}}
QTabWidget::pane {{
    border: 1px solid {DARK_BORD}; background: {DARK_SURF}; border-radius: 4px;
}}
QTabBar::tab {{
    background: {DARK_SURF2}; color: {TEXT_MUTED};
    padding: 8px 20px; border: 1px solid {DARK_BORD};
    border-bottom: none; border-radius: 4px 4px 0 0;
    margin-right: 2px; font-weight: 600; font-size: 13px;
}}
QTabBar::tab:selected {{ background: {DARK_SURF}; color: {TEXT_MAIN}; border-bottom: 2px solid {ACCENT}; }}
QTabBar::tab:hover:!selected {{ color: {TEXT_MAIN}; background: {DARK_BORD}; }}
QGroupBox {{
    border: 1px solid {DARK_BORD}; border-radius: 6px;
    margin-top: 14px; padding-top: 8px;
    font-weight: 600; color: {TEXT_MUTED}; font-size: 11px;
    text-transform: uppercase; letter-spacing: 0.5px;
}}
QGroupBox::title {{
    subcontrol-origin: margin; left: 10px; padding: 0 4px;
    background: {DARK_SURF};
}}
QPushButton {{
    background: {DARK_SURF2}; color: {TEXT_MAIN};
    border: 1px solid {DARK_BORD}; border-radius: 5px;
    padding: 6px 16px; font-weight: 600; font-size: 13px; min-height: 28px;
}}
QPushButton:hover {{ background: {DARK_BORD}; border-color: {ACCENT}; color: white; }}
QPushButton:pressed {{ background: {ACCENT_HVR}; }}
QPushButton:disabled {{ color: {TEXT_MUTED}; border-color: {DARK_BORD}; }}
QPushButton#primary {{ background: {ACCENT}; color: white; border: none; }}
QPushButton#primary:hover {{ background: {ACCENT_HVR}; }}
QPushButton#primary:disabled {{ background: #1A4A50; color: #456A70; }}
QPushButton#danger {{ background: {ERROR}; color: white; border: none; }}
QPushButton#success {{ background: {SUCCESS}; color: white; border: none; }}
QLineEdit, QPlainTextEdit, QTextEdit {{
    background: {DARK_SURF2}; color: {TEXT_MAIN};
    border: 1px solid {DARK_BORD}; border-radius: 4px;
    padding: 5px 8px; selection-background-color: {ACCENT};
}}
QLineEdit:focus, QPlainTextEdit:focus {{ border-color: {ACCENT}; }}
QComboBox {{
    background: {DARK_SURF2}; color: {TEXT_MAIN};
    border: 1px solid {DARK_BORD}; border-radius: 4px;
    padding: 4px 8px; min-height: 26px;
}}
QComboBox:hover {{ border-color: {ACCENT}; }}
QComboBox::drop-down {{ border: none; width: 20px; }}
QComboBox QAbstractItemView {{
    background: {DARK_SURF2}; border: 1px solid {DARK_BORD};
    selection-background-color: {ACCENT};
}}
QTableView {{
    background: {DARK_SURF}; color: {TEXT_MAIN};
    border: 1px solid {DARK_BORD}; gridline-color: {DARK_BORD};
    alternate-background-color: {DARK_SURF2}; border-radius: 4px;
    selection-background-color: {HIGHLIGHT}; selection-color: white;
}}
QTableView::item {{ padding: 4px 6px; border: none; }}
QTableView::item:selected {{ background: {HIGHLIGHT}; color: white; }}
QHeaderView::section {{
    background: {DARK_SURF2}; color: {TEXT_MUTED};
    border: none; border-right: 1px solid {DARK_BORD};
    border-bottom: 2px solid {ACCENT}; padding: 6px 8px;
    font-weight: 700; font-size: 11px;
    text-transform: uppercase; letter-spacing: 0.4px;
}}
QProgressBar {{
    background: {DARK_SURF2}; border: 1px solid {DARK_BORD};
    border-radius: 5px; height: 14px;
    text-align: center; color: white; font-size: 11px; font-weight: 600;
}}
QProgressBar::chunk {{
    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
        stop:0 {ACCENT}, stop:1 {ACCENT_HVR});
    border-radius: 4px;
}}
QScrollBar:vertical {{
    background: {DARK_SURF}; width: 10px; border-radius: 5px;
}}
QScrollBar::handle:vertical {{
    background: {DARK_BORD}; border-radius: 5px; min-height: 20px;
}}
QScrollBar::handle:vertical:hover {{ background: {ACCENT}; }}
QScrollBar:horizontal {{ background: {DARK_SURF}; height: 10px; }}
QScrollBar::handle:horizontal {{ background: {DARK_BORD}; border-radius: 5px; min-width: 20px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QStatusBar {{
    background: {DARK_SURF2}; color: {TEXT_MUTED};
    border-top: 1px solid {DARK_BORD}; font-size: 11px;
}}
QSplitter::handle {{ background: {DARK_BORD}; width: 2px; height: 2px; }}
QCheckBox {{ color: {TEXT_MAIN}; spacing: 6px; }}
QCheckBox::indicator {{
    width: 16px; height: 16px; border: 1px solid {DARK_BORD};
    border-radius: 3px; background: {DARK_SURF2};
}}
QCheckBox::indicator:checked {{ background: {ACCENT}; border-color: {ACCENT}; }}
QLabel#header {{ font-size: 18px; font-weight: 700; color: {TEXT_MAIN}; }}
QLabel#subheader {{ font-size: 12px; color: {TEXT_MUTED}; }}
QLabel#badge {{ background: {ACCENT}; color: white; border-radius: 10px; padding: 2px 8px; font-size: 11px; font-weight: 700; }}
QLabel#badge_warn {{ background: {WARNING}; color: white; border-radius: 10px; padding: 2px 8px; font-size: 11px; font-weight: 700; }}
QLabel#badge_ok {{ background: {SUCCESS}; color: white; border-radius: 10px; padding: 2px 8px; font-size: 11px; font-weight: 700; }}
QLabel#badge_err {{ background: {ERROR}; color: white; border-radius: 10px; padding: 2px 8px; font-size: 11px; font-weight: 700; }}
QSpinBox, QDoubleSpinBox {{
    background: {DARK_SURF2}; color: {TEXT_MAIN};
    border: 1px solid {DARK_BORD}; border-radius: 4px; padding: 4px 6px;
}}
QSpinBox:focus, QDoubleSpinBox:focus {{ border-color: {ACCENT}; }}
QToolTip {{
    background: {DARK_SURF2}; color: {TEXT_MAIN};
    border: 1px solid {ACCENT}; padding: 4px 8px; font-size: 12px;
}}
QMenuBar {{
    background: {DARK_SURF2}; color: {TEXT_MAIN};
    border-bottom: 1px solid {DARK_BORD};
}}
QMenuBar::item:selected {{ background: {ACCENT}; }}
QMenu {{
    background: {DARK_SURF2}; color: {TEXT_MAIN};
    border: 1px solid {DARK_BORD};
}}
QMenu::item:selected {{ background: {ACCENT}; }}
QSlider::groove:horizontal {{
    background: {DARK_BORD}; height: 4px; border-radius: 2px;
}}
QSlider::handle:horizontal {{
    background: {ACCENT}; width: 14px; height: 14px;
    margin: -5px 0; border-radius: 7px;
}}
"""
