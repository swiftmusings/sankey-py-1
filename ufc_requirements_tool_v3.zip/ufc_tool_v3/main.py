"""
UFC Requirements Tool v3
========================
Professional-grade PySide6 application for downloading, extracting, scoring,
and allocating requirements from DoD Unified Facilities Criteria documents.

Phases implemented
------------------
1a. LLM classifier  (OpenAI-compatible; LM Studio, Ollama, OpenAI)
1b. Near-duplicate detection via ChromaDB + nomic-embed-text
2a. SQLite project workspace with multi-project file-picker launcher
2b. Hash-stable Req IDs (SHA256 content addressing)
3a. Heuristic + LLM INCOSE / ISO 29148 quality scoring
3b. Traceability matrix (RTM) with parent/child allocation links
4a. ChromaDB vector semantic search
4b. UFC edition change detection (sentence-level diff)
5a. ReqIF 1.2 XML export (DOORS NG / Jama / Polarion compatible)
5b. LLM settings panel (multi-endpoint, embedding, extraction config)
"""

from __future__ import annotations
import sys, os, json, re, csv, datetime, hashlib, time, threading
from pathlib import Path
from dataclasses import asdict

from PySide6.QtCore import (
    Qt, QThread, Signal, QSortFilterProxyModel, QModelIndex,
    QAbstractTableModel, QSize, QTimer, QRegularExpression
)
from PySide6.QtGui import (
    QColor, QFont, QPalette, QAction, QKeySequence, QRegularExpressionValidator
)
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTabWidget, QLabel, QPushButton, QLineEdit, QProgressBar, QTableView,
    QHeaderView, QFileDialog, QMessageBox, QCheckBox, QComboBox,
    QSplitter, QTextEdit, QGroupBox, QScrollArea, QFrame, QStatusBar,
    QSizePolicy, QAbstractItemView, QDialog, QDialogButtonBox,
    QSpinBox, QSlider, QPlainTextEdit, QStyledItemDelegate,
    QFormLayout, QListWidget, QListWidgetItem, QDoubleSpinBox,
    QToolButton
)

from core.config import (
    AppConfig, LLMConfig, EmbeddingConfig, ExtractionConfig,
    CATALOG_PATH, DOWNLOADS_DIR, EXPORTS_DIR, APP_DIR
)
from core.database import ProjectDB, make_req_id, make_content_hash
from core.incose import score_batch, quality_summary
from ui.theme import STYLESHEET, DARK_BG, DARK_SURF, DARK_SURF2, DARK_BORD
from ui.theme import TEXT_MAIN, TEXT_MUTED, ACCENT, ACCENT_HVR
from ui.theme import SUCCESS, WARNING, ERROR, HIGHLIGHT, ACCENT_LT
from ui.settings_dialog import SettingsDialog
from ui.workers import (
    DownloadWorker, ExtractionWorker, LLMWorker, EmbeddingWorker,
    ChangeDetectWorker
)
from core.library import LibraryManager
from ui.library_tab import LibraryTab

CHROMA_DIR = str(APP_DIR / "chroma_db")
Path(CHROMA_DIR).mkdir(exist_ok=True)

# ── Allocation / label constants ───────────────────────────────────────────────
PRIORITY_LABELS  = ["Unset","Critical","High","Medium","Low","TBD"]
DISCIPLINE_LABELS = [
    "Unassigned","Architecture","Civil","Structural","Mechanical",
    "Electrical","Fire Protection","Environmental","Security",
    "Communications","Operations","Naval","Safety","Other"
]
STATUS_LABELS = ["Unreviewed","Accepted","Modified","Rejected","Deferred"]
LINK_TYPES    = ["derives","refines","conflicts","satisfies"]


# ═══════════════════════════════════════════════════════════════════════════════
# Project Launcher Dialog
# ═══════════════════════════════════════════════════════════════════════════════

class ProjectLauncherDialog(QDialog):
    """Startup dialog — open existing project or create new one."""

    def __init__(self, config: AppConfig, parent=None):
        super().__init__(parent)
        self._config = config
        self._selected_path: str = ""
        self.setWindowTitle("UFC Requirements Tool v3 — Open Project")
        self.setMinimumWidth(600)
        self.setMinimumHeight(400)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        # Banner
        banner = QLabel("UFC Requirements Tool")
        banner.setStyleSheet(
            f"font-size:22px;font-weight:900;color:{ACCENT};"
            f"letter-spacing:2px;font-family:'Segoe UI';"
        )
        sub = QLabel("DoD Unified Facilities Criteria · Requirements Management Platform v3")
        sub.setStyleSheet(f"color:{TEXT_MUTED};font-size:12px;")
        layout.addWidget(banner)
        layout.addWidget(sub)

        line = QFrame(); line.setFrameShape(QFrame.HLine)
        line.setStyleSheet(f"background:{DARK_BORD};")
        layout.addWidget(line)

        # New project
        new_grp = QGroupBox("New Project")
        new_layout = QFormLayout(new_grp)
        self._proj_name = QLineEdit()
        self._proj_name.setPlaceholderText("e.g., JBLM Barracks Renovation")
        self._proj_dir  = QLineEdit(str(APP_DIR / "projects"))
        self._btn_browse_dir = QPushButton("Browse…")
        self._btn_browse_dir.setFixedWidth(80)
        dir_row = QHBoxLayout()
        dir_row.addWidget(self._proj_dir)
        dir_row.addWidget(self._btn_browse_dir)
        new_layout.addRow("Project Name:", self._proj_name)
        new_layout.addRow("Directory:",    dir_row)
        self._btn_create = QPushButton("Create Project")
        self._btn_create.setObjectName("primary")
        new_layout.addRow("",              self._btn_create)
        layout.addWidget(new_grp)

        # Open existing
        open_grp = QGroupBox("Open Existing")
        open_layout = QVBoxLayout(open_grp)
        self._btn_open = QPushButton("Browse for .ufcdb file…")
        open_layout.addWidget(self._btn_open)

        # Recent
        last = self._config.last_project_path
        if last and Path(last).exists():
            lbl = QLabel(f"Recent: {Path(last).name}")
            lbl.setStyleSheet(f"color:{TEXT_MUTED};font-size:11px;")
            open_layout.addWidget(lbl)
            self._btn_recent = QPushButton(f"Open  {Path(last).name}")
            self._btn_recent.clicked.connect(lambda: self._open_path(last))
            open_layout.addWidget(self._btn_recent)

        layout.addWidget(open_grp)
        layout.addStretch()

        bb = QDialogButtonBox(QDialogButtonBox.Cancel)
        bb.rejected.connect(self.reject)
        layout.addWidget(bb)

        # Connections
        self._btn_browse_dir.clicked.connect(self._browse_dir)
        self._btn_create.clicked.connect(self._create)
        self._btn_open.clicked.connect(self._open_browse)

    def _browse_dir(self):
        d = QFileDialog.getExistingDirectory(self, "Select Project Directory")
        if d: self._proj_dir.setText(d)

    def _create(self):
        name = self._proj_name.text().strip()
        if not name:
            QMessageBox.warning(self, "Name Required", "Enter a project name.")
            return
        safe    = re.sub(r'[^\w\s-]', '', name).strip().replace(' ','_')
        dirpath = Path(self._proj_dir.text().strip())
        dirpath.mkdir(parents=True, exist_ok=True)
        db_path = dirpath / f"{safe}.ufcdb"
        # Initialise DB
        db = ProjectDB(db_path)
        db.set_meta("project_name", name)
        db.set_meta("created_at", datetime.datetime.utcnow().isoformat())
        self._open_path(str(db_path))

    def _open_browse(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Open Project", str(APP_DIR / "projects"),
            "UFC Project (*.ufcdb);;All Files (*)"
        )
        if path: self._open_path(path)

    def _open_path(self, path: str):
        self._selected_path = path
        self.accept()

    def selected_path(self) -> str:
        return self._selected_path


# ═══════════════════════════════════════════════════════════════════════════════
# Table Models
# ═══════════════════════════════════════════════════════════════════════════════

class CatalogTableModel(QAbstractTableModel):
    HEADERS = ["","UFC #","Title","Category","Status","Size","Change"]
    STATUS_COLORS = {
        "Downloaded": QColor(SUCCESS), "Downloading": QColor(ACCENT),
        "Failed": QColor(ERROR),       "Queued": QColor(WARNING), "—": QColor(TEXT_MUTED),
    }
    def __init__(self, catalog, parent=None):
        super().__init__(parent)
        self._cat     = catalog
        self._checked = [False]*len(catalog)
        self._status  = ["—"]*len(catalog)
        self._size    = [""]*len(catalog)
        self._change  = [""]*len(catalog)  # "↑ New version" indicator
        self._refresh_file_status()

    def _refresh_file_status(self):
        for i, doc in enumerate(self._cat):
            p = DOWNLOADS_DIR / doc["filename"]
            if p.exists():
                kb = p.stat().st_size/1024
                self._status[i] = "Downloaded"
                self._size[i]   = f"{kb/1024:.1f} MB" if kb>=1024 else f"{kb:.0f} KB"
            else:
                self._status[i] = "—"; self._size[i] = ""

    def rowCount(self, p=QModelIndex()): return len(self._cat)
    def columnCount(self, p=QModelIndex()): return len(self.HEADERS)
    def headerData(self, s, o, role=Qt.DisplayRole):
        if o==Qt.Horizontal and role==Qt.DisplayRole: return self.HEADERS[s]

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid(): return None
        r,c = index.row(), index.column()
        doc = self._cat[r]
        if role==Qt.CheckStateRole and c==0:
            return Qt.Checked if self._checked[r] else Qt.Unchecked
        if role==Qt.DisplayRole:
            if c==0: return None
            if c==1: return doc["id"]
            if c==2: return doc["title"]
            if c==3: return doc["category"]
            if c==4: return self._status[r]
            if c==5: return self._size[r]
            if c==6: return self._change[r]
        if role==Qt.ForegroundRole and c==4:
            return self.STATUS_COLORS.get(self._status[r], QColor(TEXT_MUTED))
        if role==Qt.ForegroundRole and c==6 and self._change[r]:
            return QColor(WARNING)
        if role==Qt.FontRole and c in (1,4):
            f=QFont(); f.setWeight(QFont.Weight.Bold); return f
        if role==Qt.TextAlignmentRole and c in (0,4,5,6):
            return Qt.AlignCenter
        return None

    def flags(self, index):
        b = Qt.ItemIsEnabled|Qt.ItemIsSelectable
        if index.column()==0: b|=Qt.ItemIsUserCheckable
        return b

    def setData(self, index, value, role=Qt.EditRole):
        if role==Qt.CheckStateRole and index.column()==0:
            self._checked[index.row()] = (value==Qt.Checked)
            self.dataChanged.emit(index, index, [role]); return True
        return False

    def set_status(self, row, status, size=""):
        self._status[row]=status
        if size: self._size[row]=size
        self.dataChanged.emit(self.index(row,4), self.index(row,5))

    def set_change_flag(self, row, msg):
        self._change[row] = msg
        self.dataChanged.emit(self.index(row,6), self.index(row,6))

    def get_checked_docs(self):
        return [(i,self._cat[i]) for i,c in enumerate(self._checked) if c]

    def check_all(self, state):
        self._checked=[state]*len(self._cat)
        self.dataChanged.emit(self.index(0,0),self.index(len(self._cat)-1,0),[Qt.CheckStateRole])

    def check_not_downloaded(self):
        self._checked=[self._status[i]!="Downloaded" for i in range(len(self._cat))]
        self.dataChanged.emit(self.index(0,0),self.index(len(self._cat)-1,0),[Qt.CheckStateRole])

    def refresh(self):
        self._refresh_file_status()
        self.dataChanged.emit(self.index(0,0),self.index(len(self._cat)-1,len(self.HEADERS)-1))

    def get_doc(self, row): return self._cat[row]


class RequirementsTableModel(QAbstractTableModel):
    HEADERS = [
        "Req ID","Source","Pg","Section","Requirement Text",
        "Kwd","INCOSE","LLM","Priority","Discipline","Status","Notes"
    ]
    EDITABLE = {6,8,9,10,11}
    STATUS_COLORS = {
        "Unreviewed": QColor(TEXT_MUTED), "Accepted": QColor(SUCCESS),
        "Modified":   QColor(ACCENT),     "Rejected": QColor(ERROR),
        "Deferred":   QColor(WARNING),
    }
    INCOSE_COLORS = [
        (0.8, QColor(SUCCESS)), (0.6, QColor(ACCENT)),
        (0.4, QColor(WARNING)), (0.0, QColor(ERROR)),
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self._rows: list[dict] = []

    def load(self, rows):
        self.beginResetModel(); self._rows=rows; self.endResetModel()

    def append_rows(self, rows):
        if not rows: return
        s=len(self._rows)
        self.beginInsertRows(QModelIndex(),s,s+len(rows)-1)
        self._rows.extend(rows); self.endInsertRows()

    def clear(self):
        self.beginResetModel(); self._rows=[]; self.endResetModel()

    def rowCount(self, p=QModelIndex()): return len(self._rows)
    def columnCount(self, p=QModelIndex()): return len(self.HEADERS)
    def headerData(self, s, o, role=Qt.DisplayRole):
        if o==Qt.Horizontal and role==Qt.DisplayRole: return self.HEADERS[s]

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid(): return None
        row,col = index.row(), index.column()
        r = self._rows[row]
        if role==Qt.DisplayRole:
            if col==0:  return r.get("req_id","")
            if col==1:  return r.get("source_ufc", r.get("source",""))
            if col==2:  return str(r.get("page",""))
            if col==3:  return str(r.get("section",""))[:60]
            if col==4:  return r.get("text","")
            if col==5:  return r.get("keyword","")
            if col==6:
                v = r.get("incose_overall")
                return f"{v:.2f}" if v is not None else "—"
            if col==7:
                v = r.get("llm_is_requirement")
                c = r.get("llm_confidence")
                if v is None: return "—"
                return f"{'✓' if v else '✗'} {c:.0%}" if c else ("✓" if v else "✗")
            if col==8:  return r.get("priority","Unset")
            if col==9:  return r.get("discipline","Unassigned")
            if col==10: return r.get("status","Unreviewed")
            if col==11: return r.get("notes","")

        if role==Qt.ForegroundRole:
            if col==10: return self.STATUS_COLORS.get(r.get("status",""),QColor(TEXT_MUTED))
            if col==6:
                v = r.get("incose_overall")
                if v is not None:
                    for thresh, color in self.INCOSE_COLORS:
                        if v >= thresh: return color

        if role==Qt.FontRole and col in (0,10):
            f=QFont()
            if col==0: f.setFamily("Consolas")
            f.setWeight(QFont.Weight.Bold); return f

        if role==Qt.TextAlignmentRole and col in (0,2,5,6,7,8,9,10):
            return Qt.AlignCenter
        if role==Qt.ToolTipRole and col==4:
            return r.get("text","")
        if role==Qt.ToolTipRole and col==6:
            r2 = self._rows[row]
            parts = []
            for k in ["score_singular","score_verifiable","score_unambiguous",
                      "score_complete","score_traceable","score_feasible"]:
                v = r2.get(k)
                if v is not None:
                    parts.append(f"{k.replace('score_','').title()}: {v:.2f}")
            return "\n".join(parts) if parts else ""
        return None

    def flags(self, index):
        b = Qt.ItemIsEnabled|Qt.ItemIsSelectable
        if index.column() in self.EDITABLE: b|=Qt.ItemIsEditable
        return b

    def setData(self, index, value, role=Qt.EditRole):
        if not index.isValid() or role!=Qt.EditRole: return False
        row,col = index.row(), index.column()
        keys={8:"priority",9:"discipline",10:"status",11:"notes"}
        if col in keys:
            self._rows[row][keys[col]]=value
            self.dataChanged.emit(index,index,[role]); return True
        return False

    def get_all(self): return self._rows
    def get_row(self, row): return self._rows[row]


# ═══════════════════════════════════════════════════════════════════════════════
# Combo Delegate
# ═══════════════════════════════════════════════════════════════════════════════

class ComboDelegate(QStyledItemDelegate):
    def __init__(self, opts, parent=None):
        super().__init__(parent); self._opts=opts
    def createEditor(self,p,o,i):
        c=QComboBox(p); c.addItems(self._opts); return c
    def setEditorData(self,e,i):
        idx=e.findText(i.data(Qt.DisplayRole) or "")
        if idx>=0: e.setCurrentIndex(idx)
    def setModelData(self,e,m,i): m.setData(i,e.currentText(),Qt.EditRole)
    def updateEditorGeometry(self,e,o,i): e.setGeometry(o.rect)


# ═══════════════════════════════════════════════════════════════════════════════
# Tab 1 — Download (extended with change detection)
# ═══════════════════════════════════════════════════════════════════════════════

class DownloadTab(QWidget):
    def __init__(self, catalog, config: AppConfig, db: ProjectDB, parent=None):
        super().__init__(parent)
        self._catalog = catalog
        self._config  = config
        self._db      = db
        self._worker  = None
        self._dl_start = None
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16,16,16,16)
        layout.setSpacing(12)

        hdr=QHBoxLayout()
        t=QLabel("UFC Document Library"); t.setObjectName("header")
        hdr.addWidget(t); hdr.addStretch()
        self._badge=QLabel(f"{len(self._catalog)} documents")
        self._badge.setObjectName("badge"); hdr.addWidget(self._badge)
        layout.addLayout(hdr)

        sub=QLabel("Download UFC PDFs from WBDG · Downloads saved to /downloads · Version hashes tracked for change detection.")
        sub.setObjectName("subheader"); sub.setWordWrap(True)
        layout.addWidget(sub)

        # Toolbar
        tb=QHBoxLayout(); tb.setSpacing(8)
        self._btn_all   = QPushButton("Select All")
        self._btn_none  = QPushButton("Select None")
        self._btn_undl  = QPushButton("Select Not Downloaded")
        self._cat_combo = QComboBox()
        self._cat_combo.addItem("Filter by Category")
        for c in sorted({d["category"] for d in self._catalog}):
            self._cat_combo.addItem(c)
        self._search=QLineEdit(); self._search.setPlaceholderText("Search UFC…")
        self._search.setMinimumWidth(200)
        for w in (self._btn_all,self._btn_none,self._btn_undl,self._cat_combo):
            tb.addWidget(w)
        tb.addStretch(); tb.addWidget(self._search)
        layout.addLayout(tb)

        # Table
        self._model  = CatalogTableModel(self._catalog)
        self._proxy  = QSortFilterProxyModel()
        self._proxy.setSourceModel(self._model)
        self._proxy.setFilterCaseSensitivity(Qt.CaseInsensitive)
        self._proxy.setFilterKeyColumn(-1)
        self._table  = QTableView()
        self._table.setModel(self._proxy)
        self._table.setAlternatingRowColors(True)
        self._table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._table.setSortingEnabled(True)
        self._table.verticalHeader().setVisible(False)
        hh=self._table.horizontalHeader()
        hh.resizeSection(0,32); hh.resizeSection(1,110)
        hh.resizeSection(2,380); hh.resizeSection(3,120)
        hh.resizeSection(4,100); hh.resizeSection(5,80)
        hh.setStretchLastSection(True)
        layout.addWidget(self._table,1)

        # Progress
        pg=QGroupBox("Download Progress"); pgL=QVBoxLayout(pg)
        r1=QHBoxLayout()
        self._prog=QProgressBar(); self._prog.setFormat("%v / %m files")
        self._lbl_status=QLabel("Ready"); self._lbl_status.setObjectName("subheader")
        r1.addWidget(self._prog,1); r1.addWidget(self._lbl_status)
        pgL.addLayout(r1)
        self._log=QPlainTextEdit(); self._log.setReadOnly(True)
        self._log.setMaximumHeight(100); self._log.setFont(QFont("Consolas",10))
        pgL.addWidget(self._log); layout.addWidget(pg)

        # Actions
        br=QHBoxLayout(); br.setSpacing(8)
        self._lbl_sel=QLabel("0 selected"); self._lbl_sel.setObjectName("subheader")
        self._spin_conc=QSpinBox(); self._spin_conc.setRange(1,8)
        self._spin_conc.setValue(self._config.get_extraction().concurrent_downloads)
        self._spin_conc.setPrefix("Concurrent: "); self._spin_conc.setFixedWidth(130)
        self._btn_dl  = QPushButton("Download Selected")
        self._btn_dl.setObjectName("primary"); self._btn_dl.setMinimumWidth(160)
        self._btn_cancel=QPushButton("Cancel"); self._btn_cancel.setEnabled(False)
        self._btn_refresh=QPushButton("Refresh Status")
        self._btn_folder =QPushButton("Open Folder")
        self._btn_chkver =QPushButton("Check for Updates")
        for w in (self._lbl_sel,self._spin_conc): br.addWidget(w)
        br.addStretch()
        for b in (self._btn_chkver,self._btn_refresh,self._btn_folder,
                  self._btn_cancel,self._btn_dl): br.addWidget(b)
        layout.addLayout(br)

        # Connections
        self._btn_all.clicked.connect(lambda: self._model.check_all(True))
        self._btn_none.clicked.connect(lambda: self._model.check_all(False))
        self._btn_undl.clicked.connect(self._model.check_not_downloaded)
        self._cat_combo.currentTextChanged.connect(self._filter_cat)
        self._search.textChanged.connect(self._proxy.setFilterFixedString)
        self._btn_dl.clicked.connect(self._start_download)
        self._btn_cancel.clicked.connect(self._cancel)
        self._btn_refresh.clicked.connect(self._model.refresh)
        self._btn_folder.clicked.connect(lambda: __import__("subprocess").Popen(f'explorer "{DOWNLOADS_DIR}"'))
        self._btn_chkver.clicked.connect(self._check_versions)
        self._model.dataChanged.connect(self._update_count)
        self._update_count()

    def _filter_cat(self, text):
        if text=="Filter by Category":
            self._model.check_all(False)
        else:
            for i,doc in enumerate(self._catalog):
                self._model._checked[i]=(doc["category"]==text)
            self._model.dataChanged.emit(self._model.index(0,0),
                self._model.index(len(self._catalog)-1,0),[Qt.CheckStateRole])
        self._update_count()

    def _update_count(self):
        n=len(self._model.get_checked_docs())
        self._lbl_sel.setText(f"{n} selected")

    def _start_download(self):
        jobs=self._model.get_checked_docs()
        if not jobs:
            QMessageBox.information(self,"No Selection","Select documents first."); return
        self._btn_dl.setEnabled(False); self._btn_cancel.setEnabled(True)
        self._prog.setMaximum(len(jobs)); self._prog.setValue(0)
        self._dl_start=time.time(); self._completed=0
        for row,_ in jobs: self._model.set_status(row,"Queued")
        self._worker=DownloadWorker(jobs, self._spin_conc.value())
        self._worker.file_done.connect(self._on_file_done)
        self._worker.all_done.connect(self._on_all_done)
        self._worker.start()

    def _on_file_done(self, row, status, size_str, fhash):
        self._completed+=1
        self._prog.setValue(self._completed)
        self._model.set_status(row, status, size_str)
        doc = self._model.get_doc(row)
        # Record version in DB
        if status=="Downloaded" and fhash:
            old = self._db.get_ufc_version(doc["filename"])
            self._db.record_ufc_version(
                doc["filename"], doc["id"], fhash,
                (DOWNLOADS_DIR/doc["filename"]).stat().st_size
            )
            if old and old["file_hash"] and old["file_hash"]!=fhash:
                self._model.set_change_flag(row,"↑ Updated")
                self._log.appendPlainText(
                    f"⚠ {doc['id']} version changed — run change detection"
                )
        icon="✓" if status=="Downloaded" else "✗"
        self._log.appendPlainText(
            f"{icon} {doc['id']} — {status}  {size_str}  "
            f"[{time.time()-self._dl_start:.1f}s]"
        )

    def _on_all_done(self, success, fail):
        self._btn_dl.setEnabled(True); self._btn_cancel.setEnabled(False)
        elapsed=time.time()-self._dl_start
        self._lbl_status.setText(f"Done — {success} OK, {fail} failed ({elapsed:.0f}s)")

    def _cancel(self):
        if self._worker: self._worker.cancel()
        self._btn_cancel.setEnabled(False)

    def _check_versions(self):
        """Compare on-disk file hashes against DB-recorded hashes."""
        changed=[]
        for doc in self._catalog:
            p=DOWNLOADS_DIR/doc["filename"]
            if not p.exists(): continue
            old=self._db.get_ufc_version(doc["filename"])
            if not old: continue
            sha=hashlib.sha256(p.read_bytes()).hexdigest()
            if sha!=old["file_hash"]:
                changed.append(doc["id"])
        if changed:
            QMessageBox.information(self,"Version Changes",
                f"{len(changed)} document(s) have changed:\n"+"\n".join(changed))
        else:
            QMessageBox.information(self,"No Changes","All downloaded files match recorded versions.")

    def get_downloaded_docs(self):
        return [doc for doc in self._catalog if (DOWNLOADS_DIR/doc["filename"]).exists()]


# ═══════════════════════════════════════════════════════════════════════════════
# Tab 2 — Extract + INCOSE Score
# ═══════════════════════════════════════════════════════════════════════════════

class ExtractTab(QWidget):
    requirements_ready = Signal(list)

    def __init__(self, dl_tab: DownloadTab, config: AppConfig,
                 db: ProjectDB, parent=None):
        super().__init__(parent)
        self._dl_tab = dl_tab
        self._config = config
        self._db     = db
        self._worker = None
        self._llm_worker = None
        self._all_reqs: list[dict] = []
        self._build_ui()

    def _build_ui(self):
        layout=QVBoxLayout(self)
        layout.setContentsMargins(16,16,16,16); layout.setSpacing(12)

        hdr=QHBoxLayout()
        t=QLabel("Extract & Score"); t.setObjectName("header")
        hdr.addWidget(t); hdr.addStretch()
        self._badge=QLabel("0 requirements"); self._badge.setObjectName("badge")
        self._badge_incose=QLabel("INCOSE: —"); self._badge_incose.setObjectName("badge_warn")
        hdr.addWidget(self._badge_incose); hdr.addWidget(self._badge)
        layout.addLayout(hdr)

        sub=QLabel("Extract requirements from downloaded PDFs, apply heuristic INCOSE scoring, then optionally run LLM classification to remove false positives.")
        sub.setObjectName("subheader"); sub.setWordWrap(True)
        layout.addWidget(sub)

        # Scope
        scope_grp=QGroupBox("Scope & Options")
        sg=QHBoxLayout(scope_grp)
        self._scope_combo=QComboBox()
        self._scope_combo.addItems(["All Downloaded","Selected Category"])
        self._cat_combo=QComboBox()
        cats=sorted({"General","Architecture","Civil","Structural","Mechanical",
                     "Electrical","Fire Protection","Environmental","Security",
                     "Operations","Naval","Facilities"})
        self._cat_combo.addItems(cats); self._cat_combo.setEnabled(False)
        self._scope_combo.currentIndexChanged.connect(
            lambda i: self._cat_combo.setEnabled(i==1))
        sg.addWidget(QLabel("Scope:")); sg.addWidget(self._scope_combo)
        sg.addWidget(self._cat_combo); sg.addStretch()
        layout.addWidget(scope_grp)

        # Progress
        pg=QGroupBox("Progress"); pgL=QVBoxLayout(pg)
        self._prog=QProgressBar(); self._prog.setFormat("%v / %m")
        self._lbl_cur=QLabel("Ready"); self._lbl_cur.setObjectName("subheader")
        pgL.addWidget(self._prog); pgL.addWidget(self._lbl_cur)
        self._ext_log=QPlainTextEdit(); self._ext_log.setReadOnly(True)
        self._ext_log.setMaximumHeight(110); self._ext_log.setFont(QFont("Consolas",10))
        pgL.addWidget(self._ext_log); layout.addWidget(pg)

        # LLM panel
        llm_grp=QGroupBox("LLM Classification (optional — removes false positives)")
        llmL=QHBoxLayout(llm_grp)
        self._lbl_llm_status=QLabel("—"); self._lbl_llm_status.setObjectName("subheader")
        self._btn_llm_classify=QPushButton("Run LLM Classifier")
        self._btn_llm_classify.setObjectName("primary"); self._btn_llm_classify.setEnabled(False)
        self._btn_llm_incose=QPushButton("Run LLM INCOSE Scorer")
        self._btn_llm_incose.setEnabled(False)
        self._chk_llm_filter=QCheckBox("Auto-hide LLM-rejected sentences after classification")
        self._chk_llm_filter.setChecked(True)
        llmL.addWidget(self._btn_llm_classify)
        llmL.addWidget(self._btn_llm_incose)
        llmL.addWidget(self._chk_llm_filter)
        llmL.addStretch()
        llmL.addWidget(self._lbl_llm_status)
        layout.addWidget(llm_grp)

        # Preview
        prev_grp=QGroupBox("Preview — last 300 extracted (double-click to inspect INCOSE breakdown)")
        prevL=QVBoxLayout(prev_grp)
        self._prev_model=RequirementsTableModel()
        self._prev_table=QTableView()
        self._prev_table.setModel(self._prev_model)
        self._prev_table.setAlternatingRowColors(True)
        self._prev_table.verticalHeader().setVisible(False)
        self._prev_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._prev_table.horizontalHeader().resizeSection(0,150)
        self._prev_table.horizontalHeader().resizeSection(4,380)
        self._prev_table.horizontalHeader().setStretchLastSection(True)
        self._prev_table.doubleClicked.connect(self._show_incose_detail)
        prevL.addWidget(self._prev_table); layout.addWidget(prev_grp,1)

        # Buttons
        br=QHBoxLayout(); br.setSpacing(8)
        self._btn_extract=QPushButton("Start Extraction")
        self._btn_extract.setObjectName("primary"); self._btn_extract.setMinimumWidth(150)
        self._btn_cancel=QPushButton("Cancel"); self._btn_cancel.setEnabled(False)
        self._btn_send=QPushButton("Send to Review →")
        self._btn_send.setObjectName("success"); self._btn_send.setEnabled(False)
        self._btn_embed=QPushButton("Embed in Vector DB")
        self._btn_embed.setEnabled(False)
        self._btn_dedup=QPushButton("Find Duplicates")
        self._btn_dedup.setEnabled(False)
        self._btn_clear=QPushButton("Clear")
        br.addStretch()
        for b in (self._btn_clear,self._btn_embed,self._btn_dedup,
                  self._btn_cancel,self._btn_extract,self._btn_send): br.addWidget(b)
        layout.addLayout(br)

        # Connections
        self._btn_extract.clicked.connect(self._start_extract)
        self._btn_cancel.clicked.connect(self._cancel_extract)
        self._btn_send.clicked.connect(self._send_to_review)
        self._btn_clear.clicked.connect(self._clear)
        self._btn_llm_classify.clicked.connect(lambda: self._start_llm(LLMWorker.MODE_CLASSIFY))
        self._btn_llm_incose.clicked.connect(lambda: self._start_llm(LLMWorker.MODE_INCOSE))
        self._btn_embed.clicked.connect(self._start_embed)
        self._btn_dedup.clicked.connect(self._start_dedup)

    def _start_extract(self):
        docs=self._dl_tab.get_downloaded_docs()
        if not docs:
            QMessageBox.information(self,"No PDFs","Download PDFs first."); return
        if self._scope_combo.currentIndex()==1:
            cat=self._cat_combo.currentText()
            docs=[d for d in docs if d["category"]==cat]
        if not docs:
            QMessageBox.information(self,"No PDFs","No downloaded PDFs for selected category."); return
        self._all_reqs=[]; self._prev_model.clear()
        self._badge.setText("0 requirements")
        self._prog.setMaximum(len(docs)); self._prog.setValue(0)
        self._btn_extract.setEnabled(False); self._btn_cancel.setEnabled(True)
        self._btn_send.setEnabled(False); self._btn_llm_classify.setEnabled(False)
        self._btn_llm_incose.setEnabled(False); self._btn_embed.setEnabled(False)
        self._btn_dedup.setEnabled(False)
        self._ext_log.clear()
        self._ext_log.appendPlainText(f"Extracting from {len(docs)} PDFs…")
        self._worker=ExtractionWorker(docs, self._config.get_extraction())
        self._worker.progress.connect(self._on_progress)
        self._worker.found_reqs.connect(self._on_batch)
        self._worker.done.connect(self._on_done)
        self._worker.start()

    def _on_progress(self, cur, total, fn):
        self._prog.setValue(cur)
        self._lbl_cur.setText(f"Processing: {fn}")
        self._ext_log.appendPlainText(f"  [{cur}/{total}] {fn}")

    def _on_batch(self, batch):
        self._all_reqs.extend(batch)
        n=len(self._all_reqs)
        self._badge.setText(f"{n:,} requirements")
        preview=self._all_reqs[-300:]
        self._prev_model.clear()
        self._prev_model.append_rows(preview)
        # Update INCOSE badge
        vals=[r.get("incose_overall") for r in self._all_reqs if r.get("incose_overall") is not None]
        if vals:
            avg=sum(vals)/len(vals)
            self._badge_incose.setText(f"INCOSE avg: {avg:.2f}")

    def _on_done(self, total):
        self._btn_extract.setEnabled(True); self._btn_cancel.setEnabled(False)
        enabled=total>0
        self._btn_send.setEnabled(enabled); self._btn_llm_classify.setEnabled(enabled)
        self._btn_llm_incose.setEnabled(enabled); self._btn_embed.setEnabled(enabled)
        self._btn_dedup.setEnabled(enabled)
        self._ext_log.appendPlainText(f"\nDone — {total:,} requirements extracted")
        self._lbl_cur.setText(f"Complete — {total:,} requirements")

    def _cancel_extract(self):
        if self._worker: self._worker.cancel()
        self._btn_cancel.setEnabled(False)

    def _send_to_review(self):
        self.requirements_ready.emit(self._all_reqs)

    def _clear(self):
        self._all_reqs=[]; self._prev_model.clear()
        self._badge.setText("0 requirements")

    def _start_llm(self, mode):
        items=[{"req_id":r["req_id"],"text":r["text"]} for r in self._all_reqs]
        if not items: return
        cfg=self._config.get_active_llm()
        self._llm_worker=LLMWorker(items, cfg, mode)
        self._btn_llm_classify.setEnabled(False)
        self._btn_llm_incose.setEnabled(False)
        self._lbl_llm_status.setText("LLM running…")
        self._prog.setMaximum(len(items)); self._prog.setValue(0)

        def on_progress(cur, total, req_id):
            self._prog.setValue(cur)
            self._lbl_cur.setText(f"LLM scoring: {req_id}")

        def on_batch(scored):
            # Merge scores back into self._all_reqs
            score_map={s["req_id"]:s for s in scored}
            for r in self._all_reqs:
                if r["req_id"] in score_map:
                    r.update(score_map[r["req_id"]])
            # Refresh preview
            preview=self._all_reqs[-300:]
            self._prev_model.clear(); self._prev_model.append_rows(preview)

        def on_done(processed, errors):
            self._btn_llm_classify.setEnabled(True)
            self._btn_llm_incose.setEnabled(True)
            self._lbl_llm_status.setText(f"LLM done — {processed} scored, {errors} errors")
            # Filter if classify mode
            if mode==LLMWorker.MODE_CLASSIFY and self._chk_llm_filter.isChecked():
                before=len(self._all_reqs)
                self._all_reqs=[r for r in self._all_reqs
                                if r.get("llm_is_requirement") != 0]
                after=len(self._all_reqs)
                self._ext_log.appendPlainText(
                    f"LLM filter: removed {before-after} non-requirements, {after} remain"
                )
                self._badge.setText(f"{after:,} requirements")
                preview=self._all_reqs[-300:]
                self._prev_model.clear(); self._prev_model.append_rows(preview)

        def on_error(msg):
            self._lbl_llm_status.setText(f"LLM error: {msg}")
            self._btn_llm_classify.setEnabled(True)
            self._btn_llm_incose.setEnabled(True)

        self._llm_worker.progress.connect(on_progress)
        self._llm_worker.batch_done.connect(on_batch)
        self._llm_worker.done.connect(on_done)
        self._llm_worker.error.connect(on_error)
        self._llm_worker.start()

    def _start_embed(self):
        if not self._all_reqs: return
        cfg=self._config.get_embedding()
        self._emb_worker=EmbeddingWorker(
            self._all_reqs, cfg, CHROMA_DIR, EmbeddingWorker.MODE_UPSERT)
        self._prog.setMaximum(len(self._all_reqs)); self._prog.setValue(0)
        self._lbl_cur.setText("Embedding requirements…")
        self._emb_worker.progress.connect(
            lambda c,t,m: (self._prog.setValue(c), self._lbl_cur.setText(m)))
        self._emb_worker.done.connect(
            lambda n: self._ext_log.appendPlainText(f"Embedded {n} requirements into ChromaDB"))
        self._emb_worker.error.connect(
            lambda m: self._ext_log.appendPlainText(f"Embedding error: {m}"))
        self._emb_worker.start()

    def _start_dedup(self):
        cfg=self._config.get_embedding()
        self._ded_worker=EmbeddingWorker(
            self._all_reqs, cfg, CHROMA_DIR, EmbeddingWorker.MODE_DEDUP,
            dup_threshold=0.95)
        self._prog.setMaximum(len(self._all_reqs)); self._prog.setValue(0)
        self._lbl_cur.setText("Detecting duplicates…")
        self._ded_worker.progress.connect(
            lambda c,t,m: (self._prog.setValue(c), self._lbl_cur.setText(m)))
        def on_dups(pairs):
            if not pairs:
                self._ext_log.appendPlainText("No near-duplicates found.")
                return
            # Mark in local list
            dup_ids={dup for dup,_,_ in pairs}
            self._all_reqs=[r for r in self._all_reqs if r["req_id"] not in dup_ids]
            self._ext_log.appendPlainText(
                f"Removed {len(pairs)} near-duplicates. {len(self._all_reqs)} unique remain.")
            self._badge.setText(f"{len(self._all_reqs):,} requirements")
            preview=self._all_reqs[-300:]
            self._prev_model.clear(); self._prev_model.append_rows(preview)
        self._ded_worker.duplicates_found.connect(on_dups)
        self._ded_worker.done.connect(
            lambda n: self._ext_log.appendPlainText(f"Dedup complete."))
        self._ded_worker.error.connect(
            lambda m: self._ext_log.appendPlainText(f"Dedup error: {m}"))
        self._ded_worker.start()

    def _show_incose_detail(self, index):
        src=self._prev_model.get_row(index.row())
        lines=[f"<b>Req ID:</b> {src.get('req_id','')}",
               f"<b>Text:</b> {src.get('text','')}","<hr>","<b>INCOSE Scores:</b>"]
        for k in ["score_singular","score_verifiable","score_unambiguous",
                  "score_complete","score_traceable","score_feasible"]:
            v=src.get(k)
            label=k.replace("score_","").title()
            bar="█"*int((v or 0)*10)+"░"*(10-int((v or 0)*10))
            lines.append(f"&nbsp;&nbsp;{label}: {bar} {v:.2f}" if v is not None else f"&nbsp;&nbsp;{label}: —")
        lines.append(f"<b>Overall:</b> {src.get('incose_overall','—')}")
        if src.get("llm_rationale"):
            lines.append(f"<b>LLM Rationale:</b> {src['llm_rationale']}")
        dlg=QDialog(self); dlg.setWindowTitle("INCOSE Detail")
        dlg.resize(600,360)
        v=QVBoxLayout(dlg)
        te=QTextEdit(); te.setReadOnly(True)
        te.setHtml("<br>".join(lines)); v.addWidget(te)
        bb=QDialogButtonBox(QDialogButtonBox.Ok)
        bb.accepted.connect(dlg.accept); v.addWidget(bb)
        dlg.exec()

    def get_requirements(self): return self._all_reqs


# ═══════════════════════════════════════════════════════════════════════════════
# Tab 3 — Review & Allocation (with RTM + Audit Log)
# ═══════════════════════════════════════════════════════════════════════════════

class ReviewTab(QWidget):
    def __init__(self, config: AppConfig, db: ProjectDB, parent=None):
        super().__init__(parent)
        self._config = config
        self._db     = db
        self._model  = RequirementsTableModel()
        self._current_src_row = None
        self._build_ui()

    def _build_ui(self):
        layout=QVBoxLayout(self); layout.setContentsMargins(16,16,16,16); layout.setSpacing(12)

        hdr=QHBoxLayout()
        t=QLabel("Review & Allocation"); t.setObjectName("header")
        hdr.addWidget(t); hdr.addStretch()
        self._badge_total   =QLabel("0"); self._badge_total.setObjectName("badge")
        self._badge_reviewed=QLabel("0 reviewed"); self._badge_reviewed.setObjectName("badge_warn")
        self._badge_incose  =QLabel("INCOSE —"); self._badge_incose.setObjectName("badge_warn")
        for b in (self._badge_incose,self._badge_reviewed,self._badge_total): hdr.addWidget(b)
        layout.addLayout(hdr)

        # Filter bar
        flt=QHBoxLayout(); flt.setSpacing(8)
        self._search=QLineEdit(); self._search.setPlaceholderText("Search text…")
        self._search.setMinimumWidth(220)
        self._flt_status=QComboBox(); self._flt_status.addItem("All Statuses"); self._flt_status.addItems(STATUS_LABELS)
        self._flt_prio  =QComboBox(); self._flt_prio.addItem("All Priorities"); self._flt_prio.addItems(PRIORITY_LABELS)
        self._flt_disc  =QComboBox(); self._flt_disc.addItem("All Disciplines"); self._flt_disc.addItems(DISCIPLINE_LABELS)
        self._flt_src   =QComboBox(); self._flt_src.addItem("All Sources")
        self._flt_llm   =QComboBox(); self._flt_llm.addItems(["All LLM","Confirmed","Rejected by LLM","Unscored"])
        self._flt_incose=QComboBox(); self._flt_incose.addItems(["All Scores","Score ≥0.8","Score 0.6–0.8","Score <0.6"])
        for w in (self._search,self._flt_status,self._flt_prio,self._flt_disc,
                  self._flt_src,self._flt_llm,self._flt_incose): flt.addWidget(w)
        flt.addStretch()
        self._btn_reset_flt=QPushButton("Reset")
        self._btn_reset_flt.setFixedWidth(60); flt.addWidget(self._btn_reset_flt)
        layout.addLayout(flt)

        # Main splitter
        splitter=QSplitter(Qt.Vertical)

        # Table
        self._proxy=QSortFilterProxyModel()
        self._proxy.setSourceModel(self._model)
        self._proxy.setFilterCaseSensitivity(Qt.CaseInsensitive)
        self._proxy.setFilterKeyColumn(-1)
        self._table=QTableView(); self._table.setModel(self._proxy)
        self._table.setAlternatingRowColors(True)
        self._table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._table.setSortingEnabled(True)
        self._table.verticalHeader().setVisible(False)
        self._table.setEditTriggers(QAbstractItemView.DoubleClicked|QAbstractItemView.SelectedClicked)
        hh=self._table.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.Interactive)
        for col,w in [(0,155),(1,95),(2,45),(3,140),(4,360),(5,60),(6,65),(7,70),(8,85),(9,120),(10,95)]:
            hh.resizeSection(col,w)
        hh.setStretchLastSection(True)
        self._table.setItemDelegateForColumn(8,ComboDelegate(PRIORITY_LABELS,self))
        self._table.setItemDelegateForColumn(9,ComboDelegate(DISCIPLINE_LABELS,self))
        self._table.setItemDelegateForColumn(10,ComboDelegate(STATUS_LABELS,self))
        splitter.addWidget(self._table)

        # Detail pane
        detail=QWidget(); detL=QVBoxLayout(detail); detL.setContentsMargins(0,0,0,0); detL.setSpacing(8)
        dh=QHBoxLayout()
        dh.addWidget(QLabel("Detail"))

        # Tab bar inside detail
        self._det_tabs=QTabWidget()
        self._det_tabs.setMaximumHeight(260)

        # Detail > Text
        dt_widget=QWidget(); dt_layout=QVBoxLayout(dt_widget); dt_layout.setContentsMargins(4,4,4,4)
        self._detail_text=QTextEdit(); self._detail_text.setReadOnly(True)
        dt_layout.addWidget(self._detail_text)
        self._det_tabs.addTab(dt_widget,"Requirement")

        # Detail > INCOSE breakdown
        inc_widget=QWidget(); inc_layout=QVBoxLayout(inc_widget); inc_layout.setContentsMargins(4,4,4,4)
        self._incose_text=QTextEdit(); self._incose_text.setReadOnly(True)
        inc_layout.addWidget(self._incose_text)
        self._det_tabs.addTab(inc_widget,"INCOSE Scores")

        # Detail > Notes
        notes_widget=QWidget(); notes_layout=QVBoxLayout(notes_widget)
        notes_layout.setContentsMargins(4,4,4,4); notes_layout.setSpacing(4)
        nh=QHBoxLayout()
        nh.addWidget(QLabel("Notes / Allocation:"))
        self._fld_assigned=QLineEdit(); self._fld_assigned.setPlaceholderText("Assigned to…")
        self._fld_assigned.setFixedWidth(180)
        nh.addWidget(self._fld_assigned)
        self._btn_save_note=QPushButton("Save")
        self._btn_save_note.setFixedWidth(60); nh.addWidget(self._btn_save_note)
        nh.addStretch(); notes_layout.addLayout(nh)
        self._notes_edit=QTextEdit()
        self._notes_edit.setPlaceholderText("Allocation rationale, cross-references, action items…")
        notes_layout.addWidget(self._notes_edit)
        self._det_tabs.addTab(notes_widget,"Notes")

        # Detail > Audit log
        audit_widget=QWidget(); audit_layout=QVBoxLayout(audit_widget)
        audit_layout.setContentsMargins(4,4,4,4)
        self._audit_text=QPlainTextEdit(); self._audit_text.setReadOnly(True)
        self._audit_text.setFont(QFont("Consolas",10))
        audit_layout.addWidget(self._audit_text)
        self._det_tabs.addTab(audit_widget,"Audit Log")

        detL.addWidget(self._det_tabs)

        # Quick-set bar
        qs=QHBoxLayout()
        qs.addWidget(QLabel("Quick Set:"))
        for lbl,col,val,obj in [
            ("✓ Accept",10,"Accepted","success"),
            ("✗ Reject",10,"Rejected","danger"),
            ("⏸ Defer", 10,"Deferred",None),
            ("🔴 Critical",8,"Critical",None),
            ("🟡 High",8,"High",None),
        ]:
            b=QPushButton(lbl); b.setFixedWidth(95)
            if obj: b.setObjectName(obj)
            b.clicked.connect(lambda _,c=col,v=val: self._quick_set(c,v))
            qs.addWidget(b)
        qs.addStretch()
        detL.addLayout(qs)

        splitter.addWidget(detail)
        splitter.setSizes([520,260])
        layout.addWidget(splitter,1)

        # Bottom stats + export
        bot=QHBoxLayout(); bot.setSpacing(8)
        self._lbl_stats=QLabel(""); self._lbl_stats.setObjectName("subheader")
        bot.addWidget(self._lbl_stats); bot.addStretch()
        self._btn_rtm=QPushButton("View RTM")
        self._btn_load=QPushButton("Load from DB")
        self._btn_save_db=QPushButton("Save to DB")
        self._btn_csv=QPushButton("Export CSV")
        self._btn_excel=QPushButton("Export Excel")
        self._btn_reqif=QPushButton("Export ReqIF")
        self._btn_clear=QPushButton("Clear"); self._btn_clear.setObjectName("danger")
        for b in (self._btn_rtm,self._btn_load,self._btn_save_db,
                  self._btn_csv,self._btn_excel,self._btn_reqif,self._btn_clear):
            bot.addWidget(b)
        layout.addLayout(bot)

        # Connections
        self._search.textChanged.connect(self._apply_text_filter)
        for combo in (self._flt_status,self._flt_prio,self._flt_disc,
                      self._flt_src,self._flt_llm,self._flt_incose):
            combo.currentTextChanged.connect(lambda _: self._apply_text_filter())
        self._btn_reset_flt.clicked.connect(self._reset_filters)
        self._table.selectionModel().currentRowChanged.connect(self._on_row_changed)
        self._btn_save_note.clicked.connect(self._save_note)
        self._model.dataChanged.connect(self._update_stats)
        self._btn_rtm.clicked.connect(self._show_rtm)
        self._btn_load.clicked.connect(self._load_from_db)
        self._btn_save_db.clicked.connect(self._save_to_db)
        self._btn_csv.clicked.connect(self._export_csv)
        self._btn_excel.clicked.connect(self._export_excel)
        self._btn_reqif.clicked.connect(self._export_reqif)
        self._btn_clear.clicked.connect(self._clear_all)

    # ── Data ──

    def load_requirements(self, reqs):
        self._model.load(reqs)
        self._update_source_filter()
        self._update_stats()
        self._badge_total.setText(f"{len(reqs):,}")

    def _update_source_filter(self):
        srcs=sorted({r.get("source_ufc",r.get("source","")) for r in self._model.get_all()})
        self._flt_src.clear(); self._flt_src.addItem("All Sources")
        self._flt_src.addItems(srcs)

    # ── Filters ──

    def _apply_text_filter(self):
        text=self._search.text()
        self._proxy.setFilterFixedString(text)

    def _reset_filters(self):
        self._search.clear()
        for c in (self._flt_status,self._flt_prio,self._flt_disc,
                  self._flt_src,self._flt_llm,self._flt_incose):
            c.setCurrentIndex(0)
        self._proxy.setFilterFixedString("")

    # ── Detail pane ──

    def _on_row_changed(self, current, previous):
        if not current.isValid(): return
        src=self._proxy.mapToSource(current)
        r=self._model.get_row(src.row())
        self._current_src_row=src.row()

        # Main text
        html=(f"<div style='font-family:Consolas;font-size:11px;color:{TEXT_MUTED}'>"
              f"{r.get('req_id','')} | {r.get('source_ufc',r.get('source',''))}"
              f" | Pg {r.get('page','')} | <i>{str(r.get('section',''))[:80]}</i></div>"
              f"<div style='font-size:14px;margin-top:8px;color:{TEXT_MAIN}'>{r.get('text','')}</div>"
              f"<div style='margin-top:6px;font-size:12px;color:{ACCENT}'>"
              f"Keyword: <b>{r.get('keyword','')}</b> &nbsp; "
              f"Priority: <b>{r.get('priority','')}</b> &nbsp; "
              f"Discipline: <b>{r.get('discipline','')}</b> &nbsp; "
              f"Status: <b>{r.get('status','')}</b></div>")
        self._detail_text.setHtml(html)

        # INCOSE breakdown
        inc_lines=[]
        for k in ["score_singular","score_verifiable","score_unambiguous",
                  "score_complete","score_traceable","score_feasible"]:
            v=r.get(k)
            label=k.replace("score_","").title()
            if v is not None:
                bar="█"*int(v*10)+"░"*(10-int(v*10))
                color=SUCCESS if v>=0.8 else (WARNING if v>=0.6 else ERROR)
                inc_lines.append(
                    f"<div>{label}: <span style='font-family:monospace;color:{color}'>{bar}</span> {v:.2f}</div>"
                )
        ov=r.get("incose_overall")
        inc_lines.append(f"<div style='margin-top:6px'><b>Overall: {ov:.2f}</b></div>" if ov else "")
        llm_conf=r.get("llm_confidence")
        llm_req =r.get("llm_is_requirement")
        if llm_req is not None:
            inc_lines.append(
                f"<div style='margin-top:4px;color:{ACCENT}'>"
                f"LLM: {'✓ Requirement' if llm_req else '✗ Not requirement'}"
                f"{f' ({llm_conf:.0%})' if llm_conf else ''}"
                f"</div>"
            )
        if r.get("llm_rationale"):
            inc_lines.append(f"<div style='color:{TEXT_MUTED}'>{r['llm_rationale']}</div>")
        self._incose_text.setHtml("".join(inc_lines))

        # Notes
        self._notes_edit.setPlainText(r.get("notes",""))
        self._fld_assigned.setText(r.get("assigned_to",""))

        # Audit log from DB
        audit=self._db.get_audit_log(r.get("req_id"))
        lines=[]
        for a in audit[:50]:
            lines.append(f"{a.get('changed_at','')[:19]}  {a.get('field','')}: "
                         f"'{a.get('old_value','')}' → '{a.get('new_value','')}'")
        self._audit_text.setPlainText("\n".join(lines) if lines else "No audit history")

    def _quick_set(self, col, value):
        col_keys={8:"priority",9:"discipline",10:"status"}
        sel=self._table.selectionModel().selectedRows()
        for pi in sel:
            si=self._proxy.mapToSource(pi)
            mi=self._model.index(si.row(),col)
            self._model.setData(mi,value,Qt.EditRole)
            req_id=self._model.get_row(si.row()).get("req_id","")
            if req_id and col in col_keys:
                try: self._db.update_requirement_field(req_id,col_keys[col],value)
                except: pass
        self._update_stats()

    def _save_note(self):
        if self._current_src_row is None: return
        note=self._notes_edit.toPlainText()
        assigned=self._fld_assigned.text().strip()
        mi_note=self._model.index(self._current_src_row,11)
        self._model.setData(mi_note,note,Qt.EditRole)
        r=self._model.get_row(self._current_src_row)
        req_id=r.get("req_id","")
        if req_id:
            try:
                self._db.update_requirement_field(req_id,"notes",note)
                if assigned:
                    self._db.update_requirement_field(req_id,"assigned_to",assigned)
            except: pass

    # ── Stats ──

    def _update_stats(self):
        rows=self._model.get_all(); total=len(rows)
        reviewed=sum(1 for r in rows if r.get("status")!="Unreviewed")
        accepted=sum(1 for r in rows if r.get("status")=="Accepted")
        rejected=sum(1 for r in rows if r.get("status")=="Rejected")
        vals=[r.get("incose_overall") for r in rows if r.get("incose_overall") is not None]
        avg_inc=sum(vals)/len(vals) if vals else None
        self._badge_total.setText(f"{total:,}")
        self._badge_reviewed.setText(f"{reviewed:,} reviewed")
        if avg_inc is not None:
            self._badge_incose.setText(f"INCOSE {avg_inc:.2f}")
        self._lbl_stats.setText(
            f"Accepted {accepted} | Rejected {rejected} | Remaining {total-reviewed}")

    # ── RTM dialog ──

    def _show_rtm(self):
        rtm=self._db.get_rtm()
        orphans=self._db.get_orphans()
        dlg=QDialog(self); dlg.setWindowTitle("Requirement Traceability Matrix")
        dlg.resize(1100,600)
        v=QVBoxLayout(dlg)

        tabs=QTabWidget()

        # RTM table
        rtm_widget=QWidget(); rtm_layout=QVBoxLayout(rtm_widget)
        if rtm:
            tbl=QTableWidget(len(rtm),7)
            tbl.setHorizontalHeaderLabels([
                "Parent ID","Parent Source","Parent Text",
                "Link","Child ID","Child Source","Child Status"])
            for i,row in enumerate(rtm):
                for j,key in enumerate(["parent_req_id","parent_source","parent_text",
                                         "link_type","child_req_id","child_source","child_status"]):
                    item=QTableWidgetItem(str(row.get(key,""))[:120])
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                    tbl.setItem(i,j,item)
            tbl.horizontalHeader().setStretchLastSection(True)
            tbl.resizeColumnsToContents()
            rtm_layout.addWidget(tbl)
        else:
            rtm_layout.addWidget(QLabel("No traceability links defined yet. Use 'Link' button in the review table."))

        tabs.addTab(rtm_widget,"Allocations")

        # Orphans
        orp_widget=QWidget(); orp_layout=QVBoxLayout(orp_widget)
        orp_lbl=QLabel(f"{len(orphans)} unallocated requirements (no parent/child links)")
        orp_lbl.setObjectName("subheader"); orp_layout.addWidget(orp_lbl)
        if orphans:
            otbl=QTableWidget(len(orphans),4)
            otbl.setHorizontalHeaderLabels(["Req ID","Source","Status","Text"])
            for i,r in enumerate(orphans):
                for j,k in enumerate(["req_id","source_ufc","status","text"]):
                    it=QTableWidgetItem(str(r.get(k,""))[:100])
                    it.setFlags(it.flags() & ~Qt.ItemIsEditable)
                    otbl.setItem(i,j,it)
            otbl.horizontalHeader().setStretchLastSection(True)
            orp_layout.addWidget(otbl)
        tabs.addTab(orp_widget,f"Orphans ({len(orphans)})")

        v.addWidget(tabs)
        bb=QDialogButtonBox(QDialogButtonBox.Close)
        bb.rejected.connect(dlg.reject); v.addWidget(bb)
        dlg.exec()

    # ── DB persistence ──

    def _save_to_db(self):
        rows=self._model.get_all()
        ins,upd=self._db.upsert_requirements(rows)
        # Also push INCOSE scores
        scored=[r for r in rows if r.get("incose_overall") is not None]
        if scored: self._db.bulk_update_incose_scores(scored)
        llm_scored=[r for r in rows if r.get("llm_is_requirement") is not None]
        if llm_scored: self._db.bulk_update_llm_scores(llm_scored)
        QMessageBox.information(self,"Saved",
            f"Saved to project DB: {ins} inserted, {upd} updated.")

    def _load_from_db(self):
        rows=self._db.get_requirements()
        if not rows:
            QMessageBox.information(self,"Empty","No requirements in project database."); return
        self.load_requirements(rows)

    # ── Exports ──

    def _export_csv(self):
        ts=datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path,_=QFileDialog.getSaveFileName(self,"Export CSV",
            str(EXPORTS_DIR/f"ufc_req_{ts}.csv"),"CSV (*.csv)")
        if not path: return
        rows=self._model.get_all()
        fields=["req_id","source_ufc","page","section","text","keyword",
                "incose_overall","score_singular","score_verifiable","score_unambiguous",
                "score_complete","score_traceable","score_feasible",
                "llm_is_requirement","llm_confidence","llm_rationale",
                "priority","discipline","status","notes","assigned_to"]
        with open(path,"w",newline="",encoding="utf-8-sig") as f:
            w=csv.DictWriter(f,fieldnames=fields,extrasaction="ignore")
            w.writeheader(); w.writerows(rows)
        QMessageBox.information(self,"Exported",f"{len(rows)} requirements → {Path(path).name}")

    def _export_excel(self):
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
            from openpyxl.utils import get_column_letter
        except ImportError:
            QMessageBox.warning(self,"Missing","pip install openpyxl"); return
        ts=datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path,_=QFileDialog.getSaveFileName(self,"Export Excel",
            str(EXPORTS_DIR/f"ufc_req_{ts}.xlsx"),"Excel (*.xlsx)")
        if not path: return
        rows=self._model.get_all()
        wb=openpyxl.Workbook(); ws=wb.active; ws.title="Requirements"
        hdr_fill=PatternFill("solid",fgColor="1A4A50")
        hdr_font=Font(bold=True,color="FFFFFF",size=10)
        thin=Side(style='thin',color="3A4050"); brd=Border(left=thin,right=thin,top=thin,bottom=thin)
        headers=["Req ID","Source","Pg","Section","Text","Keyword",
                 "INCOSE","Singular","Verifiable","Unambiguous","Complete","Traceable","Feasible",
                 "LLM","LLM Conf","LLM Note","Priority","Discipline","Status","Notes","Assigned"]
        fields =["req_id","source_ufc","page","section","text","keyword",
                 "incose_overall","score_singular","score_verifiable","score_unambiguous",
                 "score_complete","score_traceable","score_feasible",
                 "llm_is_requirement","llm_confidence","llm_rationale",
                 "priority","discipline","status","notes","assigned_to"]
        for col,h in enumerate(headers,1):
            c=ws.cell(row=1,column=col,value=h)
            c.fill=hdr_fill; c.font=hdr_font
            c.alignment=Alignment(horizontal="center"); c.border=brd
        ws.freeze_panes="A2"; ws.row_dimensions[1].height=22
        status_fills={"Accepted":PatternFill("solid",fgColor="1A4A30"),
                      "Rejected":PatternFill("solid",fgColor="4A1A1A"),
                      "Deferred":PatternFill("solid",fgColor="4A3A10")}
        for ri,r in enumerate(rows,2):
            sf=status_fills.get(r.get("status",""))
            for ci,key in enumerate(fields,1):
                val=r.get(key,"")
                if isinstance(val,float): val=round(val,3)
                c=ws.cell(row=ri,column=ci,value=val)
                c.alignment=Alignment(vertical="top",wrap_text=(ci==5))
                c.border=brd
                if sf: c.fill=sf
        for i,w in enumerate([18,10,5,20,60,8,8,8,8,8,8,8,8,6,7,25,10,16,12,30,15],1):
            ws.column_dimensions[get_column_letter(i)].width=w
        ws.auto_filter.ref=f"A1:{get_column_letter(len(headers))}1"
        # Stats sheet
        ws2=wb.create_sheet("Summary"); ws2["A1"]="UFC Requirements Export"
        ws2["A1"].font=Font(bold=True,size=14)
        ws2["A3"]="Generated:"; ws2["B3"]=datetime.datetime.now().isoformat()
        ws2["A4"]="Total:";     ws2["B4"]=len(rows)
        ws2["A5"]="Reviewed:";  ws2["B5"]=sum(1 for r in rows if r.get("status")!="Unreviewed")
        ws2["A6"]="Accepted:";  ws2["B6"]=sum(1 for r in rows if r.get("status")=="Accepted")
        ws2["A7"]="Rejected:";  ws2["B7"]=sum(1 for r in rows if r.get("status")=="Rejected")
        vals=[r.get("incose_overall") for r in rows if r.get("incose_overall") is not None]
        ws2["A8"]="Avg INCOSE:"; ws2["B8"]=round(sum(vals)/len(vals),3) if vals else "—"
        wb.save(path)
        QMessageBox.information(self,"Exported",f"{len(rows)} → {Path(path).name}")

    def _export_reqif(self):
        ts=datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path,_=QFileDialog.getSaveFileName(self,"Export ReqIF",
            str(EXPORTS_DIR/f"ufc_req_{ts}.reqif"),"ReqIF (*.reqif);;XML (*.xml)")
        if not path: return
        from core.reqif_export import export_reqif
        rows=self._model.get_all()
        allocs=self._db.get_rtm()
        project_name=self._db.get_meta("project_name","UFC Requirements")
        try:
            out=export_reqif(rows,allocs,path,project_name)
            QMessageBox.information(self,"Exported",
                f"ReqIF exported: {len(rows)} requirements → {Path(path).name}\n"
                "Compatible with DOORS NG, Jama, Polarion, Reqtify.")
        except Exception as e:
            QMessageBox.critical(self,"Export Error",str(e))

    def _clear_all(self):
        if QMessageBox.question(self,"Clear","Clear all requirements?",
            QMessageBox.Yes|QMessageBox.No)==QMessageBox.Yes:
            self._model.clear(); self._update_stats()


# ═══════════════════════════════════════════════════════════════════════════════
# Tab 4 — Semantic Search
# ═══════════════════════════════════════════════════════════════════════════════

class SearchTab(QWidget):
    def __init__(self, config: AppConfig, db: ProjectDB, parent=None):
        super().__init__(parent)
        self._config = config
        self._db     = db
        self._build_ui()

    def _build_ui(self):
        layout=QVBoxLayout(self); layout.setContentsMargins(16,16,16,16); layout.setSpacing(12)

        hdr=QLabel("Semantic Search"); hdr.setObjectName("header")
        layout.addWidget(hdr)
        sub=QLabel("Natural language search across embedded requirements using ChromaDB vector similarity. Requires Embed step in Extract tab.")
        sub.setObjectName("subheader"); sub.setWordWrap(True)
        layout.addWidget(sub)

        # Query bar
        qg=QGroupBox("Query")
        qL=QHBoxLayout(qg)
        self._query=QLineEdit()
        self._query.setPlaceholderText(
            "e.g., blast resistance requirements for exterior walls")
        self._query.returnPressed.connect(self._search)
        self._k_spin=QSpinBox(); self._k_spin.setRange(5,100)
        self._k_spin.setValue(20); self._k_spin.setPrefix("Top-K: ")
        self._k_spin.setFixedWidth(100)
        self._src_filter=QComboBox(); self._src_filter.addItem("All Sources")
        self._btn_search=QPushButton("Search")
        self._btn_search.setObjectName("primary")
        qL.addWidget(self._query,1); qL.addWidget(self._k_spin)
        qL.addWidget(self._src_filter); qL.addWidget(self._btn_search)
        layout.addWidget(qg)

        # Status
        self._lbl_status=QLabel(""); self._lbl_status.setObjectName("subheader")
        layout.addWidget(self._lbl_status)

        # Results table
        self._results_table=QTableWidget()
        self._results_table.setColumnCount(5)
        self._results_table.setHorizontalHeaderLabels(
            ["Score","Req ID","Source","Page","Requirement Text"])
        self._results_table.horizontalHeader().setStretchLastSection(True)
        self._results_table.setAlternatingRowColors(True)
        self._results_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._results_table.verticalHeader().setVisible(False)
        self._results_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._results_table.horizontalHeader().resizeSection(0,70)
        self._results_table.horizontalHeader().resizeSection(1,155)
        self._results_table.horizontalHeader().resizeSection(2,95)
        self._results_table.horizontalHeader().resizeSection(3,50)
        layout.addWidget(self._results_table,1)

        # RAG Answer panel
        rag_grp=QGroupBox("AI Answer (RAG — uses LLM to synthesise search results)")
        ragL=QVBoxLayout(rag_grp)
        self._btn_rag=QPushButton("Generate AI Answer from Results")
        self._btn_rag.setObjectName("primary"); self._btn_rag.setEnabled(False)
        self._rag_answer=QTextEdit(); self._rag_answer.setReadOnly(True)
        self._rag_answer.setMaximumHeight(160)
        self._rag_answer.setPlaceholderText("AI synthesised answer will appear here…")
        ragL.addWidget(self._btn_rag); ragL.addWidget(self._rag_answer)
        layout.addWidget(rag_grp)

        self._btn_search.clicked.connect(self._search)
        self._btn_rag.clicked.connect(self._run_rag)

    def refresh_sources(self, sources: list[str]):
        self._src_filter.clear()
        self._src_filter.addItem("All Sources")
        self._src_filter.addItems(sources)

    def _search(self):
        query=self._query.text().strip()
        if not query:
            QMessageBox.information(self,"No Query","Enter a search query."); return
        cfg=self._config.get_embedding()
        try:
            from core.embeddings import EmbeddingClient, VectorStore
            ec=EmbeddingClient(cfg.base_url,cfg.model,cfg.api_key)
            vs=VectorStore(CHROMA_DIR,ec)
        except ImportError as e:
            QMessageBox.warning(self,"Missing Packages",str(e)); return
        except Exception as e:
            QMessageBox.warning(self,"ChromaDB Error",str(e)); return

        src_filter=self._src_filter.currentText()
        if src_filter=="All Sources": src_filter=None
        k=self._k_spin.value()

        self._lbl_status.setText("Searching…")
        try:
            results=vs.search(query, k, src_filter)
        except Exception as e:
            self._lbl_status.setText(f"Search failed: {e}"); return

        self._results_table.setRowCount(len(results))
        for i,r in enumerate(results):
            score_item=QTableWidgetItem(f"{r.score:.3f}")
            score_item.setForeground(QColor(SUCCESS if r.score>=0.8 else
                                     ACCENT if r.score>=0.6 else WARNING))
            self._results_table.setItem(i,0,score_item)
            for j,val in enumerate([r.req_id,r.source_ufc,""]):
                self._results_table.setItem(i,j+1,QTableWidgetItem(val))
            self._results_table.setItem(i,4,QTableWidgetItem(r.text))

        self._lbl_status.setText(f"{len(results)} results for: '{query}'")
        self._btn_rag.setEnabled(len(results)>0)
        self._last_results=results
        self._last_query=query

    def _run_rag(self):
        if not hasattr(self,"_last_results") or not self._last_results: return
        context="\n\n".join(
            f"[{r.source_ufc}] {r.text}" for r in self._last_results[:10]
        )
        system=(
            "You are a systems engineer specialising in DoD facility design requirements. "
            "Answer the user's question using ONLY the UFC requirement excerpts provided. "
            "Cite source UFC IDs. Be concise and precise."
        )
        user=(
            f"Question: {self._last_query}\n\n"
            f"UFC Requirement Excerpts:\n{context}"
        )
        cfg=self._config.get_active_llm()
        try:
            from core.llm_client import LLMClient
            client=LLMClient(cfg)
            self._rag_answer.setPlainText("Generating answer…")
            answer=client.ask(system,user,max_tokens=512)
            self._rag_answer.setPlainText(answer)
        except Exception as e:
            self._rag_answer.setPlainText(f"Error: {e}")


# ═══════════════════════════════════════════════════════════════════════════════
# Tab 5 — Analytics Dashboard
# ═══════════════════════════════════════════════════════════════════════════════

class AnalyticsTab(QWidget):
    def __init__(self, db: ProjectDB, parent=None):
        super().__init__(parent)
        self._db=db
        self._build_ui()

    def _build_ui(self):
        layout=QVBoxLayout(self); layout.setContentsMargins(16,16,16,16); layout.setSpacing(12)
        hdr=QLabel("Project Analytics"); hdr.setObjectName("header")
        layout.addWidget(hdr)
        sub=QLabel("Live statistics from the project database. Refresh after saving requirements.")
        sub.setObjectName("subheader"); layout.addWidget(sub)
        self._btn_refresh=QPushButton("Refresh Stats")
        self._btn_refresh.setFixedWidth(140); layout.addWidget(self._btn_refresh)
        self._stats_text=QTextEdit(); self._stats_text.setReadOnly(True)
        layout.addWidget(self._stats_text,1)
        self._btn_refresh.clicked.connect(self.refresh)

    def refresh(self):
        s=self._db.get_stats()
        total=s.get("total",0)
        def pct(n): return f"{n/total*100:.1f}%" if total else "—"
        html_parts=[
            f"<h3 style='color:{ACCENT}'>Project Requirements Statistics</h3>",
            f"<p><b>Total:</b> {total:,} &nbsp;&nbsp; "
            f"<b>Unique (deduped):</b> {s.get('unique',total):,} &nbsp;&nbsp; "
            f"<b>Duplicates:</b> {s.get('duplicates',0):,}</p>",
            "<hr>",
            f"<h4>Review Progress</h4>",
            f"<p>Reviewed: {s.get('reviewed',0):,} ({pct(s.get('reviewed',0))})<br>",
            f"Accepted: {s.get('accepted',0):,} ({pct(s.get('accepted',0))})<br>",
            f"Rejected: {s.get('rejected',0):,} ({pct(s.get('rejected',0))})<br>",
            f"Deferred: {s.get('deferred',0):,} ({pct(s.get('deferred',0))})</p>",
            "<hr>",
            f"<h4>LLM Classification</h4>",
            f"<p>Confirmed requirements: {s.get('llm_confirmed',0):,}<br>",
            f"Rejected by LLM: {s.get('llm_rejected',0):,}</p>",
            "<hr>",
            f"<h4>Traceability</h4>",
            f"<p>Allocation links: {s.get('allocations',0):,}</p>",
            "<hr>",
            f"<h4>By Source UFC</h4><ul>",
        ]
        for src,n in sorted(s.get("by_source",{}).items(), key=lambda x:-x[1]):
            html_parts.append(f"<li>{src}: {n:,}</li>")
        html_parts.append("</ul>")
        self._stats_text.setHtml("".join(html_parts))


# ═══════════════════════════════════════════════════════════════════════════════
# Main Window
# ═══════════════════════════════════════════════════════════════════════════════

class MainWindow(QMainWindow):
    def __init__(self, config: AppConfig, db: ProjectDB, catalog: list):
        super().__init__()
        self._config  = config
        self._db      = db
        self._catalog = catalog
        proj_name=db.get_meta("project_name","UFC Project")
        self.setWindowTitle(f"UFC Requirements Tool v2 — {proj_name}")
        self.resize(1440,900); self.setMinimumSize(900,600)
        self._build_ui()

    def _build_ui(self):
        central=QWidget(); self.setCentralWidget(central)
        ml=QVBoxLayout(central); ml.setContentsMargins(0,0,0,0); ml.setSpacing(0)

        # Banner
        banner=QWidget(); banner.setFixedHeight(52)
        banner.setStyleSheet(
            f"background: qlineargradient(x1:0,y1:0,x2:1,y2:0,"
            f"stop:0 #0D3540, stop:1 {DARK_SURF2});"
            f"border-bottom: 2px solid {ACCENT};"
        )
        bL=QHBoxLayout(banner); bL.setContentsMargins(16,0,16,0)
        logo=QLabel("UFC"); logo.setStyleSheet(
            f"color:{ACCENT};font-size:24px;font-weight:900;"
            f"letter-spacing:4px;font-family:'Segoe UI';")
        ttl=QLabel("Requirements Tool v2")
        ttl.setStyleSheet(f"color:{TEXT_MAIN};font-size:16px;font-weight:600;")
        proj=QLabel(f"Project: {self._db.get_meta('project_name','—')}")
        proj.setStyleSheet(f"color:{TEXT_MUTED};font-size:12px;")
        bL.addWidget(logo); bL.addSpacing(12); bL.addWidget(ttl)
        bL.addSpacing(16); bL.addWidget(proj); bL.addStretch()

        # Settings button in banner
        self._btn_settings=QToolButton()
        self._btn_settings.setText("⚙ Settings")
        self._btn_settings.setStyleSheet(
            f"color:{TEXT_MUTED};background:transparent;border:none;"
            f"font-size:13px;padding:4px 8px;")
        self._btn_settings.clicked.connect(self._open_settings)
        bL.addWidget(self._btn_settings)
        ml.addWidget(banner)

        # Tabs
        self._tabs=QTabWidget()
        self._lib_mgr     = LibraryManager(self._db)
        self._dl_tab      = DownloadTab(self._catalog, self._config, self._db)
        self._ext_tab     = ExtractTab(self._dl_tab, self._config, self._db)
        self._lib_tab     = LibraryTab(self._lib_mgr, self._config, self._db)
        self._review_tab  = ReviewTab(self._config, self._db)
        self._search_tab  = SearchTab(self._config, self._db)
        self._analytics   = AnalyticsTab(self._db)

        self._tabs.addTab(self._lib_tab,    "  Library   ")
        self._tabs.addTab(self._dl_tab,     "  Download  ")
        self._tabs.addTab(self._ext_tab,    "  Extract   ")
        self._tabs.addTab(self._review_tab, "  Review    ")
        self._tabs.addTab(self._search_tab, "  Search    ")
        self._tabs.addTab(self._analytics,  "  Analytics ")
        ml.addWidget(self._tabs,1)

        # Status bar
        self._status=QStatusBar(); self.setStatusBar(self._status)
        db_size=Path(self._db.path).stat().st_size/1024 if Path(self._db.path).exists() else 0
        self._status.showMessage(
            f"{len(self._catalog)} UFC docs  |  "
            f"Library: {self._lib_mgr.count()} docs  |  "
            f"DB: {Path(self._db.path).name} ({db_size:.0f} KB)  |  "
            f"Downloads: {DOWNLOADS_DIR}"
        )
        self._build_menu()

        # Wire signals
        self._ext_tab.requirements_ready.connect(self._on_reqs_ready)
        self._lib_tab.extraction_ready.connect(self._on_reqs_ready)
        self._tabs.currentChanged.connect(self._on_tab_changed)

    def _build_menu(self):
        mb=self.menuBar()
        f=mb.addMenu("File")
        f.addAction("New Project",  self._new_project)
        f.addAction("Open Project", self._open_project)
        f.addSeparator()
        f.addAction("Open Downloads Folder",
            lambda: __import__("subprocess").Popen(f'explorer "{DOWNLOADS_DIR}"'))
        f.addAction("Open Exports Folder",
            lambda: __import__("subprocess").Popen(f'explorer "{EXPORTS_DIR}"'))
        f.addSeparator()
        f.addAction("Settings", self._open_settings)
        f.addSeparator()
        f.addAction("Exit", self.close)

        v=mb.addMenu("View")
        for i,name in enumerate(["Library","Download","Extract","Review","Search","Analytics"]):
            a=QAction(name,self); a.setShortcut(f"Ctrl+{i+1}")
            a.triggered.connect(lambda _,n=i: self._tabs.setCurrentIndex(n))
            v.addAction(a)

        h=mb.addMenu("Help")
        h.addAction("WBDG UFC Index",
            lambda: __import__("webbrowser").open("https://www.wbdg.org/dod/ufc"))
        h.addAction("INCOSE Handbook",
            lambda: __import__("webbrowser").open("https://www.incose.org/products-and-publications/se-handbook"))
        h.addAction("About", self._show_about)

    def _on_reqs_ready(self, reqs):
        self._review_tab.load_requirements(reqs)
        # Library tab is index 0, so Review is now index 3
        self._tabs.setCurrentIndex(3)
        self._status.showMessage(f"Loaded {len(reqs):,} requirements into Review")
        # Refresh search sources
        srcs=sorted({r.get("source_ufc",r.get("source","")) for r in reqs})
        self._search_tab.refresh_sources(srcs)

    def _on_tab_changed(self, idx):
        # Analytics is now index 5 (Library added at 0)
        if idx==5:
            self._analytics.refresh()

    def _open_settings(self):
        dlg=SettingsDialog(self._config, self)
        dlg.config_saved.connect(lambda cfg: setattr(self,'_config',cfg))
        dlg.exec()

    def _new_project(self):
        dlg=ProjectLauncherDialog(self._config, self)
        if dlg.exec()==QDialog.Accepted:
            path=dlg.selected_path()
            if path: self._switch_project(path)

    def _open_project(self):
        path,_=QFileDialog.getOpenFileName(self,"Open Project",
            str(APP_DIR/"projects"),"UFC Project (*.ufcdb)")
        if path: self._switch_project(path)

    def _switch_project(self, path: str):
        self._config.last_project_path=path
        self._config.save()
        QMessageBox.information(self,"Restart Required",
            f"Project selected:\n{path}\n\nRestart the application to open this project.")

    def _show_about(self):
        dlg=QMessageBox(self)
        dlg.setWindowTitle("About UFC Requirements Tool v2")
        dlg.setText(
            "<b>UFC Requirements Tool v2</b><br><br>"
            "Phase 1–5 professional upgrade.<br><br>"
            "<b>Features:</b><br>"
            "• LLM classification (LM Studio / Ollama / OpenAI-compatible)<br>"
            "• ChromaDB semantic search + near-duplicate detection<br>"
            "• SQLite project workspace with audit log<br>"
            "• INCOSE / ISO 29148 heuristic + LLM quality scoring<br>"
            "• Requirement traceability matrix (RTM)<br>"
            "• UFC edition change detection<br>"
            "• ReqIF 1.2 export (DOORS NG / Jama / Polarion)<br><br>"
            "Source: <a href='https://www.wbdg.org/dod/ufc'>WBDG.org</a>"
        )
        dlg.exec()


# ═══════════════════════════════════════════════════════════════════════════════
# Entry point
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    app=QApplication(sys.argv)
    app.setApplicationName("UFC Requirements Tool v2")
    app.setOrganizationName("DoD Facilities Engineering")
    app.setStyle("Fusion")
    app.setStyleSheet(STYLESHEET)

    pal=QPalette()
    pal.setColor(QPalette.Window,        QColor(DARK_BG))
    pal.setColor(QPalette.WindowText,    QColor(TEXT_MAIN))
    pal.setColor(QPalette.Base,          QColor(DARK_SURF))
    pal.setColor(QPalette.AlternateBase, QColor(DARK_SURF2))
    pal.setColor(QPalette.Text,          QColor(TEXT_MAIN))
    pal.setColor(QPalette.Button,        QColor(DARK_SURF2))
    pal.setColor(QPalette.ButtonText,    QColor(TEXT_MAIN))
    pal.setColor(QPalette.Highlight,     QColor(ACCENT))
    pal.setColor(QPalette.HighlightedText,QColor("white"))
    pal.setColor(QPalette.Link,          QColor(ACCENT))
    app.setPalette(pal)

    # Load config
    config=AppConfig.load()

    # Load catalog
    with open(CATALOG_PATH) as f:
        catalog=json.load(f)

    # Project launcher
    launcher=ProjectLauncherDialog(config)
    launcher.setStyleSheet(STYLESHEET)

    # Pre-select last project if it still exists
    if config.last_project_path and Path(config.last_project_path).exists():
        db=ProjectDB(Path(config.last_project_path))
        config.save()
    else:
        if launcher.exec()!=QDialog.Accepted or not launcher.selected_path():
            sys.exit(0)
        db_path=launcher.selected_path()
        config.last_project_path=db_path
        config.save()
        db=ProjectDB(Path(db_path))

    win=MainWindow(config, db, catalog)
    win.show()
    sys.exit(app.exec())


if __name__=="__main__":
    main()
